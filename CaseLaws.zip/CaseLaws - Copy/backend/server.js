const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const sql = require('mssql/msnodesqlv8');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer=require('multer')
const path = require('path');
const fs = require('fs');
const nodemailer = require('nodemailer');
const dotenv=require('dotenv');
const { Client } = require('@elastic/elasticsearch');
const expressAsyncHandler=require("express-async-handler");
const { count } = require('console');


const client = new Client({ node: 'http://localhost:9200' });

module.exports = client;

dotenv.config();



const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false, // Use `true` for port 465, `false` for all other ports
  auth: {
    user: process.env.SMTP_MAIL,
    pass: process.env.SMTP_PASSWORD,
  },
});
const sendEmail= expressAsyncHandler(async(req,res)=>{
    const {email}=req.body;

    var mailOptions={
      from:process.env.SMTP_MAIL,
      to:email,
      subject: "Thank You for Signing Up!",
    text: `Dear Lawyer,

Thank you for signing up on our platform. Your data has been successfully submitted for verification.

Your profile will be created after the verification process is completed. We will notify you once your profile is verified and activated.

Best regards,
Legal Insight
    `,
  }
    
    transporter.sendMail(mailOptions,function(error,info){
      if (error) {
            console.log("Generated mail option:", mailOptions);
            console.log("Error while sending email:", error);


            let errorMessage = 'Error while sending email.';
            if (error.code === 'EAUTH') {
              errorMessage += ' Invalid login credentials.';
            } else if (error.code === 'ENOTFOUND' || error.code === 'ECONNECTION') {
              errorMessage += ' Unable to connect to the SMTP server.';
            } else if (error.responseCode === 550) {
              errorMessage += ' Invalid recipient email address.';
            }

        res.status(500).json({ message: errorMessage, error: error.toString() });
      } else {
        console.log("Email sent successfully");
        res.status(200).json({ message: 'Email sent successfully' });
      }
    })
});


const port = 5000;

const app = express();
app.use(cors(
  {
    origin:["http://localhost:3000","http://localhost:3001"],
    methods:["POST","GET","DELETE"],
    credentials:true
  }
));
app.use(express.json());
app.use(cookieParser());
app.use(bodyParser.json());
app.use(
  session({
    secret: 'secret', 
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: false,
      maxAge:1000 * 60 * 60 * 24 * 30
       }
  })
);

app.post('/send-email', sendEmail);

// Serve static files from the 'public/images' directory
app.use('/images', express.static(path.join(__dirname, 'public', 'images')));

// Database Configuration
const dbConfig = {
  user: 'your_username', // Update with your SQL Server username if using SQL authentication
  password: 'your_password', // Update with your SQL Server password if using SQL authentication
  server: 'DESKTOP-65ER0LH\\SQLEXPRESS01',
  database: 'CaseLaws',
  driver: 'msnodesqlv8',
  options: {
    trustedConnection: true,
    enableArithAbort: true,
  },
  pool: {
    max: 10, // Maximum number of connections in the pool
    min: 0,  // Minimum number of connections in the pool
    idleTimeoutMillis: 30000, // Close idle connections after 30 seconds
    acquireTimeoutMillis: 60000, // Time in ms to wait for a connection to become available before throwing an error
  },
};

module.exports = dbConfig;
app.get('/', async (req, res) => {
  
  if (req.session.userData) {
    return res.json({ valid: true, userData: req.session.userData });
  } 
  else {
   
    return res.json({ valid: false });
  }
});

// Add this route to handle logout
app.post('/logout', (req, res) => {
// Destroy the session
req.session.destroy((err) => {
  if (err) {
    console.error('Error destroying session:', err);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  } else {
    // Respond with success
    res.clearCookie('connect.sid'); // Clear the session cookie
    res.status(200).json({ success: true, message: 'Logout successful' });
  }
});
});

app.get('/api', (req, res) => {
res.send('Hello from the server!My name is talha khalil');
});


//Route to handle the signup
app.post('/signup', async (req, res) => {
  try {
    const { fullName, email, password } = req.body;

    // Hash the password using bcrypt
    const hashedPassword = await bcrypt.hash(password, 10); // 10 is the salt rounds

    const pool = await sql.connect(dbConfig);

    const result = await pool
      .request()
      .input('fullName', sql.NVarChar(50), fullName)
      .input('email', sql.NVarChar(100), email)
      .input('password', sql.NVarChar(255), hashedPassword) // Store the hashed password
      .query('INSERT INTO Login (Username, Email, Pasword) VALUES (@fullName, @email, @password)');

    await pool.close();

    res.status(200).json({ success: true, message: 'User registered successfully.' });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ success: false, message: 'Internal server error.' });
  }
});


const jwtSecretKey = 'mySecretKey';

app.post('/login', async (req, res) => {
  try {
    // Assuming your login form sends an object with email and password
    const { username, password } = req.body;
   
    // Database connection
    await sql.connect(dbConfig);

    // Query to retrieve hashed password from the database
    const queryResult = await sql.query`SELECT * FROM Login WHERE Username = ${username}`;

    // Check if any record was found
    if (queryResult.recordset.length > 0) {
      // Compare the entered password with the stored hashed password
      const hashedPassword = queryResult.recordset[0].Pasword;
      const passwordMatch = await bcrypt.compare(password, hashedPassword);

      if (passwordMatch) {
        // Set user session
        req.session.userData = {
          username: queryResult.recordset[0].Username,
          email: queryResult.recordset[0].Email,
          password:password,
        };
        
        res.status(200).json({ success: true});
      } else {
        console.log('Password does not match');
        res.status(401).json({ success: false, message: 'Incorrect password' });
      }
    } else {
      console.log('No record found');
      res.status(404).json({ success: false, message: 'No record found' });
    }
  } catch (error) {
    console.error('Error handling login:', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  } finally {
    // Close the database connection
    await sql.close();
  }
});









// Function to connect to the database and execute the query
const executeQuery = async (query, params = []) => {
  try {
    await sql.connect(dbConfig);
    const result = await sql.query(query, ...params);
    return result.recordset;
  } finally {
    // Close the database connection
    await sql.close();
  }
};

app.get('/api', (req, res) => {
  res.send('Hello from the server! My name is talha khalil');
});





// Route to handle login POST requests from searchbar.js
// app.post('/search', async (req, res) => {
//   try {
//     console.log('Search request received:', req.body);
//     const { searchQuery } = req.body;

//     let containsConditions = '';
//     let score = '';
//     let finalQuery='';

//     // Split the search query into individual words
//     const words = searchQuery.split(/\s+/).map(word => word.replace(/[^a-zA-Z0-9]/g, ''));

//     // Filter out stop words
//     const filteredWords = words.filter(word => !stopWords.includes(word.toLowerCase()));

//     console.log("");

//     if (searchQuery.includes('"')) 
//     {
//       console.log("Exact matching search triggered.");
//       // Handle exact match search
//       const exactMatchQuery = searchQuery.slice(1, -1);
//       finalQuery = `
//         SELECT *
//         FROM CaseLaws4
//         WHERE 
//           CaseNo LIKE '%${exactMatchQuery}%' OR
//           CaseSubject LIKE '%${exactMatchQuery}%' OR
//           CaseTitle LIKE '%${exactMatchQuery}%' OR
//           Court LIKE '%${exactMatchQuery}%' OR
//           AuthorJudge LIKE '%${exactMatchQuery}%' OR
//           JudgementDate LIKE '%${exactMatchQuery}%' OR
//           Citation LIKE '%${exactMatchQuery}%' OR
//           SCCitation LIKE '%${exactMatchQuery}%' OR
//           Tagline LIKE '%${exactMatchQuery}%' OR
//           Judgement LIKE '%${exactMatchQuery}%'
//       `;
//    }
    
//     else 
//     {
//       // Handle regular search
//       if (filteredWords.length === 0) {
//         // Handle empty search query gracefully (optional)
//         console.log("Empty search query")
//         res.status(400).json({ message: 'Please enter a valid search term' });
//         return;
//       }

//       // Build the CONTAINS part of the query for each word
//       containsConditions = filteredWords.map(word => {
//         return `
//           CONTAINS(Keywords, '${word}')
//         `;
//       }).join(' OR ');

//       score = `
//         (
//           ${filteredWords.map(word => `
//             CASE
//               WHEN CONTAINS(Keywords, '${word}') THEN 1
//               ELSE  0 
//           END
//           `).join('+')}
//         ) AS score
//       `;

//         finalQuery = `
//         SELECT TOP 100 *,
//           ${score}
//         FROM CaseLaws4
//         WHERE ${containsConditions}
//         ORDER BY score DESC
//       `;
//     }

//     console.log("Final query::::", finalQuery)
//     const searchResults = await executeQuery(finalQuery);

//     if (searchResults.length > 0) {
//       if (score) {
//         // Calculate the minimum required score for 50% match
//         const minRequiredScore = Math.ceil((filteredWords.length / 2));

//         // Filter results based on the minimum required score
//         const filteredResults = searchResults.filter(result => result.score >= minRequiredScore);

//         filteredResults.forEach(result => {
//           // console.log(`Score: ${result.score}, CaseNo: ${result.CaseNo}`);
//         });
//         res.status(200).json(filteredResults);
//       } else {
//         console.log('Record found:', searchResults.length);
//         res.status(200).json(searchResults);
//       }
//     } else {
//       console.log('No record found');
//       res.status(404).json({ message: 'No record found' });
//     }
//   } catch (error) {
//     console.error('Error handling search:', error.message);
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

const stopWords = [
  "the", "a", "an", "in", "on", "at", "to", "from", "by", "is", "are", "was", "were", "be", "have", "has",
   "had", "will", "would", "could", "should", "may", "might", "do", "does", "did", "of", "and", "but", "or",
    "nor", "so", "as", "what", "which", "how", "their", "our", "its", "his", "her", "these", "those", "each",
     "some", "any", "all", "many", "most", "other", "same", "well", "only", "if", "else", "when", "where", "why",
      "how", "again", "further", "then", "once", "here", "there", "all", "any", "much", "most", "other", "same",
       "such", "than", "too", "very", "can", "for", "no", "more", "out", "up", "over", "down", "in", "into", "on",
        "upon", "with", "between"
];



app.post('/search', async (req, res) => {
  try {
    console.time('Total search time');
    console.log('Search request received:', req.body);
    const { searchQuery } = req.body;

    let containsConditions = '';
    let score = '';
    let finalQuery = '';
    let isExactSearch = false;
    let exactMatchQuery = '';

    console.time('Split and filter words');
    const words = searchQuery.split(/\s+/);
    const filteredWords = words.filter(word => !stopWords.includes(word.toLowerCase()));
    console.timeEnd('Split and filter words');

    if (searchQuery.startsWith('"') && searchQuery.endsWith('"')) {
      console.log("Exact matching search triggered.");
      isExactSearch = true;
      exactMatchQuery = searchQuery.slice(1, -1);

      const exactWords = exactMatchQuery.split(/\s+/);
      const firstWord = exactWords[0];
      const lastWord = exactWords[1];

      const conditions = `
        (
          CONTAINS(CombinedText, '${firstWord}')

        )
      `;

      finalQuery = `
        SELECT CaseNo, CombinedText
        FROM CaseLaws4
        WHERE ${conditions}
      `;
    } else {
      if (filteredWords.length === 0) {
        console.log("Empty search query");
        res.status(400).json({ message: 'Please enter a valid search term' });
        return;
      }

      console.time('Build query time:');
      containsConditions = filteredWords.map(word => `
        CONTAINS(CombinedText, '${word}')
      `).join(' OR ');

      score = `
        (
          ${filteredWords.map(word => `
            CASE
              WHEN CONTAINS(CombinedText, '${word}') THEN 1
              ELSE 0
            END
          `).join(' + ')}
        ) AS score
      `;
      console.timeEnd('Build query time:');

      finalQuery = `
        SELECT CaseNo, ${score}
        FROM CaseLaws4
        WHERE ${containsConditions}
        ORDER BY score DESC
      `;
    }

    console.log("Final query:", finalQuery);

    console.time('Execute query');
    const searchResults = await executeQuery(finalQuery);
    console.timeEnd('Execute query');

    if (searchResults.length > 0) {
      console.time('Fetch Records time:');
      let filteredResults;

      if (isExactSearch) {

        console.log("Results found:",searchResults.length)
        console.log("Exact Match Query:",exactMatchQuery)

        // Filter results manually for exact search
        filteredResults = searchResults.filter(result => {
          const combinedText = result.CombinedText.toLowerCase();
          return combinedText.includes(exactMatchQuery.toLowerCase());
        });
      } else {
        const minRequiredScore = Math.ceil(filteredWords.length / 2);
        filteredResults = searchResults.filter(result => result.score >= minRequiredScore);
      }

      if (filteredResults.length > 0) {

              // Limit the filtered results to 2000 if there are more than 2000 results
          if (filteredResults.length > 1200) {
            filteredResults = filteredResults.slice(0, 1200);
        }
        const caseNos = filteredResults.map(result => `'${result.CaseNo}'`);
        const caseLawResults = [];

        const batchSize = 100; // Adjust the batch size as needed
        for (let i = 0; i < caseNos.length; i += batchSize) {
          const batch = caseNos.slice(i, i + batchSize).join(',');
          const caseLawQuery = `SELECT ID, CaseNo, CaseSubject, CaseTitle, Court, AuthorJudge, JudgementDate, Citation, SCCitation, Tagline, Judgement FROM CaseLaws4 WHERE CaseNo IN (${batch})`;

          const batchResults = await executeQuery(caseLawQuery);
          caseLawResults.push(...batchResults);
        }
        console.timeEnd('Fetch Records time:');

        if (!isExactSearch) {
          caseLawResults.forEach(result => {
            const combinedText = `${result.CombinedText} ${result.Tagline} ${result.Judgement}`.toLowerCase();
            result.count = filteredWords.reduce((count, word) => {
              const regex = new RegExp(`\\b${word}\\b`, 'g');
              const matches = combinedText.match(regex);
              return count + (matches ? matches.length : 0);
            }, 0);
          });

          caseLawResults.sort((a, b) => b.count - a.count);
        }

        res.status(200).json(caseLawResults);
      } else {
        console.log('No record found with sufficient score');
        res.status(404).json({ message: 'No record found with sufficient score' });
      }
    } else {
      console.log('No record found');
      res.status(404).json({ message: 'No record found' });
    }

    console.timeEnd('Total search time');
  } catch (error) {
    console.error('Error handling search:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});




app.post('/search2', async (req, res) => {
  try {
    console.log('Search request received:', req.body);
    const {
      caseno,
      casesubject,
      casetitle,
      judgename,
      judgementdate,
      courtname,
      casecitation,
      keyword,
    } = req.body;

    const sanitizeAndQuote = (columnName, value) => {
      if (value) {
        const sanitizedValue = value.replace(/[^a-zA-Z0-9\s]/g, '');
        return `CONTAINS(${columnName}, '${sanitizedValue}')`;
      }
      return null;
    };

    const queryConditions = [];
    const scoreConditions = [];
    const filteredWords = [];  // New array to store filtered keywords


      if (caseno) {
        const words = caseno.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
        const conditions = words.map(word => sanitizeAndQuote('CaseNo', word)).filter(Boolean);
        if (conditions.length > 0) {
          queryConditions.push(`(${conditions.join(' OR ')})`);
          scoreConditions.push(
            words.map(word => `CASE WHEN CONTAINS(CaseNo, '${word}') THEN 1 ELSE 0 END`).join(' + ')
          );
          
          filteredWords.push(...words);
        }
      }


    if (casesubject) {
      const words = casesubject.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
      const conditions = words.map(word => sanitizeAndQuote('CaseSubject', word)).filter(Boolean);
      if (conditions.length > 0) {
        queryConditions.push(`(${conditions.join(' OR ')})`);
        scoreConditions.push(
          words.map(word => `CASE WHEN CONTAINS(CaseSubject, '${word}') THEN 1 ELSE 0 END`).join(' + ')
        );
        
        filteredWords.push(...words);
      }
    }

    if (casetitle) {
      const words = casetitle.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
      const conditions = words.map(word => sanitizeAndQuote('CaseTitle', word)).filter(Boolean);
      if (conditions.length > 0) {
        queryConditions.push(`(${conditions.join(' OR ')})`);
        scoreConditions.push(
          words.map(word => `CASE WHEN CONTAINS(CaseTitle, '${word}') THEN 1 ELSE 0 END`).join(' + ')
        );
        
        filteredWords.push(...words);
      }
    }

    if (courtname) {
      const words = courtname.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
      const conditions = words.map(word => sanitizeAndQuote('Court', word)).filter(Boolean);
      if (conditions.length > 0) {
        queryConditions.push(`(${conditions.join(' OR ')})`);
        scoreConditions.push(
            words.map(word => `CASE WHEN CONTAINS(Court, '${word}') THEN 1 ELSE 0 END`).join(' + ')
        );
        
        filteredWords.push(...words);
      }
    }

    if (judgename) {
      const words = judgename.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
      const conditions = words.map(word => sanitizeAndQuote('AuthorJudge', word)).filter(Boolean);
      if (conditions.length > 0) {
        queryConditions.push(`(${conditions.join(' OR ')})`);
        scoreConditions.push(
              words.map(word => `CASE WHEN CONTAINS(AuthorJudge, '${word}') THEN 1 ELSE 0 END`).join(' + ')
        );
        filteredWords.push(...words);
      }
    }

    if (judgementdate) {
      const words = judgementdate.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
      const conditions = words.map(word => sanitizeAndQuote('JudgementDate', word)).filter(Boolean);
      if (conditions.length > 0) {
        queryConditions.push(`(${conditions.join(' OR ')})`);
        scoreConditions.push(
           words.map(word => `CASE WHEN CONTAINS(JudgementDate, '${word}') THEN 1 ELSE 0 END`).join(' + ')
        );
        filteredWords.push(...words);
      }
    }

    if (casecitation) {
      const words = casecitation.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
      const conditions = words.map(word => sanitizeAndQuote('Citation', word)).filter(Boolean);
      if (conditions.length > 0) {
        queryConditions.push(`(${conditions.join(' OR ')})`);
        scoreConditions.push(
             words.map(word => `CASE WHEN CONTAINS(Citation, '${word}') THEN 1 ELSE 0 END`).join(' + ')
        );
        filteredWords.push(...words);
      }
    }

    if (keyword) {
      const words = keyword.split(/\s+/).filter(word => !stopWords.includes(word.toLowerCase()));
      const conditions = words.map(word => sanitizeAndQuote('Judgement', word)).filter(Boolean);
      if (conditions.length > 0) {
        queryConditions.push(`(${conditions.join(' OR ')})`);
        scoreConditions.push(
          words.map(word => `CASE WHEN CONTAINS(Judgement, '${word}') THEN 1 ELSE 0 END`).join(' + ')
        );
        filteredWords.push(...words);
      }
    }

    console.log("Query conditions:", queryConditions);

    if (queryConditions.length > 0) {
      const score = scoreConditions.join('+');
      const whereClause = 'WHERE ' + queryConditions.join(' AND ');

      const query = `
        SELECT CaseNo,${score} AS score
        FROM CaseLaws4
        ${whereClause}
        ORDER BY score DESC
      `;

      console.log("Final query:::",query)
      const searchResults = await executeQuery(query);

      // Print the results to the terminal
      console.log('Search Results:', searchResults.length);

      // Check if any record was found
      if (searchResults.length > 0) {
        // Count the number of unique words in the search query
        const uniqueWordsCount = new Set(filteredWords).size;

        // // Calculate the minimum required score for 50% match
        // const minRequiredScore = Math.ceil((uniqueWordsCount / 2));
        const minRequiredScore = Math.ceil((uniqueWordsCount * 0.6));



        // Filter results based on the minimum required score
        let filteredResults = searchResults.filter(result => result.score >= minRequiredScore);


        if (filteredResults.length > 0) {

            if (filteredResults.length > 2500) {
                filteredResults = filteredResults.slice(0, 2500);
            }
            const caseNos = filteredResults.map(result => `'${result.CaseNo}'`);
            const caseLawResults = [];

            const batchSize = 200; // Adjust the batch size as needed
            for (let i = 0; i < caseNos.length; i += batchSize) {
              const batch = caseNos.slice(i, i + batchSize).join(',');
              const caseLawQuery = `SELECT ID, CaseNo, CaseSubject, CaseTitle, Court, AuthorJudge, JudgementDate, Citation, SCCitation, Tagline, Judgement FROM CaseLaws4 WHERE CaseNo IN (${batch})`;

              const batchResults = await executeQuery(caseLawQuery);
              caseLawResults.push(...batchResults);

            }


              console.log('Record found:',searchResults.length);
              console.log('Filtered records::',filteredResults.length);
              console.log('No. of Keywords::',uniqueWordsCount);

              res.status(200).json(caseLawResults);
        }
       
           
      } else {
        console.log('No record found');
        res.status(404).json({ message: 'No record found' });
      }
    } else {
      console.log('No query conditions provided');
      res.status(400).json({ message: 'No query conditions provided' });
    }
  } catch (error) {
    console.error('Error handling search:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Endpoint to handle bookmarking
app.post('/bookmark', async (req, res) => {
  const { userName, caseNo } = req.body;

  try {
    // Connect to SQL Server
    await sql.connect(dbConfig);

    // Insert data into the Bookmarkjudgements table
    const result = await sql.query`INSERT INTO Bookmarkjudgements (Username, Caseno) VALUES (${userName}, ${caseNo})`;

    console.log('Judgment bookmarked successfully:', result);

    res.status(200).json({ success: true, message: 'Judgment bookmarked successfully' });
  } catch (error) {
    console.error('Error bookmarking judgment:', error);
    res.status(500).json({ success: false, message: 'Error bookmarking judgment' });
  } finally {
    // Close the SQL Server connection
    await sql.close();
  }
});

// Endpoint to handle fetching bookmarked cases
app.post('/fetchcases', async (req, res) => {
  const { userName } = req.body;

  try {
    // Connect to SQL Server
    await sql.connect(dbConfig);

    // Fetch bookmarked cases associated with the user's email
    const result = await sql.query`SELECT Caseno FROM Bookmarkjudgements WHERE Username = ${userName}`;

    // console.log('Record found',result);
    
     if(result.recordset.length>0)
      {
        // console.log('Record found',result);
        // res.status(200).json(result);
        // Extract Caseno values from the result
          const casenoArray = result.recordset.map((row) => row.Caseno);

          // Fetch CaseLaws from the CaseLaws table based on the Caseno values
          const caseLawsResult = await sql.query`SELECT * FROM CaseLaws4 WHERE Caseno IN (${casenoArray})`;

            console.log('CaseLaws found are:',caseLawsResult.recordset.length);
            res.status(200).json(caseLawsResult.recordset);
         
      }
      else{
        console.log('No record found');
        res.status(404).json({ message: 'No record found' });
      }
     
  } catch (error) {
    console.error('Error fetching bookmarked cases:', error);
    res.status(500).json({ error: 'Error fetching bookmarked cases' });
  } finally {
    // Close the SQL Server connection
    await sql.close();
  }
});

// Endpoint to handle fetching updated bookmarked cases
app.post('/fetch', async (req, res) => {
  const { userName } = req.body;
  console.log("username:::",userName)

  try {
    // Connect to SQL Server
    await sql.connect(dbConfig);

    // Fetch bookmarked cases associated with the user's email
    const result = await sql.query`SELECT Caseno FROM Bookmarkjudgements WHERE Username = ${userName}`;

    // console.log('Record found',result);
    
     if(result.recordset.length>0)
      {
        // console.log('Record found',result);
        // res.status(200).json(result);
        // Extract Caseno values from the result
          const casenoArray = result.recordset.map((row) => row.Caseno);

          // Fetch CaseLaws from the CaseLaws table based on the Caseno values
          const caseLawsResult = await sql.query`SELECT * FROM CaseLaws4 WHERE Caseno IN (${casenoArray})`;

            console.log('CaseLaws found are:',caseLawsResult.recordset.length);
            res.status(200).json(caseLawsResult.recordset);
         
      }
      else{
        console.log('No record found');
        res.status(404).json({ message: 'No record found' });
      }
     
  } catch (error) {
    console.error('Error fetching bookmarked cases:', error);
    res.status(500).json({ error: 'Error fetching bookmarked cases' });
  } finally {
    // Close the SQL Server connection
    await sql.close();
  }
});
app.delete('/api/bookmarks', async (req, res) => {
  const { caseNo, userName } = req.body;
  console.log("Case no. is:::",caseNo,"User email is::::",userName)

  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool.request()
      .input('Caseno', sql.NVarChar, caseNo)
      .input('Username', sql.NVarChar, userName)
      .query(`
        DELETE FROM Bookmarkjudgements
        WHERE Caseno = @CaseNo AND Username = @Username;
      `);

    if (result.rowsAffected[0] > 0) {
      res.json({ success: true, message: 'Bookmark deleted successfully' });
    } else {
      res.status(404).json({ success: false, message: 'Bookmark not found' });
    }
    await pool.close();
  } catch (error) {
    console.error('Error deleting bookmark:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

app.get('/fetchbookmarks', async (req, res) => {
  const userName = req.query.userName;

  if (!userName) {
    return res.status(400).json({ error: 'Username is required' });
  }

  try {
    // Create a new connection pool
    const pool = await sql.connect(dbConfig);

    // Execute the query to fetch bookmarks
    const result = await pool.request()
      .input('userName', sql.NVarChar, userName)
      .query('SELECT Caseno FROM Bookmarkjudgements WHERE Username = @userName');

    // Close the connection pool
    await pool.close();

    // Extract bookmarked case numbers from the result
    const bookmarks = result.recordset.map(row => row.Caseno);
    
    // Send the bookmarked case numbers as response
    res.json(bookmarks);
  } catch (error) {
    console.error('Error fetching bookmarks:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

const storage=multer.diskStorage({
      destination:(req,file,cb)=>{
             cb(null,'public/images')
      },
      filename: (req, file, cb) => {
       
        const originalFilename = file.originalname.split('.')[0]; 
        const fileExtension = '.png';                 
        const newFilename = `${originalFilename}${fileExtension}`; 
        cb(null, newFilename);
    }
})

const upload=multer({
      storage:storage
})

app.post('/upload',upload.array('images'),async(req,res)=>
{
  try {
      if (req.files && req.files.length > 0) {
          // Assuming you have the lawyer ID available in req.files[0].filename
          const pool = await sql.connect(dbConfig);

          const lawyerId = req.files[0].filename.split('_')[0];
          console.log("Fetched lawyer ID:",lawyerId)
          // Extract filenames from req.files
          const imageNames = req.files.map(file => file.filename);
          
          console.log("Image data:",req.files)
          // Construct the SQL UPDATE query to update the image fields in the LawyerSignupData table
          const updateImageFieldsQuery = `
              UPDATE LawyerSignupData
              SET
                  frontImage = @frontImage,
                  backImage = @backImage,
                  LLBdegree = @LLBdegree,
                  LAWGATresult = @LAWGATresult,
                  certificateImage = @certificateImage,
                  approvalImage = @approvalImage,
                  lawyerImage = @lawyerImage
              WHERE ID = @lawyerId;
          `;

          // Execute the SQL UPDATE query
          const result = await pool.request()
              .input('frontImage', sql.VarChar(255), imageNames[0])
              .input('backImage', sql.VarChar(255), imageNames[1])
              .input('LLBdegree', sql.VarChar(255), imageNames[2])
              .input('LAWGATresult', sql.VarChar(255), imageNames[3])
              .input('certificateImage', sql.VarChar(255), imageNames[4])
              .input('approvalImage', sql.VarChar(255), imageNames[5])
              .input('lawyerImage', sql.VarChar(255), imageNames[6])
              .input('lawyerId', sql.Int, lawyerId)
              .query(updateImageFieldsQuery);

          console.log('Image fields updated successfully');
          res.status(200).json({ message: 'Images uploaded and database updated successfully' });

          await pool.close();
      } else {
          res.status(400).json({ error: 'No images were uploaded' });
      }
  } catch (error) {
      console.error('Error uploading images and updating database:', error);
      res.status(500).json({ error: 'An error occurred while uploading images and updating database' });
  }
     
})


let pool;
// API endpoint to insert lawyer signup data
app.post('/submit-lawyer-data', async (req, res) => {
  // Create connection pool
  pool = await sql.connect(dbConfig);
  try {
    
    const {
      form1,
      form2,
      form3,
      form4,
      form5,
      form6,
      form7
    } = req.body;
    
    console.log("Form1 data::",form1)
    console.log("Form2 data::",form2)
    console.log("Form3 data::",form3)
    console.log("Form4 data::",form4)
    console.log("Form5 data::",form5)
    console.log("Form6 data::",form6)
    console.log("Form7 data::",form7)

    // Fetch username from session data
    const username = req.session.userData ? req.session.userData.username: null;

    if(!username){
      res.status(401).json({ error: 'An error occurred while inserting data' })
    }

    // Start transaction
    await pool.request().query('BEGIN TRANSACTION');

    // Insert into main table
    const mainTableQuery = `
      INSERT INTO LawyerSignupData (Username, barAffiliation, barAssociation, frontImage, backImage, name, email, phone, gender, province, city, education, graduationYear, LLB, LLM, LLD, LLBdegree, LAWGATresult, currentPosition, durationOfPractice, lowerCourts, highCourt, certificateImage, approvalImage, licenseNumber, certifications, caseExperience, notableCases, successStories, officeAddress, lawyerImage, facebook, whatsapp, linkedin)
      OUTPUT inserted.ID
      VALUES (@Username, @barAffiliation, @barAssociation, @frontImage, @backImage, @name, @email, @phone, @gender, @province, @city, @education, @graduationYear, @LLB, @LLM, @LLD, @LLBdegree, @LAWGATresult, @currentPosition, @durationOfPractice, @lowerCourts, @highCourt, @certificateImage, @approvalImage, @licenseNumber, @certifications, @caseExperience, @notableCases, @successStories, @officeAddress, @lawyerImage, @facebook, @whatsapp, @linkedin)
    `;

  
    const result = await pool.request()
      .input('Username', sql.NVarChar(50), username)
      .input('barAffiliation', sql.VarChar(255), form1.barAffiliation || 'NIL')
      .input('barAssociation', sql.VarChar(255), form1.barAssociation || 'NIL')
      .input('frontImage', sql.VarChar(255), 'NIL') // Placeholder for image name
      .input('backImage', sql.VarChar(255), 'NIL') // Placeholder for image name
      .input('name', sql.VarChar(255), form2.name || 'NIL')
      .input('email', sql.VarChar(255), form2.email || 'NIL')
      .input('phone', sql.VarChar(255), form2.phone || 'NIL')
      .input('gender', sql.VarChar(255), form2.gender || 'NIL')
      .input('province', sql.VarChar(255), form2.province || 'NIL')
      .input('city', sql.VarChar(255), form2.city || 'NIL')
      .input('education', sql.VarChar(sql.MAX), form3.education || 'NIL')
      .input('graduationYear', sql.Int, parseInt(form3.graduationYear) || 0)
      .input('LLB', sql.VarChar(255), form3.LLB || 'NIL')
      .input('LLM', sql.VarChar(255), form3.LLM || 'NIL')
      .input('LLD', sql.VarChar(255), form3.LLD || 'NIL')
      .input('LLBdegree', sql.VarChar(255), 'NIL') // Placeholder for image name
      .input('LAWGATresult', sql.VarChar(255), 'NIL') // Placeholder for image name
      .input('currentPosition', sql.VarChar(255), form4.currentPosition || 'NIL')
      .input('durationOfPractice', sql.Int, parseInt(form4.durationOfPractice) || 0)
      .input('lowerCourts', sql.VarChar(sql.MAX), form4.lowerCourts || 'NIL')
      .input('highCourt', sql.VarChar(255), form4.highCourt || 'NIL')
      .input('certificateImage', sql.VarChar(255), 'NIL') // Placeholder for image name
      .input('approvalImage', sql.VarChar(255), 'NIL') // Placeholder for image name
      .input('licenseNumber', sql.VarChar(255), form5.licenseNumber || 'NIL')
      .input('certifications', sql.VarChar(sql.MAX), form5.certifications || 'NIL')
      .input('caseExperience', sql.VarChar(sql.MAX), form5.caseExperience || 'NIL')
      .input('notableCases', sql.VarChar(sql.MAX), form5.notableCases || 'NIL')
      .input('successStories', sql.VarChar(sql.MAX), form5.successStories || 'NIL')
      .input('officeAddress', sql.VarChar(sql.MAX), form6.officeAddress || 'NIL')
      .input('lawyerImage', sql.VarChar(255), 'NIL') // Placeholder for image name
      .input('facebook', sql.VarChar(255), form7.facebook || 'NIL')
      .input('whatsapp', sql.VarChar(255), form7.whatsapp || 'NIL')
      .input('linkedin', sql.VarChar(255), form7.linkedin || 'NIL')
      .query(mainTableQuery);



    console.log("After main table insertion query", result);
    // Get the inserted lawyerId
    // Get the inserted lawyerId
    const lawyerId = result && result.recordset ? result.recordset[0].ID : null;
    console.log("fetched lawyer id for this row is:", lawyerId);

if (lawyerId) {


    // Insert into PracticeAreas table
    for (const area of form1.areas) {
      // Extract the value from the area object
      const areaValue = area.value;

      await pool.request()
        .input('lawyerId', sql.Int, lawyerId)
        .input('area', sql.VarChar(255), areaValue)
        .query('INSERT INTO PracticeAreas (lawyerId, area) VALUES (@lawyerId, @area)');
    }
    // Insert into ConsultationModes table
    for (const mode of form6.consultationModes) {
      const fee = form6.consultationFees[mode.value]; // Fetch fee based on mode value
      await pool.request()
        .input('lawyerId', sql.Int, lawyerId)
        .input('mode', sql.VarChar(255), mode.label) // Assuming you want to insert mode label into the database
        .input('fee', sql.VarChar(255), fee) // Fetch fee dynamically
        .query('INSERT INTO ConsultationModes (lawyerId, mode, fee) VALUES (@lawyerId, @mode, @fee)');
     }

    // Insert into OfficeHours table
    for (const [dayOfWeek, hours] of Object.entries(form6.officeHours)) {
      await pool.request()
        .input('lawyerId', sql.Int, lawyerId)
        .input('dayOfWeek', sql.VarChar(255), dayOfWeek)
        .input('startTime', sql.VarChar(255), hours.startTime)
        .input('endTime', sql.VarChar(255), hours.endTime)
        .query('INSERT INTO OfficeHours (lawyerId, dayOfWeek, startTime, endTime) VALUES (@lawyerId, @dayOfWeek, @startTime, @endTime)');
    }
}
else{
  console.log("Lawyer ID is null")
}

    // Commit transaction
    await pool.request().query('COMMIT TRANSACTION');

    res.status(200).json({ message: 'Data inserted successfully', data: lawyerId });

  } 
  catch (error) {
    console.error('Error inserting data:', error);
    if (pool && pool.transaction) {
        try {
            // Rollback transaction
            await pool.request().query('ROLLBACK TRANSACTION');
            console.log('Transaction rolled back successfully');
        } catch (rollbackError) {
            console.error('Error rolling back transaction:', rollbackError);
        }
    }
    console.log("Error caught:", error);
    res.status(500).json({ error: 'An error occurred while inserting data' });
  
  } 
  finally {
    // Close pool
    if (pool) await pool.close();
  }
});



// Fetch profile data
app.get('/fetch-profile', async (req, res) => {
 try 
 {
    // const username = req.query.username;
    const username = req.session.userData ? req.session.userData.username : null;
    console.log("Username fetched:",username)
    if (!username) {
      console.log("Username fetched null:",username)
      return res.status(401).json({ error: 'User not logged in' });
    }

    const pool = await sql.connect(dbConfig);

    const query = `
      SELECT * FROM LawyerSignupData WHERE Username = @Username;
      SELECT area FROM PracticeAreas WHERE lawyerId = (SELECT ID FROM LawyerSignupData WHERE Username = @Username);
      SELECT mode, fee FROM ConsultationModes WHERE lawyerId = (SELECT ID FROM LawyerSignupData WHERE Username = @Username);
      SELECT dayOfWeek, startTime, endTime FROM OfficeHours WHERE lawyerId = (SELECT ID FROM LawyerSignupData WHERE Username = @Username);
      SELECT * FROM LawyerReviews WHERE lawyerId = (SELECT ID FROM LawyerSignupData WHERE Username = @Username);
      `;

    const result = await pool.request()
      .input('Username', sql.NVarChar(50), username)
      .query(query);

    const profileData = result.recordsets[0][0];

    if (!profileData) {
      return res.status(404).json({ error: 'No profile found for the given username' });
    }
    const practiceAreas = result.recordsets[1];
    const consultationModes = result.recordsets[2];
    const officeHours = result.recordsets[3];
    const reviews = result.recordsets[4];

    // Define the public folder path where images are stored
    const publicFolderPath = path.join(__dirname, 'public', 'images');

    const images = {
      frontImage: profileData.frontImage ? `/images/${profileData.frontImage}` : null,
      backImage: profileData.backImage ? `/images/${profileData.backImage}` : null,
      LLBdegree: profileData.LLBdegree ? `/images/${profileData.LLBdegree}` : null,
      LAWGATresult: profileData.LAWGATresult ? `/images/${profileData.LAWGATresult}` : null,
      certificateImage: profileData.certificateImage ? `/images/${profileData.certificateImage}` : null,
      approvalImage: profileData.approvalImage ? `/images/${profileData.approvalImage}` : null,
      lawyerImage: profileData.lawyerImage ? `/images/${profileData.lawyerImage}` : null,
    };

    res.status(200).json({
      profileData,
      practiceAreas,
      consultationModes,
      officeHours,
      reviews,
      images,
    });

    await pool.close();
  } catch (error) {
    console.error('Error fetching profile data:', error);
    res.status(500).json({ error: 'An error occurred while fetching profile data' });
  }
});

app.get('/fetch-profile-id', async (req, res) => {
  try {
    const lawyerId = req.query.id;
    if (!lawyerId) {
      return res.status(400).json({ error: 'Lawyer ID is required' });
    }

    const pool = await sql.connect(dbConfig);

    const query = `
      SELECT * FROM LawyerSignupData WHERE ID = @LawyerId;
      SELECT area FROM PracticeAreas WHERE lawyerId = @LawyerId;
      SELECT mode, fee FROM ConsultationModes WHERE lawyerId = @LawyerId;
      SELECT dayOfWeek, startTime, endTime FROM OfficeHours WHERE lawyerId = @LawyerId;
      SELECT * FROM LawyerReviews WHERE lawyerId = @LawyerId;
    `;

    const result = await pool.request()
      .input('LawyerId', sql.Int, lawyerId)
      .query(query);

    const profileData = result.recordsets[0][0];

    if (!profileData) {
      return res.status(404).json({ error: 'No profile found for the given ID' });
    }
    const practiceAreas = result.recordsets[1];
    const consultationModes = result.recordsets[2];
    const officeHours = result.recordsets[3];
    const reviews = result.recordsets[4];

    // Define the public folder path where images are stored
    const publicFolderPath = path.join(__dirname, 'public', 'images');

    const images = {
      frontImage: profileData.frontImage ? `/images/${profileData.frontImage}` : null,
      backImage: profileData.backImage ? `/images/${profileData.backImage}` : null,
      LLBdegree: profileData.LLBdegree ? `/images/${profileData.LLBdegree}` : null,
      LAWGATresult: profileData.LAWGATresult ? `/images/${profileData.LAWGATresult}` : null,
      certificateImage: profileData.certificateImage ? `/images/${profileData.certificateImage}` : null,
      approvalImage: profileData.approvalImage ? `/images/${profileData.approvalImage}` : null,
      lawyerImage: profileData.lawyerImage ? `/images/${profileData.lawyerImage}` : null,
    };

    res.status(200).json({
      profileData,
      practiceAreas,
      consultationModes,
      officeHours,
      reviews,
      images,
    });

    await pool.close();
  } catch (error) {
    console.error('Error fetching profile data:', error);
    res.status(500).json({ error: 'An error occurred while fetching profile data' });
  }
});


app.post('/uploadEdit',upload.array('images'), async (req, res) => {
  
})



// API endpoint to insert or update lawyer signup data
app.post('/submit-lawyer-data-edit', async (req, res) => {
  const pool = new sql.ConnectionPool(dbConfig);
  const poolConnect = pool.connect();

  try {
    await poolConnect;

    const {
      form1, form2, form3, form4, form5, form6, form7
    } = req.body;


    const username = req.session.userData ? req.session.userData.username : null;

    const transaction = new sql.Transaction(pool);
    await transaction.begin();

    try {
      const request = new sql.Request(transaction);

      const existingLawyerResult = await request
        .input('Username1', sql.NVarChar(50), username)
        .query('SELECT ID FROM LawyerSignupData WHERE Username = @Username1');

      const lawyerId = existingLawyerResult.recordset.length > 0 ? existingLawyerResult.recordset[0].ID : null;

      // Check if updating an existing entry
      const query = `
        UPDATE LawyerSignupData
        SET
          barAffiliation = @barAffiliation,
          barAssociation = @barAssociation,
          name = @name,
          email = @email,
          phone = @phone,
          gender = @gender,
          province = @province,
          city = @city,
          education = @education,
          graduationYear = @graduationYear,
          LLB = @LLB,
          LLM = @LLM,
          LLD = @LLD,
          currentPosition = @currentPosition,
          durationOfPractice = @durationOfPractice,
          lowerCourts = @lowerCourts,
          highCourt = @highCourt,
          licenseNumber = @licenseNumber,
          certifications = @certifications,
          caseExperience = @caseExperience,
          notableCases = @notableCases,
          successStories = @successStories,
          officeAddress = @officeAddress,
          facebook = @facebook,
          whatsapp = @whatsapp,
          linkedin = @linkedin,
          Status=@status
        WHERE ID = @lawyerId1
      `;

      await request
        .input('barAffiliation', sql.VarChar(255), form1.barAffiliation || 'NIL')
        .input('barAssociation', sql.VarChar(255), form1.barAssociation || 'NIL')
        .input('name', sql.VarChar(255), form2.name || 'NIL')
        .input('email', sql.VarChar(255), form2.email || 'NIL')
        .input('phone', sql.VarChar(255), form2.phone || 'NIL')
        .input('gender', sql.VarChar(255), form2.gender || 'NIL')
        .input('province', sql.VarChar(255), form2.province || 'NIL')
        .input('city', sql.VarChar(255), form2.city || 'NIL')
        .input('education', sql.VarChar(sql.MAX), form3.education || 'NIL')
        .input('graduationYear', sql.Int, parseInt(form3.graduationYear) || 0)
        .input('LLB', sql.VarChar(255), form3.LLB || 'NIL')
        .input('LLM', sql.VarChar(255), form3.LLM || 'NIL')
        .input('LLD', sql.VarChar(255), form3.LLD || 'NIL')
        .input('currentPosition', sql.VarChar(255), form4.currentPosition || 'NIL')
        .input('durationOfPractice', sql.Int, parseInt(form4.durationOfPractice) || 0)
        .input('lowerCourts', sql.VarChar(sql.MAX), form4.lowerCourts || 'NIL')
        .input('highCourt', sql.VarChar(255), form4.highCourt || 'NIL')
        .input('licenseNumber', sql.VarChar(255), form5.licenseNumber || 'NIL')
        .input('certifications', sql.VarChar(sql.MAX), form5.certifications || 'NIL')
        .input('caseExperience', sql.VarChar(sql.MAX), form5.caseExperience || 'NIL')
        .input('notableCases', sql.VarChar(sql.MAX), form5.notableCases || 'NIL')
        .input('successStories', sql.VarChar(sql.MAX), form5.successStories || 'NIL')
        .input('officeAddress', sql.VarChar(sql.MAX), form6.officeAddress || 'NIL')
        .input('facebook', sql.VarChar(255), form7.facebook || 'NIL')
        .input('whatsapp', sql.VarChar(255), form7.whatsapp || 'NIL')
        .input('linkedin', sql.VarChar(255), form7.linkedin || 'NIL')
        .input('status', sql.VarChar(50), 'pending')
        .input('lawyerId1', sql.Int, lawyerId)
        .query(query);

      console.log("Fetched lawyer ID for this row is:", lawyerId);

      if (lawyerId) {
        // Update PracticeAreas table
        for (const area of form1.areas) {
          const areaValue = area.value;

          await new sql.Request(transaction)
            .input('lawyerId2', sql.Int, lawyerId)
            .input('area', sql.VarChar(255), areaValue)
            .query('UPDATE PracticeAreas SET area = @area WHERE ID = @lawyerId2');
        }

      // Update Consultation Modes
      for (const mode of form6.consultationModes) {
      const fee = form6.consultationFees[mode.value] || null;
      const query = `
        MERGE ConsultationModes AS target
        USING (SELECT @lawyerId AS lawyerId, @mode AS mode) AS source
        ON (target.lawyerId = source.lawyerId AND target.mode = source.mode)
        WHEN MATCHED THEN 
          UPDATE SET fee = @fee
        WHEN NOT MATCHED THEN
          INSERT (lawyerId, mode, fee)
          VALUES (@lawyerId, @mode, @fee);
      `;

      const request = new sql.Request(transaction);
      await request.input('lawyerId', sql.Int, lawyerId)
                   .input('mode', sql.VarChar, mode.value)
                   .input('fee', sql.NVarChar, fee)
                   .query(query);
    }
    

    // Update Office Hours
    for (const [day, { startTime, endTime }] of Object.entries(form6.officeHours)) {
      const query = `
        MERGE OfficeHours AS target
        USING (SELECT @lawyerId AS lawyerId, @dayOfWeek AS dayOfWeek) AS source
        ON (target.lawyerId = source.lawyerId AND target.dayOfWeek = source.dayOfWeek)
        WHEN MATCHED THEN 
          UPDATE SET startTime = @startTime, endTime = @endTime
        WHEN NOT MATCHED THEN
          INSERT (lawyerId, dayOfWeek, startTime, endTime)
          VALUES (@lawyerId, @dayOfWeek, @startTime, @endTime);
      `;

      const request = new sql.Request(transaction);
      await request.input('lawyerId', sql.Int, lawyerId)
                   .input('dayOfWeek', sql.VarChar, day)
                   .input('startTime', sql.VarChar, startTime)
                   .input('endTime', sql.VarChar, endTime)
                   .query(query);
    }



      }

      await transaction.commit();
      console.log("***********Data updated********")
      res.status(200).json({ message: 'Data inserted/updated successfully', data: lawyerId });
    } catch (err) {
      await transaction.rollback();
      console.error('Error inserting/updating data:', err);
      res.status(500).json({ error: 'An error occurred while inserting/updating data' });
    }
  } catch (error) {
    console.error('Error connecting to the database:', error);
    res.status(500).json({ error: 'An error occurred while connecting to the database' });
  } finally {
    pool.close().then(() => console.log('Connection pool closed.'));
  }
});


app.get('/check-lawyer-account', async (req, res) => {
  const username = req.session.userData ? req.session.userData.username : null;

  if (!username) {
    return res.status(400).json({ error: 'User not logged in' });
  }

  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool.request()
      .input('Username', sql.NVarChar, username)
      .query('SELECT Status FROM LawyerSignupData WHERE Username = @Username');

    if (result.recordset.length > 0) {
      const status = result.recordset[0].Status;
      
      if (status === 'Approved') {
        res.json({ hasLawyerAccount: true, status: 'Approved' });
      } else if (status === 'pending') {
        res.json({ hasLawyerAccount: true, status: 'Pending' });
      } else if (status === 'Rejected') {
        res.json({ hasLawyerAccount: true, status: 'Rejected' });
      } else {
        res.json({ hasLawyerAccount: false, status: 'Unknown' });
      }
    } else {
      res.json({ hasLawyerAccount: false, status: 'Not Found' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});

app.get('/get-rejection-reasons', async (req, res) => {
  
  const username = req.session.userData ? req.session.userData.username : null;

  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool.request()
      .input('Username', sql.NVarChar, username)
      .query('SELECT RejectionNotes, rejections FROM LawyerSignupData WHERE Username = @Username');

    if (result.recordset.length > 0) {
      const record = result.recordset[0];
      res.json({
        rejectionNotes: record.RejectionNotes,
        rejections: record.rejections
      });
    } else {
      res.json({
        rejectionNotes: null,
        rejections: null
      });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database error' });
  }
});


app.post('/checkPhoneEmail', async (req, res) => {
  const { phone, email } = req.body;

  if (!phone || !email) {
    return res.status(400).json({ message: 'Phone and email are required' });
  }

  try {
    

    const pool = await sql.connect(dbConfig);
    const phoneResult = await pool.request()
        .input('phone', sql.NVarChar, phone)
        .query('SELECT COUNT(*) AS count FROM LawyerSignupData WHERE phone = @phone');
    const phoneExists = phoneResult.recordset[0].count > 0;


    const emailResult = await pool.request()
         .input('email', sql.NVarChar, email)
         .query('SELECT COUNT(*) AS count FROM LawyerSignupData WHERE email = @email');
    const emailExists = emailResult.recordset[0].count > 0;



    if (phoneExists && emailExists) {
      return res.status(200).json({ message: 'Both phone and email exist' });
    } else if (phoneExists) {
      return res.status(200).json({ message: 'Phone exists' });
    } else if (emailExists) {
      return res.status(200).json({ message: 'Email exists' });
    } else {
      return res.status(200).json({ message: 'Neither phone nor email exists' });
    }

  } catch (error) {
    console.error('Error querying database: ', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/checkPhoneEmail2', async (req, res) => {
  const { phone, email } = req.body;

  if (!phone || !email) {
    return res.status(400).json({ message: 'Phone and email are required' });
  }

  try {
    

    const pool = await sql.connect(dbConfig);
    const phoneResult = await pool.request()
        .input('phone', sql.NVarChar, phone)
        .query('SELECT COUNT(*) AS count FROM LawyerSignupData WHERE phone = @phone');
    const phoneExists = phoneResult.recordset[0].count > 1;


    const emailResult = await pool.request()
         .input('email', sql.NVarChar, email)
         .query('SELECT COUNT(*) AS count FROM LawyerSignupData WHERE email = @email');
    const emailExists = emailResult.recordset[0].count > 1;



    if (phoneExists && emailExists) {
      return res.status(200).json({ message: 'Both phone and email exist' });
    } else if (phoneExists) {
      return res.status(200).json({ message: 'Phone exists' });
    } else if (emailExists) {
      return res.status(200).json({ message: 'Email exists' });
    } else {
      return res.status(200).json({ message: 'Neither phone nor email exists' });
    }

  } catch (error) {
    console.error('Error querying database: ', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});


// Review submission endpoint
app.post('/submit-review', async (req, res) => {
  const { id, rating, category, reviewText } = req.body;
  const username = req.session.userData ? req.session.userData.username : null;
  const lawyerId = id;

  if (!username) {
    return res.status(401).json({ error: 'User not logged in' });
  }

  if (!lawyerId || !rating || !category || !reviewText) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const pool = await sql.connect(dbConfig);

    // Check if a review already exists for this username and lawyerId
    const checkQuery = `
      SELECT COUNT(*) AS reviewCount
      FROM LawyerReviews
      WHERE lawyerId = @lawyerId AND Username = @Username
    `;

    const checkResult = await pool.request()
      .input('lawyerId', sql.Int, lawyerId)
      .input('Username', sql.NVarChar(50), username)
      .query(checkQuery);

    const reviewCount = checkResult.recordset[0].reviewCount;

    if (reviewCount > 0) {
      return res.status(409).json({ error: 'A review already exists from this user for this lawyer' });
    }

    // Insert the new review
    const insertQuery = `
      INSERT INTO LawyerReviews (lawyerId, Username, rating, category, reviewText)
      VALUES (@lawyerId, @Username, @rating, @category, @reviewText);
    `;

    await pool.request()
      .input('lawyerId', sql.Int, lawyerId)
      .input('Username', sql.NVarChar(50), username)
      .input('rating', sql.Int, rating)
      .input('category', sql.NVarChar(255), category)
      .input('reviewText', sql.NVarChar(sql.MAX), reviewText)
      .query(insertQuery);

    res.status(200).json({ message: 'Review submitted successfully' });

    await pool.close();
  } catch (error) {
    console.error('Error submitting review:', error);
    res.status(500).json({ error: 'An error occurred while submitting the review' });
  }
});


app.get('/search-lawyer', async (req, res) => {
  const { lawArea, location, lawyerName } = req.query;

  let query = `
    SELECT 
      l.ID, l.name, l.city, l.currentPosition, l.durationOfPractice, l.lawyerImage, l.barAffiliation, l.netRating,
      p.area,
      (SELECT COUNT(*) FROM LawyerReviews r WHERE r.lawyerId = l.ID) AS totalReviews
    FROM 
      LawyerSignupData l
    LEFT JOIN 
      PracticeAreas p ON l.ID = p.lawyerId
    WHERE 
      l.status = 'Approved'
  `;

  const conditions = [];

  if (lawArea) {
    conditions.push(`p.area LIKE '%${lawArea}%'`);
  }
  if (location) {
    conditions.push(`l.city LIKE '%${location}%'`);
  }
  if (lawyerName) {
    conditions.push(`l.name LIKE '%${lawyerName}%'`);
  }

  if (conditions.length > 0) {
    query += ' AND ' + conditions.join(' AND ');
  }

  query += `
    GROUP BY
      l.ID, l.name, l.city, l.currentPosition, l.durationOfPractice, l.lawyerImage, l.barAffiliation, l.netRating, p.area
    ORDER BY
      (YEAR(GETDATE()) - CAST(l.durationOfPractice AS INT)) DESC, l.netRating DESC, l.name ASC;
  `;

  console.log("Search Query found::", query);

  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool.request().query(query);
    
    if (result.recordset.length === 0) {
      res.status(404).send('No matching records found');
    } else {
      res.status(200).json(result.recordset);
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});



// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
