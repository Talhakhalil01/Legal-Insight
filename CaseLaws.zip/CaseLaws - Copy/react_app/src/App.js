import React, { useState, useEffect } from 'react';
import './styles/App.css';
import './index.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import LandingPage from './LandingPageFiles/src/LandingPage';
import Home from './components/Home';
import Signup from './components/signup';
import Signin from './components/signin';
import { TableProvider } from './components/TableContext';
import Bookmarks from './components/Bookmarks';
import { UserProvider } from './components/UserContext';
import { BookmarksProvider } from './components/BookmarksContext';
import { FormProvider } from './components/FormContext';
import { FormProvider2 } from './components/EditForms/Edit_FormContext';
import { DataProvider, useFormContext2 } from './components/ProfileDataContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Guidance from './components/LawyerSignupGuide';
import Register from './components/LawyerPersonal';
import Register2 from './components/LawyerPersonal2';
import Professional from './components/LawyerProfessional';
import Professional2 from './components/LawyerSignup4';
import Professional3 from './components/LawyerSignup5';
import Professional4 from './components/LawyerSignup6';
import Professional5 from './components/LawyerSignup7';
import Thankyou from './components/ThanKyouForm.js';

import Edit_Register from './components/EditForms/Edit_LawyerPersonal';
import Edit_Register2 from './components/EditForms/Edit_LawyerPersonal2';
import Edit_Professional from './components/EditForms/Edit_LawyerProfessional';
import Edit_Professional2 from './components/EditForms/Edit_LawyerSignup4';
import Edit_Professional3 from './components/EditForms/Edit_LawyerSignup5';
import Edit_Professional4 from './components/EditForms/Edit_LawyerSignup6';
import Edit_Professional5 from './components/EditForms/Edit_LawyerSignup7';

import View from './components/ProfileView';
import RejectedMessage from './components/Rejected';



import Search from "./Profiling/Search";
import Profile from "./Profiling/Profile";


import axios from 'axios';
import { useNavigate } from 'react-router-dom';










function App() {
  
  return (
    <BrowserRouter>
    <TableProvider>
    <FormProvider>
    <FormProvider2>
    <DataProvider>
     <BookmarksProvider>
      <UserProvider>
        <Routes>
              <Route path="/" element={<LandingPage/>} />
              <Route path="/caselaw" element={<Home/>} />
              <Route path="/signup" element={<Signup/>} />
              <Route path="/signin" element={<Signin/>} />
              <Route path="/bookmark" element={<Bookmarks/>}/>

              <Route path="/lawyerGuide" element={<Guidance/>}/>
              <Route path="/lawyerSignup" element={<Professional/>}/>
              <Route path="/lawyerSignup2" element={<Register/>}/>
              <Route path="/lawyerSignup3" element={<Register2/>}/>
              <Route path="/lawyerSignup4" element={<Professional2/>}/>
              <Route path="/lawyerSignup5" element={<Professional3/>}/>
              <Route path="/lawyerSignup6" element={<Professional4/>}/>
              <Route path="/lawyerSignup7" element={<Professional5/>}/>
              <Route path="/thankyou" element={<Thankyou/>}/>

              <Route path="/editlawyerSignup" element={<Edit_Professional/>}/>
              <Route path="/editlawyerSignup2" element={<Edit_Register/>}/>
              <Route path="/editlawyerSignup3" element={<Edit_Register2/>}/>
              <Route path="/editlawyerSignup4" element={<Edit_Professional2/>}/>
              <Route path="/editlawyerSignup5" element={<Edit_Professional3/>}/>
              <Route path="/editlawyerSignup6" element={<Edit_Professional4/>}/>
              <Route path="/editlawyerSignup7" element={<Edit_Professional5/>}/>

              <Route path="/view" element={<View/>}/>
             <Route path="/rejected" element={<RejectedMessage />} />

              <Route path="/search" element={<Search />} />
              <Route path="/profile" element={<Profile />} />
              
        </Routes>
        <ToastContainer
          position="top-center"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
          style={{ width: '400px' }} 
          />
      </UserProvider>
      </BookmarksProvider>
      </DataProvider>
      </FormProvider2>
      </FormProvider>
     </TableProvider>
    </BrowserRouter>
  )
}

export default App;
