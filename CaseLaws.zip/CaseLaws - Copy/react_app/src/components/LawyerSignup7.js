import React, { useState,useEffect,useRef  } from "react"
import "../styles/LawyerSignup7.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import Select from 'react-select';
import defaultImageIcon from '../styles/images/blank-design2.jpg';
import PhoneInput, { formatPhoneNumber, formatPhoneNumberIntl, isValidPhoneNumber,isPossiblePhoneNumber } from 'react-phone-number-input'
import { GrValidate } from "react-icons/gr";
import { RxCross1 } from "react-icons/rx";
import { useFormContext } from "./FormContext"; 
import { FaCloudUploadAlt } from "react-icons/fa";
import { LuBadgeX } from "react-icons/lu";
import { ToastContainer, toast } from 'react-toastify';
import ClipLoader from "react-spinners/MoonLoader";




const Register = () => {
  
  const navigate = useNavigate();
  const { state, dispatch,fetchDataAndSendToServer } = useFormContext();
  const [loading, setLoading] = useState(false);
  const [ImageURL,setImageURL]=useState(null)
  const mounted = useRef(false);
  const [isFormSubmitted, setIsFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
      lawyerImage:null,
      facebook:"",
      whatsapp:"+92",
      linkedin:""
  });


   const handleFrontImageChange = (e) => {
       const imageFile = e.target.files[0];
  
        // Validate image file type (optional)
        if (!imageFile || !imageFile.type.match('image/*')) {
           toast.error('Please select a valid image file.');
           return;
        }
    
        // Update form data state
        setFormData({ ...formData, lawyerImage: imageFile });
    
        // Create image preview URL and update preview state
        const reader = new FileReader();
        reader.onload = (event) => {
        setImageURL(event.target.result);
        };
        reader.readAsDataURL(imageFile);
  };

 const isValidUrl =(url)=> {
    // Regular expression to match URL format
    const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
  
    // Test the URL against the regex
    return urlRegex.test(url);
  }
  
 
  const extractImageData = () => {
    const imageData = [];
    const finalData = state;
  
    // Loop through each form object
    for (const [formName, fd] of Object.entries(finalData)) {
      // Access image properties within each form
      const formImages = [];
  
      // Check for 'barCardImages' in form1
      if (formName === 'form1' && fd.barCardImages) {
        formImages.push({
          label: 'FrontBarCard',
          file: fd.barCardImages.frontImage,
        });
        formImages.push({
          label: 'BackBarCard',
          file: fd.barCardImages.backImage,
        });
      }
  
      // Check for 'degrees' in form3
      if (formName === 'form3' && fd.degrees) {
        formImages.push({
          label: 'LLBDegree',
          file: fd.degrees.LLBdegree,
        });
        formImages.push({
          label: 'LAWGATResult',
          file: fd.degrees.LAWGATresult,
        });
      }
     
        if (formName === 'form4' && fd.certificates) {
        formImages.push({
          label: 'CertificateImage',
          file: fd.certificates.certificateImage,
        });
        formImages.push({
          label: 'ApprovalImage',
          file: fd.certificates.approvalImage,
        });
      }
      // Check for 'degrees' in form3
      if (formName === 'form7' && fd.lawyerImage) {
        formImages.push({
          label: 'ProfileImage',
          file: fd.lawyerImage,
        });
      }
    
  
      imageData.push(...formImages);
    }
    return imageData;
  };
  const SubmitData = async () => {
    const imageData = extractImageData();
    const finalData = state;
    if(finalData && imageData)
     { 

         console.log("Form data is::",finalData)
         
         try {
             axios.defaults.withCredentials = true;
             const response = await axios.post('http://localhost:5000/submit-lawyer-data',finalData)
             console.log(response.data); 
             
            const lawyerId = response.data.data; // Extract lawyerId from response
            console.log("Lawyer ID:", lawyerId);
            // Iterate through images and append lawyerId to filenames
            const images = new FormData();
            imageData.forEach(image => {
                const fileExtension = image.file.name.split('.').pop(); // Extract file extension
                const fileName = `${lawyerId}_${image.label}.${fileExtension}`; // Concatenate label and extension
                images.append('images', image.file,fileName);
            });
            
            console.log("Images are:::",images.getAll('images'))
            // Now submit the updated images to /upload endpoint
            const uploadResponse = await axios.post('http://localhost:5000/upload', images);
            console.log(uploadResponse.data); // Handle upload response

            if (response.status === 200) {
              
                  await axios.post('http://localhost:5000/send-email', {
                      email: finalData.form2.email,
                  });
                 
                  
                  toast.success("Form submitted successfully");

                  setLoading(false);
                  dispatch({ type: 'RESET_FORM' });
                  navigate('/thankyou')
                  
          }

         } 
         catch (error) {
             console.error(error);
             setLoading(false);
             toast.error('Error submitting data');
         }
    }
    else{
     console.log("Image data is null")
    }
   };
   
  useEffect(() => {
    if (isFormSubmitted) {
      
       SubmitData();

      setIsFormSubmitted(false);
    }
    else{
      console.log("False value")
    }
    
  }, [state.form7]);


const handlenextpage =  async(e) => { 
    e.preventDefault();
    
    

    if (!isValidPhoneNumber(formData.whatsapp) ) 
    {
           toast.error("Whatsapp number is not valid")     
           return; 
        
    }
    if (formData.facebook && !isValidUrl(formData.facebook)) 
    {
        toast.error("Facebook url is not valid")  
        return;
        
    }
    if (formData.linkedin && !isValidUrl(formData.linkedin)) 
    {
        toast.error("Linkedin url is not valid")  
        return;
        
    }
    setLoading(true);
    
   
    setIsFormSubmitted(true);
    await dispatch({ type: 'UPDATE_FORM_7', payload: formData });
    console.log("Is form submitted value is:", isFormSubmitted);

    
    setTimeout(() => {
      setLoading(false) 
  }, 500);

    
    
  
             
}
  

    return (
    <div className="signup-wrapper7">
      <div className="wrapper7">
        <form onSubmit={handlenextpage}>
          <h1>Lawyer Signup</h1>
         
          <div className="input-box7" id="img1">
                <label id="label-image1">Upload a your formal image:</label>
                <input
                    type="file"
                    id="uploadBtn"
                    onChange={handleFrontImageChange}
                    required
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>
               
              
            
             {ImageURL ? (
                <img className="image" src={ImageURL} alt="Lawyer Image" />
                ):(
                    <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
                )}
            </div>

            <div className="input-box7" id="input3">
            <label>Enter your WhatsApp number:</label>
            <input
                type="tel"
                name="whatsapp"
                value={formData.whatsapp}
                onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                placeholder="WhatsApp Number"
                required
            />
            {formData.whatsapp && formData.whatsapp.length > 3 && (
                  <div className="extra">
                      {isValidPhoneNumber(formData.whatsapp) ? (
                          <>
                              <GrValidate className="tick" /> 
                              <span className="valid-message">Valid Phone number</span>
                          </>
                      ) : (
                          <>
                              <LuBadgeX className="cross" />
                              <span className="invalid-message">Invalid Phone number</span>
                          </>
                      )}
                  </div>
              )}
            </div>

            <div className="input-box7" id="input2">
            <label>Enter your Facebook Profile Link(if any):</label>
            <input
                type="url"
                name="facebook"
                value={formData.facebook}
                onChange={(e) => setFormData({ ...formData, facebook: e.target.value })}
                placeholder="Facebook profile link"
            />
            </div>
          
            <div className="input-box7" id="input5">
            <label>Enter your LinkedIn Profile Link(if any):</label>
            <input
                type="url"
                name="linkedin"
                value={formData.linkedin}
                onChange={(e) => setFormData({ ...formData, linkedin: e.target.value })}
                placeholder="LinkedIn profile link"
            />
            </div>

            {loading ? (
        <div className="loading-spinner">
               <ClipLoader
                  color={"#007bff"}
                  loading={loading}
                  size={100}
                />
            </div>
          ) : (
            <button type="submit">Create Profile</button>
          )}

          <div className="register-link7">
            <p>Form 7 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;