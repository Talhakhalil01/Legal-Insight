import React, { useState } from 'react';
import '../styles/Searchbar.css';
import '../styles/central.css';
import { useTable } from './TableContext';
import { BsSearch } from "react-icons/bs";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';



const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { tableData, updateTableData } = useTable()
  const { queryData, updateQueryData } = useTable()
  const {search, updateSearch} = useTable();
  const {loading2, updateLoading} = useTable();

  const handleSearch = async (e) => {
    e.preventDefault();


    const words = searchQuery.trim().split(/\s+/);
    if (words.length > 50) {
      toast.error("Search query should not exceed 70 words.");
      return;
    }

    updateQueryData(searchQuery);
    updateLoading(true);
   

    try {
      const response = await fetch('http://localhost:5000/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ searchQuery }),
      });

      if (!response.ok) {
        throw new Error('Server error');
        updateTableData([]);
      }
      else
      {
          const searchData = await response.json();
          console.log("Data received at searchbar.js:", searchData.length);
          
          updateTableData(searchData);
          updateSearch("MainSearchbar")

          updateLoading(false);
          
          
          
      }

    } catch (error) {
      console.error('Error during search:', error.message);
      updateLoading(false);
      // Pass searchData as null to indicate an error
      updateTableData([]);
    }
  };

  return (
  
    <form onSubmit={handleSearch} className="search-bar">

    <div className='search-bar-container'>
          <input
            className='search'
            type="text"
            id="searchInput"
            placeholder="Search here for judgments"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            required
          />
      <BsSearch className="search-icon" />

      </div>

      <button type="submit" className='searchbtn'>Search</button>
    </form>

  );
};

export default SearchBar;
