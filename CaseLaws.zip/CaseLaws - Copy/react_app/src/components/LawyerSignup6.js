import React, { useState,useEffect } from "react"
import "../styles/LawyerSignup6.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import  TimePicker from 'react-time-picker';
import Select from 'react-select';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import { MdExpandLess } from "react-icons/md";
import { MdExpandMore } from "react-icons/md";
import ClipLoader from "react-spinners/MoonLoader";
import { useFormContext } from "./FormContext"; 





const Register = () => {
  
  const navigate = useNavigate();
  const { state, dispatch } = useFormContext();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
 
  const [formData, setFormData] = useState({
   officeAddress:"",
   officeHours: {
    Monday: { startTime: "09:00", endTime: "17:00" },
    Tuesday: { startTime: "09:00", endTime: "17:00" },
    Wednesday: { startTime: "09:00", endTime: "17:00" },
    Thursday: { startTime: "09:00", endTime: "17:00" },
    Friday: { startTime: "09:00", endTime: "17:00" },
    Saturday: { startTime: "00:00", endTime: "00:00" },
    Sunday: { startTime: "00:00", endTime: "00:00" }
  },
   consultationModes: [],
   consultationFees: {},


  });

  const consultationOptions = [
    { value: 'In-Person', label: 'In-Person' },
    { value: 'VideoCall', label: 'Video Call' },
    { value: 'PhoneCall', label: 'Phone Call' },
   ];
   useEffect(() => {
    // Update formData state with values from formContext when component mounts
    setFormData(state.form6);
  }, []); 

  const handleTimeChange = (day, field, time) => {
    setFormData(prevState => ({
        ...prevState,
        officeHours: {
          ...prevState.officeHours,
          [day]: {
            ...prevState.officeHours[day],
            [field]: time
          }
        }
      }));
  };


 
  const [showOptions, setShowOptions] = useState(false);

  const toggleAdvanceOptions = () => {
    setShowOptions(!showOptions);
  };
  const handleModeChange = (selectedOptions) => {
    const consultationFees = {};
    selectedOptions.forEach((option) => {
      consultationFees[option.value] = '';
    });
    setFormData({ ...formData, consultationModes: selectedOptions, consultationFees });
  };

  const handleFeeChange = (mode, fee) => {
    setFormData({
      ...formData,
      consultationFees: {
        ...formData.consultationFees,
        [mode]: fee,
      },
    });
  };
  const handlenextpage =  async (e) => {
    e.preventDefault();
  
    if (!formData.officeAddress || formData.officeAddress.length < 5) {
        setFormData(prevData => ({ ...prevData, officeAddress: 'Nil' }));
      }
  
    // Update context with form data
    dispatch({ type: 'UPDATE_FORM_6', payload: formData });
  
    setLoading(true);
    setTimeout(() => {
        console.log("Form 6:",formData)
      // Navigate to the next page
      navigate('/lawyerSignup7');
    }, 500);
    
  }
    return (
    <div className="signup-wrapper6">
      <div className="wrapper6">
        <form onSubmit={handlenextpage}>
          <h1>Lawyer Signup</h1>
          <div className="input-box6" id="input1">
                <label id="label1">Enter your office address(if any):</label>
                <input
                    type="text"
                    name="officeAddress"
                    value={formData.officeAddress}
                    onChange={(e) => setFormData({ ...formData, officeAddress: e.target.value })}
                    placeholder="Office name,Street,City,Province,Postal Code,Country"
                    
                />
            </div>
            <div className="input-box6" id="input2">
                <label>Enter your office hours:</label>
                <button className="hour-btn" type="button" onClick={toggleAdvanceOptions}>Enter your office-hours</button>
                {showOptions ? (
                    <MdExpandLess className="icon6"/> ):(<MdExpandMore className="icon6"/>)}

            </div>
        {showOptions && (
            <div className="office-hours">
                {Object.keys(formData.officeHours).map(day => (
                <div key={day} className="timepicker-wrapper">
                    <label className="day-label">{day}</label>
                
                </div>
                ))}
                {Object.keys(formData.officeHours).map(day => (
                <div key={day} className="timepicker-wrapper2">
                    <TimePicker
                    className="timepicker"
                    format="HH:mm"
                    disableClock={true}
                    clearIcon={null}
                    onChange={time => handleTimeChange(day, "startTime", time)}
                    value={formData.officeHours[day].startTime}
                 
                    />
                    <span className="to">to</span>
                    <TimePicker
                    className="timepicker2"
                    format="HH:mm"
                    disableClock={true}
                    clearIcon={null}
                    onChange={time => handleTimeChange(day, "endTime", time)}
                    value={formData.officeHours[day].endTime}
                 
                    />
                
                </div>
                ))}
            </div>)}
            
           
            <div className="input-box6" id="modes">
                <label>Select your consultation modes:</label>
               
                
            </div>
            
             <Select
                    className="reactselect2"
                    name="appointmentType"
                    value={formData.consultationModes}
                    onChange={handleModeChange}
                    options={consultationOptions}
                    isMulti
                    placeholder="Select Consultation Modes"
                    required
                />
           
            <div className="input-box6" id="fees">
                {/* <label>Enter fees for each mode:</label> */}
               
                {formData.consultationModes.map((mode) => (
                    <div key={mode.value} className="modes-fees">
                    <label htmlFor={mode.value} className="small-label">Fee for {mode.label} mode:</label>
                    <input
                        type="number"
                        id={mode.value}
                        value={formData.consultationFees[mode.value]}
                        onChange={(e) => handleFeeChange(mode.value, e.target.value)}
                        className="small-input"
                        placeholder="Enter Fee"
                        required
                    />
                    </div>
                ))}
            </div>
          
            {loading ? (
        <div className="loading-spinner">
               <ClipLoader
                  color={"#007bff"}
                  loading={loading}
                  size={100}
                />
            </div>
          ) : (
            <button type="submit">Next</button>
          )}
          <div className="register-link6">
            <p>Form 6 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;

