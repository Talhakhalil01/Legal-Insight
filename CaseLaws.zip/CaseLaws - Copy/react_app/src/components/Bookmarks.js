import React, { useState,useEffect } from 'react';
import './Bookmarks.css';
import Judgement from './Judgement';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { useTable } from './TableContext';
import { useBookmarks } from './BookmarksContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useUser } from './UserContext';
import ClipLoader from "react-spinners/MoonLoader";



const Bookmarks = () => {
    
  const [selectedJudgement, setSelectedJudgement] = useState(null);
  const [searchButtonClicked, setSearchButtonClicked] = useState(false);
  const[userData,setuserData]=useState('');
  const navigate = useNavigate()
  const{bookmarkedCases}=useBookmarks();
  const [tabledata, setTableData] = useState(bookmarkedCases);
  const { userdata, login, logout } = useUser();


  const openJudgementModal = (judgement) => {
    setSelectedJudgement(judgement);
  };

  const closeJudgementModal = () => {
    setSelectedJudgement(null);
  };
  
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
    
        if (response.data.valid) {
            setuserData(response.data.userData);

        } else {
          setuserData(null);
          toast.error("User not logged-In")
          navigate("/")

          
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        return null;
      }
    };
    fetchCurrentUser();
    
  }, [userdata]);

        const handleupdatebookmark = async () => {
              const userName=userData.username;
              console.log("Logged in user::",userName);
              try {
                // Send a POST request to the server to save the bookmark
                const response = await fetch('http://localhost:5000/fetch', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify({userName}),
                });
      
              
              if (!response.ok) {
                   toast.error("No recors exists for the login account")
                   setTableData(null);
              }
              else
              {
                const searchData = await response.json(); // Use await response.json() to parse the JSON response
                setTableData(searchData);
                
              }
            } catch (error) {
              console.error('Error fetching updated bookmarked cases:', error);
              setTableData(null);    
            }
            
          
        };
  // Function to handle deleting a bookmark
  const handleUnbookmark = async (caseNo) => {
    try {
      const username = userData.username;

      // Assuming your server is running on http://localhost:5000
      const response = await fetch(`http://localhost:5000/api/bookmarks`, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ caseNo, userName: userData.username }), // Pass both user email and caseNo in the request body
      });

      if (response.ok) {
          // Successful deletion, update the UI or fetch updated data
          // alert('Bookmark deleted successfully');
          toast.success("Bookmark deleted successfully")
          handleupdatebookmark();

          
      } else {
        // Handle error, log or show a message to the user
        console.error('Error in deleting bookmark:', response.statusText);
      }
    } catch (error) {
      console.error('Error deleting bookmark:', error.message);
    }
  };



  if (!tabledata || (tabledata.length === 0 && searchButtonClicked)) {
    return( 
      <div className='bookmarks'>
      <h1>Your Bookmarked Cases</h1>
          <div className="table-container2">
          <div className="error2">No bookmarks found</div>
      </div>
      </div>
    );
  }
    return (
      <div className='bookmarks'>

      <div className='top-bar'><h1>Your Bookmarked Cases</h1></div>
      <div className="table-container2">
      {/* <div className="options"></div> */}
        <div className="records-found2">
          Total bookmarks: {tabledata.length}
        
      </div>

      <div className="table2">
      
        {tabledata.length > 0 && (
          
          <table>
            <thead>
              <tr>
                <th className='th'>Sr No.</th>
                <th className='th'>Case no.</th>
                <th className='th'>Case Subject</th>
                <th className='th'>Case Title</th>
                <th className='th'>Author Judge</th>
                <th className='th'>Court</th>
                <th className='th'>Judgement Date</th>
                <th className='th'>Citation</th>
                <th className='th'>Judgement</th>
                <th className='th'>UnBookmark</th>
              </tr>
            </thead>
            <tbody>
              {tabledata.map((row, index) => (
                <React.Fragment key={index}>
                  <tr>
                    <td className='td'>{index + 1}</td>
                    <td className='td'>{row.CaseNo}</td>
                    <td className='td'>{row.CaseSubject}</td>
                    <td className='td'>{row.CaseTitle}</td>
                    <td className='td'>{row.AuthorJudge}</td>
                    <td className='td'>{row.Court}</td>
                    <td className='td'>{row.JudgementDate}</td>
                    <td className='td'>{row.Citation}</td>
                    <td><button className="opencaselaw2" onClick={() => openJudgementModal(row.Judgement)}>
                      Read Full Text</button></td>
                      <td>
                      <button className='bookmark2' onClick={() => handleUnbookmark(row.CaseNo)}>Unbookmark</button>
                    </td>
                  </tr>
                  <tr>
                    <td colSpan="10" className='tagline2'>{row.Tagline ? ("Tagline: " + row.Tagline) : (null)}</td>
                  </tr>
                </React.Fragment>
              ))}
            </tbody>
          </table>
        )}
        {selectedJudgement && (
          <Judgement judgement={selectedJudgement} onClose={closeJudgementModal} />
        )}
      </div>
    </div>
    
    </div>
  );

};

export default Bookmarks;
