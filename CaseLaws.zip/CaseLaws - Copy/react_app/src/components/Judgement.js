// Judgement.js
import React from 'react';
import '../styles/judgement.css';


const Judgement = ({ judgement, onClose }) => {
  return (
    <div className="judgement-popup">
      <div className="judgement-content">
        <button className="close" onClick={onClose}>&times;</button>
        <h2>Full Text of the Judgment</h2>
        <p className='text'>{judgement}</p>
      </div>
    </div>
  );
};

export default Judgement;
