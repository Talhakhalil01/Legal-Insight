import React, { useState,useEffect } from 'react';
import SearchBar from './SearchBar';
import AdvanceSearchBar from './AdvanceSearchBar';
import NavBar from './Navbar.jsx'; 
import Table from './Table';
import { useTable } from './TableContext';
import '../styles/Home.css';
import '../styles/Searchbar.css';
import '../styles/advancesearchbar.css';
import '../styles/Table.css';
import '../styles/central.css';
import ClipLoader from "react-spinners/ClipLoader";
import { Outlet } from 'react-router-dom';

 const Home=()=> {

  const [loading , setLoading] = useState(false);


  useEffect(() => {
    setLoading(true); 
    setTimeout(() => {
       setLoading(false);
    }, 200); 
  }, []);


  return (
            

                <div className="home-container">
                  <div className="navbar"><NavBar/></div>
                  <div className="searchbar"><SearchBar/></div>
                  <div className="Table"><Table/></div>
                </div>
           
  
  );
}
export default Home;

