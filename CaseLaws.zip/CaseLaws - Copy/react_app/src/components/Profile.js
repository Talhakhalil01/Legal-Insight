import React, { useState,useEffect } from "react"
import '../styles/Profile.css';
import { useNavigate, useLocation } from "react-router-dom";
import axios from 'axios';
import { useUser } from './UserContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { MdOutlineLogout } from "react-icons/md";
import { BiLogOut } from "react-icons/bi";
import { LuLogIn } from "react-icons/lu";
import { BiLogIn } from "react-icons/bi";
import { TbArrowsExchange } from "react-icons/tb";
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css




const Profile=()=> {

  const[userData,setuserData]=useState('');
  const { userdata, login, logout } = useUser();
  const navigate = useNavigate()
  const location = useLocation(); // Get current location
 


  const handleLogout = async () => {
    if (!userdata) {
      toast.error('User not logged in');
      console.log("User data is::", userdata);
    } else {
      confirmAlert({
        // title: 'Confirm to submit',
        message: 'Are you sure you want to logout?',
        buttons: [
          {
            label: 'Yes',
            onClick: async () => {
              try {
                axios.defaults.withCredentials = true;
                const response = await axios.post('http://localhost:5000/logout');
                if (response.data.success) {
                  toast.success("Logged out successfully");
                  logout(); // Update user data context on successful logout
                  setuserData(null);
                } else {
                  console.error('Logout failed:', response.data.message);
                  alert('Logout failed');
                }
              } catch (error) {
                console.error('Error during logout:', error.message);
              }
            }
          },
          {
            label: 'No',
            onClick: () => {}
          }
        ]
      });
    }
  };
  
  const signInToAnotherAccount = () => {
    const currentPath = location.pathname.substring(1); // Remove leading slash
    navigate(`/signin?redirectTo=${currentPath}`);
  };

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
    
        if (response.data.valid) {
            setuserData(response.data.userData);
            login(response.data.userData)
        } else {
          setuserData(null);

        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        return null;
      }
    };
    fetchCurrentUser();
    
  }, [userdata]);
 


  return (
    <div className="profile-content2">
      <h2 className="heading">Account Details</h2>
      <p className='username'>
        <strong>Username:</strong> {userData ? userData.username : 'undefined'}
      </p>
      <p className='email'>
        <strong>Email:</strong> {userData ? userData.email : 'undefined'}
      </p>
      <button className="Logout" onClick={handleLogout}><BiLogOut className="profile-logo"/> <span className="btn-text">Sign out</span></button>
      
      <button className="Signin" onClick={signInToAnotherAccount}><TbArrowsExchange className="profile-logo"/> <span className="btn-text">Change Account</span></button>
    </div>
  );
}



export default Profile;
