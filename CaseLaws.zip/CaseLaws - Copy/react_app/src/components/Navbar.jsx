import { useState, useEffect } from "react";
// import '../LandingPageFiles/src/components/styles/Navbar.css'; 
import './Navbar.css'; 
import { useNavigate } from 'react-router-dom';
import '../styles/central.css';
import Profile from './Profile';
import axios from 'axios';
import { useUser } from './UserContext';
import { useBookmarks } from './BookmarksContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useFormContext } from "./EditForms/Edit_FormContext"; 
import { RiAccountCircleFill } from "react-icons/ri";
import { BsFillBookmarksFill } from "react-icons/bs";



const Navbar = () => {
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();
  const [userData, setUserData] = useState('');
  const { userdata } = useUser();
  const { updateBookmarkedCases } = useBookmarks();
  const { state, dispatch } = useFormContext();

  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  const closePopup = () => {
    setShowPopup(false);
  };

 

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
        if (response.data.valid) {
          setUserData(response.data.userData);
        } else {
          setUserData(null);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchCurrentUser();
  }, [userdata]);

  const handleBookmark = async () => {
    if (userData) {
      const userName = userData.username;
      try {
        const response = await fetch('http://localhost:5000/fetchcases', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userName }),
        });
        if (!response.ok) {
          toast.info("No record exists for this account");
        } else {
          const searchData = await response.json();
          updateBookmarkedCases(searchData);
          navigate('/bookmark');
        }
      } catch (error) {
        console.error('Error fetching bookmarked cases:', error);
        updateBookmarkedCases(null);
      }
    } else {
      toast.error("Please login first");
      navigate(`/signin?redirectTo=bookmark`);
    }
  };

  return (
    <nav className="navbar1">
      <div className="navbar-container2">
        <div className="navbar-inner">
          <div className='mylogo2'></div>
          <div className="navbar-actions">
            <button className="bookmark-button" onClick={handleBookmark}><BsFillBookmarksFill className="bookmark-icon" /> Bookmarks</button>
            <button className={`login-button ${userData ? 'logged-in' : 'logged-out'}`} onClick={togglePopup}>
              <RiAccountCircleFill className="login-icon" />
            </button>
           
          </div>
          {showPopup && (
            <div className="popup-overlay" onClick={closePopup}>
              <div className="popup" onClick={(e) => e.stopPropagation()}>
                <Profile />
              </div>
            </div>
          )}
        </div>
      </div>
      <ToastContainer />
    </nav>
  );
};

export default Navbar;
