import React, { useState,useEffect } from 'react';
import '../styles/navbar.css';
import '../styles/central.css';
import Profile from './Profile'; // Import your Profile component
import { useNavigate } from "react-router-dom";
import { useBookmarks } from './BookmarksContext';
import axios from 'axios';
import { useUser } from './UserContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useFormContext } from "./EditForms/Edit_FormContext"; 

const NavBar =() => {
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();
  const[userData,setuserData]=useState('');
  const { userdata } = useUser();
  const {updateBookmarkedCases}=useBookmarks();
  const { state, dispatch } = useFormContext();
  
  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  const closePopup = () => {
    setShowPopup(false);
  };
  const handleSignup = () => {
    if(userData)
    {
      navigate('/lawyerGuide')
    }
    else{
     
      toast.error("Please login into your main account first");
      navigate(`/signin?redirectTo=lawyerGuide`);
    }
  };
  const handleEdit = () => {
        if (userData) {
              //  navigate('/editlawyerSignup')
              const fetchProfileData = async () => {
                try {
                  const response = await axios.get('http://localhost:5000/fetch-profile');
                  const { profileData, practiceAreas, consultationModes, officeHours, images } = response.data;
           
                  console.log("Profile:",profileData)
                  console.log("Practice areas:",practiceAreas)
                  console.log("Consultation modes:",consultationModes)
                  console.log("Office hours:",officeHours)
                  // console.log("Images:",images)

                  // Dispatch action to update fetched data
                  await dispatch({ type: 'UPDATE_FETCHED_DATA', payload: { profileData, practiceAreas, consultationModes, officeHours, images } });
                  toast.success("Data fetched successfully")

                  // navigate('/editlawyerSignup')
                } catch (error) {
                  toast.error('Error fetching profile data', error);
                  
                }
              };
          
              fetchProfileData();
              
        } else {
          toast.error("Please login into your main account first");
          navigate(`/signin?redirectTo=editlawyerSignup`);
        }
      };
    const handleFind=()=>{
      navigate('/search')
    }
  

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
    
        if (response.data.valid) {
            setuserData(response.data.userData);
            
        } else {
          setuserData(null);

        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        return null;
      }
    };
    fetchCurrentUser();
    
  }, [userdata]);

    const handlebookmark = async () => {
      if (userData) {
          const userName=userData.username;
          try {
            // Send a POST request to the server to save the bookmark
            const response = await fetch('http://localhost:5000/fetchcases', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({userName}),
            });
  
          
          if (!response.ok) {
              
              toast.info("No record exists for this account")
          }
          else
          {
            const searchData = await response.json(); // Use await response.json() to parse the JSON response
            updateBookmarkedCases(searchData);
            console.log("Bookmarks rows:",searchData.length," for username:",userData.username)
            navigate('/bookmark');
            

          }
        } catch (error) {
          console.error('Error fetching bookmarked cases:', error);
          updateBookmarkedCases(null);

        }
        
      } else {
        toast.error("Please login first")
        navigate(`/signin?redirectTo=bookmark`);
      }
    };
  return (
    <div className='nav-bar'>
      <div className='mylogo'></div>
      <button className="bookmark-button" onClick={handlebookmark}>Bookmarked Cases</button>
      <button className="login-button" onClick={togglePopup}></button>
      {/* <button className="login" onClick={handleSignup}>Create Lawyer Profile</button>
      <button className="edit" onClick={handleEdit}>Edit Profile</button>
      <button className="find" onClick={handleFind}>Find Lawyer</button> */}
      {showPopup && (
        <div className="popup-overlay" onClick={closePopup}>
          <div className="popup" onClick={(e) => e.stopPropagation()}>
            <Profile />
          </div>
        </div>
      )}
    </div>
  );
};

export default NavBar;
