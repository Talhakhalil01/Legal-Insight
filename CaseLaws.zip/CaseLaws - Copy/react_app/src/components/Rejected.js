import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useUser } from './UserContext';
import { useNavigate } from 'react-router-dom';
import { ImCross } from "react-icons/im";
import '../styles/rejection.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useFormContext } from "./EditForms/Edit_FormContext"; 
import { useFormContext2 } from "./ProfileDataContext"; 

const RejectedMessage = () => {
  const { userdata } = useUser();
  const [rejectionData, setRejectionData] = useState({ rejectionNotes: '', rejections: '' });
  const navigate = useNavigate();
  const { state, dispatch } = useFormContext();

  useEffect(() => {
    const fetchRejectionReasons = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000/get-rejection-reasons');
        setRejectionData(response.data);
        console.log("Rejection data we received:", response.data);
      } catch (error) {
        console.error('Error fetching rejection reasons:', error);
      }
    };

    fetchRejectionReasons();
  }, [userdata]);

  const handleEdit = () => {
    //  navigate('/editlawyerSignup')
    const fetchProfileData = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000/fetch-profile');
        const { profileData, practiceAreas, consultationModes, officeHours, images } = response.data;
 

        await dispatch({ type: 'UPDATE_FETCHED_DATA', payload: { profileData, practiceAreas, consultationModes, officeHours, images } });
        toast.success("Data fetched successfully")

        navigate('/editlawyerSignup')
      } catch (error) {
        toast.error('Error fetching profile data', error);
        
      }
    };

    fetchProfileData();
    
};

  return (
    <div className="rejected-message-container">
      <div className="rejected-message-header">
      <div className="cross-icon-container">
          <ImCross />
        </div>
        <h1>Profile Rejected</h1>
        
      </div>
      <p>Hey {userdata.username}, your profile has been rejected for the following reasons:</p>
      <div className="rejection-details">
        <h3>Forms Rejected:</h3>
        <p>{rejectionData.rejections}</p>
      </div>
      <div className="rejection-details">
        <h3>Rejection Notes:</h3>
      {rejectionData.rejectionNotes ?
        <p>{rejectionData.rejectionNotes}</p>
      :
      <p>Nil</p>}
      </div>
      <button onClick={handleEdit}>Edit Profile</button>
    </div>
  );
};

export default RejectedMessage;
