import React, { useState,useEffect } from "react"
import "../styles/LawyersSignup.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { IoMdCall } from "react-icons/io";
import { HiBuildingOffice2 } from "react-icons/hi2";
import { ImCross } from "react-icons/im";
import { GrValidate } from "react-icons/gr";
import { RxCross1 } from "react-icons/rx";
import ClipLoader from "react-spinners/MoonLoader";
import 'react-phone-number-input/style.css'
import PhoneInput, { formatPhoneNumber, formatPhoneNumberIntl, isValidPhoneNumber,isPossiblePhoneNumber } from 'react-phone-number-input'
import { useFormContext } from "./FormContext"; 
import { ToastContainer, toast } from 'react-toastify';
import { LuBadgeX } from "react-icons/lu";




const Register = () => {
  
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
  const { state, dispatch } = useFormContext();
 
  
 

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "+92",
    gender:"",
    province:"",
    city:""
  });
  useEffect(() => {
    // Update formData state with values from formContext when component mounts
    setFormData(state.form2);
  }, []); 
  
  const KPK_tehsils = [
    "Adenzai", "Allai", "Alpuri", "Ambar Utman Khel", "Bannu", "Bara", "Barikot", "Batagram", "Bettani", "Birmil", "Bisham", "Buni", "Chagharzai", "Chakesar", "Chamkani", "Charsadda", "Chitral",
    "Dara Adam Khel", "Daraban", "Darazinda", "Dassu", "Datta Khel", "Daur Maira", "Dera Ismail Khan", "Dossali", "Drosh", "Gagra", "Ghazni Khel", "Gharyum", "Ghulam Khan", "Gumbat", "Hangu", "Haripur",
    "Havelian", "Ismail Zai", "Jandola", "Judba", "Kabal", "Kakki", "Kalkot", "Kalakhel", "Kandia", "Karak", "Khal", "Khander", "Khar Bajaur", "Khwaza Khela", "Kolai-Palas", "Kurram",
    "Lakki Marwat", "Lal Qilla", "Landi Kotal", "Lachi", "Ladha", "Lahor", "Lower Dir", "Lower Kohistan", "Lower Kurram", "Lower Orakzai", "Lower South Waziristan", "Lund Khwar", "Makhuzai",
    "Makin", "Malakand", "Mamund", "Mansehra", "Martung", "Mastuj", "Mathra", "Meryan", "Miran Shah", "Mir Ali", "Moga", "Mohmand", "Mulkhow/Torkhow", "Nawagai", "Nowshera", "Orakzai",
    "Paharpur", "Paroa", "Pattan", "Peshawar", "Peshtakhara", "Pindiali", "Puran", "Razmak", "Razar", "Rustam", "Safi", "Samar Bagh", "Sam Rani Zai", "Sararogha", "Sarawakai",
    "Sarawakai", "Seo", "Serwekai", "Shabqadar", "Shaktoi", "Shawal", "Shewa", "Shinkiari", "Spinwam", "Swabi", "Takht Bhai", "Takht-e-Nasrati", "Tangi", "Tank", "Thal",
    "Timergara", "Toi Khulla", "Topi", "Torghar", "Upper Chitral", "Upper Dir", "Upper Kohistan", "Upper Kurram", "Upper Orakzai", "Upper South Waziristan", "Utmankhel", "Wana", "Wari", "Wazir", "Yake Ghund"
];

  
  const Balochistan_tehsils = [
    "Awaran", "Baghbana", "Balnigor", "Balanari", "Barkhan", "Barshore", "Besima", "Bhag", "Bela", "Buleda",
    "Chagai", "Chaman", "Chiltan", "Dalbandin", "Dasht", "Dasht Mastung", "Dera Bugti", "Dera Murad Jamali", "Dhadar", "Dobandi",
    "Duki", "Gichk", "Gandakha", "Gandoi", "Garekhat", "Gishkaur", "Gowargo", "Grisini", "Gulistan", "Gwadar",
    "Harnai", "Hayrvi", "Hub", "Jhal Jhao", "Jhal Magsi", "Jiwani", "Johan", "Kahan", "Kalat", "Kanmetharzai",
    "Kanraj", "Karkh", "Khattan", "Khoast", "Kuchlak", "Kulanch", "Kharan", "Khuzdar", "Kingri", "Korak Jahoo",
    "Kutmandai", "Loralai", "Loiband", "Mach", "Maiwand", "Mand", "Mangochar", "Mashkay", "Mashkel", "Mekhtar",
    "Mirpur", "Moola", "Muslim Bagh", "Nag", "Nall", "Nasirabad", "Nok Kundi", "Nushki", "Ormara", "Ornach",
    "Panjgur", "Panjpai", "Paroom", "Pasni", "Phelawagh", "Sadar", "Sangan", "Sani", "Sar-Kharan", "Saroona",
    "Shahgori", "Sherani", "Shinki", "Sibi", "Sinjavi", "Sohbatpur", "Solband", "Sui", "Suntsar", "Surab",
    "Tamboo", "Taftan", "Tohmulk", "Toisar", "Tump", "Turbat", "Usta Mohammad", "Uthal", "Washuk", "Wadh",
    "Zehri", "Ziarat", "Zamuran", "Zarghoon"
];

 
  const Kashmir_tehsils = [
    "Abbaspur", "Bagh", "Balouch", "Barnala", "Bhimber", "Birpani", "Charhoi", "Chikkar", "Dadyal", "Dhirkot", "Fatehpur Thakiala", "Hajira", "Hattian Bala", "Haveli", "Islamgarh", "Khurshidabad", "Khuiratta", "Kotli", "Leepa", "Mang",
    "Mirpur", "Mumtazabad", "Muzaffarabad", "Nasirbad", "Pallandri", "Rawalakot", "Rera", "Samahni", "Sehnsa", "Sharda", "Tarar Khel", "Thorar"
];

 
  const Sindh_tehsils = [
    "Aram Bagh", "Badin", "Bakrani", "Baldia", "Bin Qasim", "Bhiria", "Bulri Shah Karim", "Chamber", "Civil Line", "Dadu", "Daharki", "Dahli", "Diplo", "Dokri", "Faiz Ganj", "Fatehpur Thakiala", "Gambat", "Garhi Khairo", "Garhi Yasin",
    "Ghorabari", "Gulistan-e-Jouhar", "Gulshan-E-Iqbal", "Gulzar-E-Hijri", "Hala", "Hyderabad City", "Ibrahim Hyderi", "Islamkot", "Ittehad", "Jati", "Jhando Mari", "Jinnah", "Johi", "Kandhkot", "Kanganpur", "Kandiaro", "Keti Bunder", "Khairpur Nathan Shah", "Khanpur",
    "Kharo Chan", "Khipro", "Kingri", "Kot Diji", "Kot Ghulam Muhammad", "Kotri", "Kubo Saeed Khan", "Kunri", "Latifabad", "Liaquatabad", "Lyari", "Malir", "Manghopir", "Manjhand", "Maripur", "Matli", "Mehar", "Mehrabpur",
    "Mirpur Bathoro", "Mirpur Khas", "Mirpur Mathelo", "Mirpur Sakro", "Mominabad", "Moro", "Murad Memon", "Nagarparkar", "Nasarpur", "Nasirabad", "New Karachi", "New Sukkur", "North Karachi", "North Nazimabad", "Orangi", "Pallandri",
    "Pano Aqil", "Pithoro", "Qasimabad", "Qambar", "Qubo Saeed Khan", "Ratodero", "Rohri", "Sadar", "Salehpat", "Samaro", "Sehwan", "Shah Bandar", "Shahdadpur", "Shah Faisal", "Shah Murad", "Shaheed Fazil Rahu", "Shujabad", "Sijawal Junejo",
    "Sindhri", "Sinjhoro", "Sobho Dero", "Sujawal", "Tando Adam Khan", "Tando Bago", "Tando Ghulam Hyder", "Tando Mohammad Khan", "Tangwani", "Tharparkar", "Thari Mirwah", "Thul", "Ubauro", "Umerkot", "Warah"
];


  const Punjab_tehsils = [
    "Ahmadpur East", "Ahmadpur Sial", "Alipur", "Arifwala", "Attock", "Bahawalnagar", "Bahawalpur City", "Bahawalpur Saddar", "Bhakkar", "Bhalwal", "Bhera", "Burewala", "Chakwal","Chak Jhumra", "Chishtian", "Chowk Sarwar Shaheed", "Chunian", "Darya Khan", "Daska",
    "Depalpur", "Dera Ghazi Khan", "De-Excluded Area D.G. Khan", "De-Excluded Area Rajanpur", "Dina", "Faisalabad City", "Faisalabad Sadar", "Fateh Jang", "Fort Abbas", "Gojra", "Gujar Khan", "Gujrat", "Gujranwala City", "Gujranwala Saddar",
    "Hafizabad", "Hasilpur", "Haroonabad", "Hassan Abdal", "Hazro", "Jampur", "Jalalpur Jattan", "Jalalpur Pirwala", "Jaranwala", "Jahanian", "Jatoi", "Jhang", "Joharabad", "Kahror Pakca", "Kallar Kahar", "Kallar Syedan", "Kamalia",
    "Karor Lal Esan", "Khanewal", "Khanpur", "Kharian", "Khipro", "Khushab", "Kot Addu", "Kot Chutta", "Kot Momin", "Kot Radha Kishan", "Kunjah", "Lalian", "Layyah", "Lahore Cantonment", "Lahore City", "Liaquatpur", "Lodhran",
    "Malakwal", "Mankera", "Mian Channu", "Minchinabad", "Multan Khurd", "Muhammadpur", "Murree", "Muzaffargarh", "Nankana Sahib", "Narowal", "Nowshera Virkan", "Okara", "Pakpattan", "Pasrur", "Pattoki", "Pindi Bhattian",
    "Pindi Gheb", "Piplan", "Pir Mahal", "Quaidabad", "Rajanpur", "Rahim Yar Khan", "Raiwind", "Rawalpindi", "Renala Khurd", "Rojhan", "Sadar", "Sambrial", "Samundri", "Sangla Hill", "Sarai Alamgir", "Sadiqabad",
    "Sialkot", "Shah Kot", "Shahdadpur", "Shahpur", "Shakargarh", "Shujabad", "Shorkot", "Sillanwali", "Sobho Dero", "Sohawa", "Sukheke", "Talagang", "Tandlianwala", "Taxila", "Toba Tek Singh", "Vehari",
    "Wazirabad", "Yazman", "Zafarwal"
];

const Gilgit_tehsils = [
  "Aliabad", "Astore", "Babusar", "Baltistan", "Chalt", "Chilas", "Chorbut", "Daghoni", "Danyor", "Diamer", "Gamba", "Gilgit", "Gojal", "Gupis", "Gulabpur", "Gultari", "Haldi", "Hunza", "Ishkoman", "Juglot", "Keris", "Khaplu", "Kharmang",
  "Kohistan", "Mashabrum", "Nagar", "Naltar", "Punial", "Rondu", "Shigar", "Shounter", "Skardu", "Tangir", "Yasin"
];
// Define the tehsils for each province
const tehsilsByProvince = {
  "Khyber Pakhtunkhwa": KPK_tehsils,
  "Balochistan": Balochistan_tehsils,
  "Azad Kashmir": Kashmir_tehsils,
  "Sindh": Sindh_tehsils,
  "Punjab": Punjab_tehsils,
  "Gilgit Baltistan": Gilgit_tehsils
};
const handleProvinceChange = (e) => {
  const selectedProvince = e.target.value;
  setFormData({ ...formData, province: selectedProvince, city: '' });
};
const handlenextpage =  async (e) => {
  e.preventDefault();
 
  // Check if bar association meets the validation criteria
  const Name = formData.name.trim();
  const words = Name.split(/\s+/); // Split by whitespace to count words
  if (Name.length < 6 || words.length < 2) {
      toast.error("Full Name is required.");
      return;
  }
  if(!isValidPhoneNumber(formData.phone))
  {
    toast.error("Phone number is invalid")
    return;
  }

  // Check if bar association meets the validation criteria
  const Email = formData.email.trim();
  if (Email.length < 13) {
      toast.error("Email is invalid.");
      return;
  }


    try {
      const response = await axios.post('http://localhost:5000/checkPhoneEmail', {
        phone: formData.phone,
        email: formData.email
      });

      const { message } = response.data;
      if (message === 'Both phone and email exist' || message === 'Phone exists' || message === 'Email exists') {
        toast.error(message);
        return;
      }
    } catch (error) {
      console.error('Error checking phone and email:', error);
      toast.error("Failed to check phone and email.");
      return;
    }

  dispatch({ type: 'UPDATE_FORM_2', payload: formData });

  setLoading(true);
  setTimeout(() => {
    console.log("Form 2:",formData)
    navigate('/lawyerSignup3');
  }, 500);
  
}

    return (
    <div className="signup-wrapper2">
      <div className="wrapper2">
        <form onSubmit={handlenextpage}>
          <h1>Lawyer Signup</h1>
          <div className="input-box2" id="in1">
            <label className="label">Enter your full Name:</label>
            <input
             type="text"
              placeholder="Full Name"
              required
              name="Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}/>
            <FaUser className="icon2"/>

          </div>

          <div className="input-box2" id="email">
            <label className="label">Enter your Email:</label>
            <input 
            type="email"
            placeholder="Email"
            required
            name="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
            <MdEmail className="icon2"/>
          </div>

         <div className="input-box2" id="phone">
         <label className="label">Enter your phone no.</label>
         
           
          </div>
          <PhoneInput 
                name="mobile-number"
                className="phoneInput"
                defaultCountry="PK"
                value={formData.phone}
                placeholder="Phone number"
                onChange={(phone) => setFormData({ ...formData, phone })}
                required
               
                
      
           />
          {formData.phone && (
                  <div className="extra">
                      {isValidPhoneNumber(formData.phone) ? (
                          <>
                              <GrValidate className="tick" /> 
                              <span className="valid-message">Valid Phone number</span>
                          </>
                      ) : (
                          <>
                              <LuBadgeX className="cross" />
                              <span className="invalid-message">Invalid Phone number</span>
                          </>
                      )}
                  </div>
              )}
          <div className="input-box2" id="gender">
          <label className="label">Select your gender:</label>
          <div className="male-box">
          <label htmlFor="male" className="option1">Male</label>
            <input
              type="radio"
              id="male"
              name="gender"
              value="Male"
              checked={formData.gender === "Male"}
              onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
              required
            />
            
          </div>
          <div className="female-box">
           <label htmlFor="female" className="option2">Female</label>
            <input
              type="radio"
              id="female"
              name="gender"
              value="Female"
              checked={formData.gender === "Female"}
              onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
              required
            />
           
          </div>
     </div>
          
            
           <div className="input-box2" id="province">
              <label className="label">Select your province:</label>
                <select
                    name="province"
                    value={formData.province}
                    onChange={handleProvinceChange}
                    required
                  >
                    <option value="">Select</option>
                    {Object.keys(tehsilsByProvince).map((province) => (
                      <option key={province} value={province}>{province}</option>
                    ))}
                  </select>
          </div>

          <div className="input-box2" id="city">
              <label className="label">Select your city:</label>
              <select
                    name="city"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    required
                  >
                    <option value="">Select</option>
                    {formData.province && tehsilsByProvince[formData.province].map((tehsil) => (
                      <option key={tehsil} value={tehsil}>{tehsil}</option>
                    ))}
                    
              </select>
               
          </div>

          

          {loading ? (
            <div className="loading-spinner">
                  <ClipLoader
                      color={"#007bff"}
                      loading={loading}
                      size={100}
                    />
                </div>
              ) : (
                <button type="submit">Next</button>
              )}
          <div className="register-link2">
            <p>Form 2 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;