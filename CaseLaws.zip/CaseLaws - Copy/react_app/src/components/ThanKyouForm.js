import React, { useState,useEffect } from "react"
import "../styles/thankyouForm.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import { useFormContext } from "./FormContext"; 
import { useUser } from './UserContext';
import { ToastContainer, toast } from 'react-toastify';


const Thankyou = () => {
  
  const navigate = useNavigate();
  const { userdata } = useUser();
  const { state, dispatch } = useFormContext();
  const [loading, setLoading] = useState(false);

  

 

  const handlebutton =()=>{
    navigate('/')
  }

    return (
    <div className="thankyou-wrapper">
      <div className="wrapper-element">
      <div class="container">
          <div class="tick"></div>
      </div>
        <p><strong className='upper-text'>Thankyou <span className="user-name">{userdata && userdata.username}</span> for your signup!!!</strong></p>
        <p className="lower-text1">Your data has been sent for verification.</p>
        <p className="lower-text2">Your profile will be created after verification from our team.</p>
        <button className="home-btn" onClick={handlebutton}>Back to home page</button>
      </div>
        
    </div> 

)
    
  

        
};
export default Thankyou;