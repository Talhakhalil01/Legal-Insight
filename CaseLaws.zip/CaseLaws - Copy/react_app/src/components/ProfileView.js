import React, { useState, useEffect } from "react";
import "../styles/ProfileView.css";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
// import ClipLoader from "react-spinners/MoonLoader";
import { ToastContainer, toast } from 'react-toastify';
import { useParams } from "react-router-dom";
import { initialResults } from "../Profiling/data";
import { useLocation } from "react-router-dom";
import { FaFacebook } from "react-icons/fa";
import { IoLogoWhatsapp } from "react-icons/io";
import { BsLinkedin } from "react-icons/bs";
import { useFormContext } from "./EditForms/Edit_FormContext"; 
import { useFormContext2 } from "./ProfileDataContext"; 
import { useUser } from './UserContext';
import ClipLoader from "react-spinners/SyncLoader";
import Modal from 'react-modal';





const Profile = () => {
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const id = queryParams.get("id");
    const [reviewRating, setReviewRating] = useState(0);
    const [reviewText, setReviewText] = useState("");
    const { state, dispatch } = useFormContext();
    const[userData,setuserData]=useState('');
    const navigate = useNavigate();
    const [loading , setLoading] = useState(false);
    


    const { state2, dispatch2, fetchData } = useFormContext2();
    const [frontImageURL, setFrontImageURL] = useState(null);
    const [backImageURL, setBackImageURL] = useState(null);
    const [LLBdegree, setLLBdegree] = useState(null);
    const [LAWGATresult, setLAWGATresult] = useState(null);
    const [certificateImage, setCertificateImage] = useState(null);
    const [approvalImage, setApprovalImage] = useState(null);
    const [imageURL, setImageURL] = useState(null);
    const [dataFetched, setDataFetched] = useState(false);


    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedImage, setSelectedImage] = useState(null);
    const [imageLabel, setImageLabel] = useState('');

    const openModal = (imageURL, label) => {
      setSelectedImage(imageURL);
      setImageLabel(label);
      setIsModalOpen(true);
    };

    const closeModal = () => {
      setIsModalOpen(false);
      setSelectedImage(null);
      setImageLabel('');
    };
    

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "+92",
    gender: "",
    province: "",
    city: "",
    areas: [],
    barAffiliation: "",
    barAssociation: "",
    barCardImages: {
      frontImage: null,
      backImage: null,
    },
    education: "",
    graduationYear: "",
    LLB: "",
    LLM: "",
    LLD: "",
    degrees: {
      LLBdegree: null,
      LAWGATresult: null,
    },
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts: "",
    highCourt: "",
    certificates: {
      certificateImage: null,
      approvalImage: null,
    },
    licenseNumber: "",
    certifications: "",
    caseExperience: "",
    notableCases: "",
    successStories: "",
    officeAddress: "",
    officeHours: {
      Monday: { startTime: "09:00", endTime: "17:00" },
      Tuesday: { startTime: "09:00", endTime: "17:00" },
      Wednesday: { startTime: "09:00", endTime: "17:00" },
      Thursday: { startTime: "09:00", endTime: "17:00" },
      Friday: { startTime: "09:00", endTime: "17:00" },
      Saturday: { startTime: "00:00", endTime: "00:00" },
      Sunday: { startTime: "00:00", endTime: "00:00" }
    },
    consultationModes: [],
    consultationFees: {},
    lawyerImage: null,
    facebook: "",
    whatsapp: "+92",
    linkedin: "",
  
  
  date: "",
  verificationDate: "",
  reviews:[]

  });

 
// Setting the app element for react-modal
// useEffect(() => {
//   Modal.setAppElement('#root');
// }, []);
useEffect(() => {
   const fetchProfileData = async () => {
    setLoading(true);
     try {
       
       axios.defaults.withCredentials = true;
       const response = await axios.get(`http://localhost:5000/fetch-profile`);
       const { profileData, practiceAreas, consultationModes, officeHours,reviews, images } = response.data;

      
       await dispatch2({ type: 'UPDATE_FETCHED_DATA', payload: { profileData, practiceAreas, consultationModes, officeHours, reviews, images } });
       // toast.success("Data fetched successfully")
       console.log("Feteched Data in first block:",state2.fetchedData)


       setDataFetched(true);
       setLoading(false);

     } catch (error) {
      //  navigate('/lawyerGuide')
      setLoading(false);
      console.log("Error:::",error)
       toast.error('Error while fetching profile data:', error);     
     }
   };

   fetchProfileData();

  }, []);

 
 useEffect(() => {
  if (dataFetched) {
    displayData();
  }
 
}, [dataFetched, state2.fetchData]);

  const displayData = () =>{

    if (state2.fetchedData.profileData) {
      console.log("Feteched Data:",state2.fetchedData)
     
      const { profileData, practiceAreas, consultationModes, officeHours, reviews, images } = state2.fetchedData;

      

      const officeHoursObject = officeHours.reduce((acc, { dayOfWeek, startTime, endTime }) => {
        acc[dayOfWeek] = { startTime, endTime };
        return acc;
      }, {});

      const modesOptions = consultationModes.map(modeobj => ({
        value: modeobj.mode,
        label: modeobj.mode,
      }));

      const consultationFees = consultationModes.reduce((acc, { mode, fee }) => {
        acc[mode] = fee;
        return acc;
      }, {});

      const baseURL = `http://localhost:5000`;

      if (images.frontImage) setFrontImageURL(`${baseURL}${images.frontImage}`);
      if (images.backImage) setBackImageURL(`${baseURL}${images.backImage}`);
      if (images.LLBdegree) setLLBdegree(`${baseURL}${images.LLBdegree}`);
      if (images.LAWGATresult) setLAWGATresult(`${baseURL}${images.LAWGATresult}`);
      if (images.certificateImage) setCertificateImage(`${baseURL}${images.certificateImage}`);
      if (images.approvalImage) setApprovalImage(`${baseURL}${images.approvalImage}`);
      if (images.lawyerImage) setImageURL(`${baseURL}${images.lawyerImage}`);

      setFormData((prevFormData) => ({
        ...prevFormData,
        name: profileData.name || prevFormData.name,
        email: profileData.email || prevFormData.email,
        phone: profileData.phone || prevFormData.phone,
        gender: profileData.gender || prevFormData.gender,
        province: profileData.province || prevFormData.province,
        city: profileData.city || prevFormData.city,
        areas: practiceAreas || prevFormData.areas,
        barAffiliation: profileData.barAffiliation || prevFormData.barAffiliation,
        barAssociation: profileData.barAssociation || prevFormData.barAssociation,
        barCardImages: {
          frontImage: images.frontImage ? images.frontImage : prevFormData.barCardImages.frontImage,
          backImage: images.backImage ? images.backImage : prevFormData.barCardImages.backImage,
        },
        education: profileData.education || prevFormData.education,
        graduationYear: profileData.graduationYear || prevFormData.graduationYear,
        LLB: profileData.LLB || prevFormData.LLB,
        LLM: profileData.LLM || prevFormData.LLM,
        LLD: profileData.LLD || prevFormData.LLD,
        degrees: {
          LLBdegree: images.LLBdegree ? images.LLBdegree : prevFormData.degrees.LLBdegree,
          LAWGATresult: images.LAWGATresult ? images.LAWGATresult : prevFormData.degrees.LAWGATresult,
        },
        currentPosition: profileData.currentPosition || prevFormData.currentPosition,
        durationOfPractice: profileData.durationOfPractice || prevFormData.durationOfPractice,
        lowerCourts: profileData.lowerCourts || prevFormData.lowerCourts,
        highCourt: profileData.highCourt || prevFormData.highCourt,
        certificates: {
          certificateImage: images.certificateImage ? images.certificateImage : prevFormData.certificates.certificateImage,
          approvalImage: images.approvalImage ? images.approvalImage : prevFormData.certificates.approvalImage,
        },
        licenseNumber: profileData.licenseNumber || prevFormData.licenseNumber,
        certifications: profileData.certifications || prevFormData.certifications,
        caseExperience: profileData.caseExperience || prevFormData.caseExperience,
        notableCases: profileData.notableCases || prevFormData.notableCases,
        successStories: profileData.successStories || prevFormData.successStories,
        officeAddress: profileData.officeAddress || prevFormData.officeAddress,
        officeHours: { ...prevFormData.officeHours, ...officeHoursObject },
        consultationModes: modesOptions || prevFormData.consultationModes,
        consultationFees: { ...prevFormData.consultationFees, ...consultationFees },
        lawyerImage: images.lawyerImage ? images.lawyerImage : prevFormData.lawyerImage,
        facebook: profileData.facebook || prevFormData.facebook,
        whatsapp: profileData.whatsapp || prevFormData.whatsapp,
        linkedin: profileData.linkedin || prevFormData.linkedin,
        date:profileData.signupDate || prevFormData.date,
        verificationDate: profileData.verificationDate || prevFormData.verificationDate,

        reviews: reviews || prevFormData.reviews,
        
      }));
      
      
      console.log("Reviews:",reviews)
      
    }
    else{

      console.log("Feteched Data in else:",state2.fetchedData)
      toast.error("Data not found")
    }

   
  }
   
 
  // console.log(id);
  // const lawyer = initialResults.find((lawyer) => lawyer.id === parseInt(id));
  //   const handleAddReview = () => {
  //     console.log("Adding Review:", reviewRating, reviewText);
  //   };
  //   if (!lawyer) {
  //     return (
  //       <div className="bg-gray-500 min-h-screen px-6 py-24">
  //         <p className="text-white">Lawyer not found.</p>
  //       </div>
  //     );
  //   }
   
    const formatOfficeHours = (officeHours) => {
      return (
        <div className="office-hours">
          {Object.entries(officeHours).map(([day, { startTime, endTime }]) => (
            <div key={day} className="office-hours-day">
              <span className="day">{day}:</span>
              <div className="time">
                <span className="start-time">{startTime}</span>
                <span className="dash">-</span>
                <span className="end-time">{endTime}</span>
            </div>
            </div>
          ))}
        </div>
      );
    };
  
    const formatConsultationFees = (consultationFees) => {
      return (
        <div className="consultation-fees">
          {Object.entries(consultationFees).map(([mode, fee]) => (
            <div key={mode} className="consultation-fees-mode">
              <div className="mode-fee">
                    <span className="mode">{mode}:</span>
                    <span className="fee">{fee}rs</span>
              </div>
            </div>
          ))}
        </div>
      );
    };
    const formatPracticeAreas = () => {
      const areas=formData.areas;
      if (Array.isArray(areas)) {
        const areaNames = areas.map(areaObj => areaObj.area);
        return areaNames.join(", ");
      } else if (typeof areas === 'object' && areas !== null && 'area' in areas) {
        return areas.area;
      } else {
        return "";
      }
    };
    

    const handleEdit = () => {
            //  navigate('/editlawyerSignup')
            const fetchProfileData = async () => {
              try {
                axios.defaults.withCredentials = true;
                const response = await axios.get('http://localhost:5000/fetch-profile');
                const { profileData, practiceAreas, consultationModes, officeHours, images } = response.data;
         

                await dispatch({ type: 'UPDATE_FETCHED_DATA', payload: { profileData, practiceAreas, consultationModes, officeHours, images } });
                toast.success("Data fetched successfully")

                navigate('/editlawyerSignup')
              } catch (error) {
                toast.error('Error fetching profile data', error);
                
              }
            };
        
            fetchProfileData();
            
    };
    const handleDelete = () => {

    }
    const formatDate = (dateString) => {
      if (!dateString) return "";
      const date = new Date(dateString);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    };
    
    const calculateNetRating = (reviews) => {
      if (reviews && reviews.length > 0) {
        const totalRating = reviews.reduce((acc, review) => acc + review.rating, 0);
        const averageRating = totalRating / reviews.length;
          return averageRating.toFixed(1);
      } else {
            return 0;
      }
    };
    const generateStars = (rating) => {
        const stars = [];
        for (let i = 1; i <= 5; i++) {
          if (i <= rating) {
            stars.push(<span key={i} className="star">&#9733;</span>); // filled star
          } else {
            stars.push(<span key={i} className="star-empty">&#9734;</span>); // empty star
          }
        }
        return stars;
    };
  

  return (
    <div className="profile-container">
     

      {loading ? (
        <div className="loading-spinner">
              <div className="loader">
               <ClipLoader
                  loading={loading}
                  color="#083e78"
                  margin={5}
                />
                </div>
                {/* <span>Please Wait</span> */}
            </div> ) 
        :
        (
        <div className="profile-wrapper">
        <div className="profile-header">
         {imageURL && <img src={imageURL} alt={formData.name} className="profile-picture" />}
          <div className="profile-details">

            <h1>{formData.name}</h1>
            <p className="profile-text2">{formData.currentPosition}</p>
            <p className="profile-text2">{formData.barAffiliation}</p>
            <p className="profile-text2">{formatPracticeAreas()}</p>
            <p className="profile-text2">{formData.city}</p>
                   
          </div>
          <div className="button-container">
                <span>Signup Date: {formatDate(formData.date)}</span>
                <span>Verification Date: {formData.verificationDate}</span>
                <span>Rating: {calculateNetRating(formData.reviews)}</span>
                <button className="submit-review-button" onClick={handleEdit}>Edit Profile</button>
                <button className="submit-review-button" onClick={handleDelete}>Delete Profile</button>
          </div>
         
          
        </div>
        <div className="profile-info">
       
          <div className='profile-info-row'>
                <div className="data-block">
                <h2 className="section-title">Basic Information</h2>
                <p className="profile-text">Practice Areas:{formatPracticeAreas()}</p>
                <p className="profile-text">Bar Affiliation: {formData.barAffiliation}</p>
                <p className="profile-text">Bar Association: {formData.barAssociation}</p>
                {frontImageURL && <p className="image-btn" onClick={() => openModal(frontImageURL, 'Front Bar Card')}>View Front Bar Card</p>}
                <br />
                {backImageURL && <p className="image-btn" onClick={() => openModal(backImageURL, 'Back Bar Card')}>View Back Bar Card</p>}
                    
                </div>
             
                <div className="data-block">
                <h2 className="section-title">Personal Details</h2>
                <p className="profile-text">Name: {formData.name}</p>
                <p className="profile-text">Email: {formData.email}</p>
                <p className="profile-text">Phone no.: {formData.phone}</p>
                <p className="profile-text">Province: {formData.province}</p>
                <p className="profile-text">City: {formData.city}</p>
                </div>
               
                <div className="data-block">
                    <h2 className="section-title">Education</h2>
                    <p className="profile-text">Education: {formData.education}</p>
                    <p className="profile-text">LLB: {formData.LLB}</p>
                    <p className="profile-text">LLM: {formData.LLM}</p>
                    <p className="profile-text">LLD: {formData.LLD}</p>
                    {LLBdegree && <p className="image-btn" onClick={() => openModal(LLBdegree, 'LLB Degree')}>View LLB Degree</p>}
                      <br />
                    {LAWGATresult && <p className="image-btn" onClick={() => openModal(LAWGATresult, 'LAW-GAT Result')}>View LAW-GAT</p>}
                </div>

          </div>
        
          <div className="profile-info-row">
            <div className="data-block">
              <h2 className="section-title">Professional Details</h2>
              <p className="profile-text">Current Position: {formData.currentPosition}</p>
              <p className="profile-text">Duration of Practice: {formData.durationOfPractice}</p>
              <p className="profile-text">Lower Courts: {formData.lowerCourts}</p>
              <p className="profile-text">High Court: {formData.highCourt}</p>
              {certificateImage && <p className="image-btn" onClick={() => openModal(certificateImage, 'Certificate Image')}>View Confirmation</p>}
              <br />
              {approvalImage && <p className="image-btn" onClick={() => openModal(approvalImage, 'Approval Image')}>View Approval</p>}
            </div>
           
            <div className="data-block">
              <h2 className="section-title">License and Certifications</h2>
              <p className="profile-text">Certifications: {formData.certifications}</p>
              <p className="profile-text">Case Experience: {formData.caseExperience}</p>
              <p className="profile-text">Notable Cases: {formData.notableCases}</p>
              <p className="profile-text">Success Stories: {formData.successStories}</p>
            
            </div>
         
            <div className="data-block">
            <h2 className="section-title">Social Media and Contact</h2>
              <p className="profile-text">Contact Number: {formData.phone}</p>
              <div className="social-links">
                {formData.facebook && (
                  <a href={formData.facebook} className="social-link">
                    <FaFacebook />
                  </a>
                )}
                {formData.whatsapp && (
                  <a href={`https://wa.me/${formData.whatsapp}`} className="social-link">
                    <IoLogoWhatsapp />
                  </a>
                )}
                {formData.linkedin && (
                  <a href={formData.linkedin} className="social-link">
                    <BsLinkedin />
                  </a>
                )}
                </div>
            </div>
            
         </div>
        
         <div className="data-block">
            <h2 className="section-title">Office Details</h2>
            <p className="profile-text">Office Address: {formData.officeAddress}</p>
            <div className="profile-text">Office Hours:</div>
            {formatOfficeHours(formData.officeHours)}
            <p className="profile-text">Consultation Modes: {formData.consultationModes.map(mode => mode.label).join(", ")}</p>
            <div className="profile-text">
                Consultation Fees:
                <div className="fees-container">
                        <div className="fee-item">
                            {formatConsultationFees(formData.consultationFees)}
                        </div>
                  
                </div>
            </div>
          </div>
          <div>
            <h2 className="section-title2">Reviews and Ratings({formData.reviews.length})</h2>
            <div className="reviews">
              {formData.reviews && formData.reviews.map((review, index) => (
                  <div key={index} className="review">
                    <p className="review-title">{review.category}</p>
                    <p className="review-user">{review.Username}</p>
                    <div className="review-rating">
                      Rating: {generateStars(review.rating)}
                    </div>
                    <p className="review-text"> Review: {review.reviewText}</p>
                    <p className="review-text">Review Date: {formatDate(review.reviewDate)}</p>
                  </div>
                ))}
            </div>
            
          </div>
        </div>
        <Modal
            isOpen={isModalOpen}
            onRequestClose={closeModal}
            contentLabel="Image Viewer"
            className="modal"
            overlayClassName="modal-overlay"
          >
            <div className="modal-header">
              <h2>{imageLabel}</h2>
              <button onClick={closeModal} className="close-button">&times;</button>
            </div>
            {selectedImage && <img src={selectedImage} alt={imageLabel} className="modal-image" />}
          </Modal>
      
      </div>)}
    </div>
  );
};

export default Profile;
