import React, { useState,useEffect } from "react"
import "./Edit_LawyerSignup5.css"
import '../../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { IoMdCall } from "react-icons/io";
import { HiBuildingOffice2 } from "react-icons/hi2";
import { ImCross } from "react-icons/im";
import { GrValidate } from "react-icons/gr";
import 'react-phone-number-input/style.css'
import Select from 'react-select';
import PhoneInput, { formatPhoneNumber, formatPhoneNumberIntl, isValidPhoneNumber,isPossiblePhoneNumber } from 'react-phone-number-input'
import ClipLoader from "react-spinners/MoonLoader";
import { useFormContext } from "./Edit_FormContext"; 
import { ToastContainer, toast } from 'react-toastify';




const Register = () => {
  
  const navigate = useNavigate();
  const { state, dispatch } = useFormContext();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
 

  const [formData, setFormData] = useState({
   licenseNumber:"",
   certifications:"",
   caseExperience:"",
   notableCases:"",
   successStories:""
  });
  useEffect(() => {
    if (state.fetchedData.profileData) {
      const { profileData, images } = state.fetchedData;

      setFormData((prevFormData) => ({
        ...prevFormData,
        licenseNumber: profileData.licenseNumber || prevFormData.licenseNumber,
        certifications: profileData.certifications || prevFormData.certifications,
        caseExperience: profileData.caseExperience || prevFormData.caseExperience,
        notableCases: profileData.notableCases || prevFormData.notableCases,
        successStories: profileData.successStories || prevFormData.successStories
        
      }));

      
    
    }
   
  }, [state.fetchedData]); 
  const handlenextpage =  async (e) => {
    e.preventDefault();
    // Check if each field contains at least 3 characters
    
    const licensenumber = formData.licenseNumber.trim();
    const words = licensenumber.split(/\s+/);            
    if (licensenumber.length < 5 || words.length > 1) {
        toast.error("Bar license number is invalid.");
        return;
    }
    const casexperience = formData.caseExperience.trim();
    const words2 = casexperience.split(/\s+/);       
    if (casexperience.length < 12 || words2.length < 3) {
      toast.error("Case experience is improper.");
      return;
  }

    const successstories = formData.successStories.trim();
    const words3 = successstories.split(/\s+/);       
    if (successstories.length < 12 || words3.length < 3) {
        toast.error("Success stories is improper.");
        return;
    }

    if (!formData.certifications || formData.certifications.length < 8) {
      setFormData(prevData => ({ ...prevData, certifications: 'Nil' }));
    }
  
    if (!formData.notableCases || formData.notableCases.length < 8) {
      setFormData(prevData => ({ ...prevData, notableCases: 'Nil' }));
    }

   
    
  
    // Update context with form data
    dispatch({ type: 'UPDATE_FORM_5', payload: formData });
  
    setLoading(true);
    setTimeout(() => {
      console.log("Form 5:",formData)
      // Navigate to the next page
      navigate('/editlawyerSignup6');
    }, 500);
    
  }


    return (
      <div className="signup-wrapper5">
       <div className="wrapper5">
        <form onSubmit={handlenextpage}>
          <h1>Lawyer Signup</h1>
          <div className="input-box5" id="input1">
                <label id="label1">Update Bar License Number:</label>
                <input
                    type="text"
                    id="licenseNumber"
                    name="licenseNumber"
                    value={formData.licenseNumber}
                    required
                    onChange={(e) => setFormData({ ...formData, licenseNumber: e.target.value })}
                    placeholder="E.g:123456,etc."
                />
            </div>
            <div className="input-box5" id="input2">
                <label>Update Specialized Certifications(if any):</label>
                <input
                    id="certifications"
                    name="certifications"
                    value={formData.certifications}
                    onChange={(e) => setFormData({ ...formData, certifications: e.target.value })}
                    placeholder="E.g:Certified in Family Law,Certified in Criminal Law,etc."
                />
            </div>
            <div className="input-box5">
                <label>Update Case Experience:</label>
                <input
                    id="caseExperience"
                    name="caseExperience"
                    value={formData.caseExperience}
                    required
                    onChange={(e) => setFormData({ ...formData, caseExperience: e.target.value })}
                    placeholder="E.g:Handled various divorce cases with successful outcomes,etc."
                />
            </div>
            <div className="input-box5">
                <label>Update Notable Cases Handled(if any):</label>
                <input
                    id="notableCases"
                    name="notableCases"
                    value={formData.notableCases}
                    onChange={(e) => setFormData({ ...formData, notableCases: e.target.value })}
                    placeholder="E.g:Won landmark case X vs. Y in Supreme Court.,etc."
                />
            </div>
            <div className="input-box5">
                <label>Update Success Stories or Outcomes:</label>
                <input
                    id="successStories"
                    name="successStories"
                    value={formData.successStories}
                    required
                    onChange={(e) => setFormData({ ...formData, successStories: e.target.value })}
                    placeholder="E.g:Helped client Z win custody battle.,etc."
                />
            </div>
           

     {loading ? (
        <div className="loading-spinner">
               <ClipLoader
                  color={"#007bff"}
                  loading={loading}
                  size={100}
                />
            </div>
          ) : (
            <button type="submit">Next</button>
          )}
          <div className="register-link5">
            <p>Form 5 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;