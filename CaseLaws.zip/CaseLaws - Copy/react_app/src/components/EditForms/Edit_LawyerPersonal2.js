import React, { useState,useEffect } from "react"
import "./Edit_LawyerSignup2.css"
import '../../styles/central.css';
import defaultImageIcon from '../../styles/images/document4.png';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import Select from 'react-select';
import ClipLoader from "react-spinners/MoonLoader";
import { useFormContext } from "./Edit_FormContext"; 
import { ToastContainer, toast } from 'react-toastify';


const Register = () => {
  
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
  const { state, dispatch } = useFormContext();
  const [LLBdegree,setLLBdegree]=useState(null)
  const [LAWGATresult,setLAWGATresult]=useState(null)

  const [formData, setFormData] = useState({
    education: "",
    graduationYear: "",
    LLB: "",
    LLM:"",
    LLD:"",
    degrees:{
      LLBdegree: null,
      LAWGATresult: null,
  },

  });
  useEffect(() => {
    if (state.fetchedData.profileData) {
      const { profileData, images } = state.fetchedData;

      setFormData((prevFormData) => ({
        ...prevFormData,
        education: profileData.education || prevFormData.education,
        graduationYear: profileData.graduationYear || prevFormData.graduationYear,
        LLB: profileData.LLB || prevFormData.LLB,
        LLM: profileData.LLM || prevFormData.LLM,
        LLD: profileData.LLD || prevFormData.LLD,
        degrees: {
          LLBdegree: images.LLBdegree ? images.LLBdegree : prevFormData.degrees.LLBdegree,
          LAWGATresult: images.LAWGATresult ? images.LAWGATresult: prevFormData.degrees.LAWGATresult,
        },
      }));

      const baseURL = `http://localhost:5000`;

      if (images.LLBdegree) {
        setLLBdegree(`${baseURL}${images.LLBdegree}`);
        
      } 

      if (images.LAWGATresult) {
        setLAWGATresult(`${baseURL}${images.LAWGATresult}`);
      }
    
    }
   
  }, [state.fetchedData]); 


  const years = [];
    for (let year = 1980; year <= new Date().getFullYear(); year++) {
    years.push(year.toString());
    }

// Function to handle image selection
const  handleFrontImageChange = (e) => {
  const imageFile = e.target.files[0];

  if (!imageFile || !imageFile.type.match('image/*')) {
    toast.error('Please select a valid image file.');
    return;
 }
 
  setFormData({
    ...formData,degrees: {...formData.degrees, LLBdegree: imageFile,},
  });
  if (imageFile) { // Optional preview
        
        setLLBdegree(URL.createObjectURL(imageFile))
       
      }
};
const  handleBackImageChange = (e) => {
  const imageFile2 = e.target.files[0];
  if (!imageFile2 || !imageFile2.type.match('image/*')) {
    toast.error('Please select a valid image file.');
    return;
 }
  setFormData({
    ...formData,degrees: {...formData.degrees, LAWGATresult: imageFile2,},
  });
  if (imageFile2) { // Optional preview
        
        setLAWGATresult(URL.createObjectURL(imageFile2))
       
      }
};

  const handlenextpage =  async (e) => {
    e.preventDefault();
    
    if (!LLBdegree)
    {
      toast.error('LLB degree image is required.');
      return;
    }
    if (!LAWGATresult)
    {
      toast.error('LAW-GAT result image is required.');
      return;
    }
     
    // Update context with form data
    dispatch({ type: 'UPDATE_FORM_3', payload: formData });
  
    setLoading(true);
    setTimeout(() => {
        console.log("Form 3:",formData)
      // Navigate to the next page
      navigate('/editlawyerSignup4');
    }, 500);
    
  }
    return (
    <div className="signup-wrapper4">
      <div className="wrapper4">
        <form onSubmit={handlenextpage}>
          <h1>Lawyer Signup</h1>
          
          <div className="input-box4" id="education">
            <label className="label">Update your education:</label>
            <select
                
                name="education"
                value={formData.education}
                required
                onChange={(e) => setFormData({ ...formData, education: e.target.value })}
            >
                <option value="">Select Law Degree</option>
                <option value="LLB">Bachelor of Laws (LLB)</option>
                <option value="LLM">Master of Laws (LLM)</option>
                <option value="LLD">Doctor of Laws (LLD)</option>
          </select>

          </div>
          <div className="input-box4">
            <label className="label">Update your LLB graduation year:</label>
            <select
                id="date"
                name="date"
                value={formData.graduationYear}
                required
                onChange={(e) => setFormData({ ...formData, graduationYear: e.target.value })}
            >
                <option value="">Select graduation year</option>
                {years.map((year) => (
                <option key={year} value={year}>
                    {year}
                </option>
                ))}
             </select>


          </div>
         
          {formData.education=="LLB" && (
            <div className="input-box4">
            <label className="label">Update LLB Institute/LLB University:</label>
            <input 
                type="text" 
                id="institutes"
                placeholder="Name of institute/univeristy from where you got your LLB degree" 
                required
                name="institutes"
                value={formData.LLB}
                onChange={(e) => setFormData({ ...formData, LLB: e.target.value })}
            />
              </div>
          )}
           {formData.education=="LLM" && (
            <div>
                <div className="input-box4">
            <label className="label">Update LLB Institute/LLB University:</label>
            <input 
                type="text" 
                id="institutes"
                placeholder="Name of institute/univeristy from where you got your LLB degree" 
                required
                name="institutes"
                value={formData.LLB}
                onChange={(e) => setFormData({ ...formData, LLB: e.target.value })}
            />
              </div>
              <div className="input-box4">
              <label className="label">Update LLM Institute/LLM University:</label>
              <input 
                  type="text" 
                  id="institutes"
                  placeholder="Name of institute/univeristy from where you got your LLM degree" 
                  required
                  name="institutes"
                  value={formData.LLM}
                  onChange={(e) => setFormData({ ...formData, LLM: e.target.value })}
              />
                </div>
            </div>
            
          )}
           {formData.education=="LLD" && (
            <div>
                <div className="input-box4">
            <label className="label">Update LLB Institute/LLB University:</label>
            <input 
                type="text" 
                id="institutes"
                placeholder="Name of institute from where you got your LLB degree" 
                required
                name="institutes"
                value={formData.LLB}
                onChange={(e) => setFormData({ ...formData, LLB: e.target.value })}
            />
              </div>
              <div className="input-box4">
              <label className="label">Update LLM Institute/LLM University:</label>
              <input 
                  type="text" 
                  id="institutes"
                  placeholder="Name of institute from where you got your LLBM degree" 
                  required
                  name="institutes"
                  value={formData.LLM}
                  onChange={(e) => setFormData({ ...formData, LLM: e.target.value })}
              />
                </div>
                <div className="input-box4">
                <label className="label">Update LLD Institute/LLD University:</label>
                <input 
                    type="text" 
                    id="institutes"
                    placeholder="Name of institute from where you got your LLD degree" 
                    required
                    name="institutes"
                    value={formData.LLD}
                    onChange={(e) => setFormData({ ...formData, LLD: e.target.value })}
                />
                </div>

            </div>
            
          )}
          
           
              
             
        
          <div className="input-box4" id="img1">
                <label id="label-image1">Update clear image of your LLB degree:</label>
                <input
                    type="file"
                    id="uploadBtn"
                    onChange={handleFrontImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label htmlFor="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>


                
             {/* Image viewer for front image */}
             {LLBdegree ? (
                    <img className="image" src={LLBdegree} alt="LLB Degree Image" />
                ) : (
                    <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
                )}
            </div>
            

           
            <div className="input-box4" id="img2">
                <label id="label-image2">Update clear image of your LAW-GAT result:</label>
                <input
                    type="file"
                    id="uploadBtn2"
                    onChange={handleBackImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label htmlFor="uploadBtn2" className="upload-btn2"><i class="fa-solid fa-upload"></i>Upload Image</label>


               {LAWGATresult ? (
                    <img className="image2" src={LAWGATresult} alt="LAW-GAT result Image" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>

            {loading ? (
        <div className="loading-spinner">
               <ClipLoader
                  color={"#007bff"}
                  loading={loading}
                  size={100}
                />
            </div>
          ) : (
            <button type="submit">Next</button>
          )}

          <div className="register-link4">
            <p>Form 3 of 7</p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Register;