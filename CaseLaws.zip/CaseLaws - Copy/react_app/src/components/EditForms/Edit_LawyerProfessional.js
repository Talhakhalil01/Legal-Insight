import React, { useState, useEffect } from "react";
import "./Edit_LawyerProfessional.css";
import '../../styles/central.css';
import defaultImageIcon from '../../styles/images/document4.png';
import { useNavigate } from "react-router-dom";
import Select from 'react-select';
import ClipLoader from "react-spinners/MoonLoader";
import { useFormContext } from "./Edit_FormContext"; 
import { ToastContainer, toast } from 'react-toastify';

const Register = () => {
  const navigate = useNavigate();
  const { state, dispatch } = useFormContext();
  const [loading, setLoading] = useState(false);
  const [frontImageURL, setFrontImageURL] = useState(null);
  const [backImageURL, setBackImageURL] = useState(null);

  const [formData, setFormData] = useState({
    areas: "",
    barAffiliation: "",
    barAssociation: "",
    barCardImages: {
      frontImage: null,
      backImage: null,
    },
  });

  useEffect(() => {
    if (state.fetchedData.profileData) {
      const { practiceAreas, profileData, images } = state.fetchedData;

      // Map practiceAreas to the format expected by react-select
      const areasOptions = practiceAreas.map(areaObj => ({
        value: areaObj.area,
        label: areaObj.area,
      }));

      setFormData((prevFormData) => ({
        ...prevFormData,
        areas: areasOptions || prevFormData.areas,
        barAffiliation: profileData.barAffiliation || prevFormData.barAffiliation,
        barAssociation: profileData.barAssociation || prevFormData.barAssociation,
        barCardImages: {
          frontImage: images.frontImage ? images.frontImage : prevFormData.barCardImages.frontImage,
          backImage: images.backImage ? images.backImage : prevFormData.barCardImages.backImage,
        },
      }));

      const baseURL = `http://localhost:5000`;

      if (images.frontImage) {
        setFrontImageURL(`${baseURL}${images.frontImage}`);
        console.log("Front Image URL:", `${baseURL}${images.frontImage}`);
      } else {
        console.log("Front Image not found");
      }

      if (images.backImage) {
        setBackImageURL(`${baseURL}${images.backImage}`);
      }
    
    }
  }, [state.fetchedData]);
  

  const practiceAreas = [
    "Administrative Law", "Admiralty & Aviation Law", "Agribusiness", "Alternative Dispute Resolution", "Appellate Practice", "Arbitration Law", "Asset Management Company", "Asset Search & Background Investigation", "Attestation & Legalization Services", 
    "Banking & Finance", "Blue Collar Crime", "Brokerage Company", "Business Law", "Business Tax Planning", "Capital Markets", "Child Abduction Law", "Child Adoption", "Child Custody Law", "Citizenship & Residency", 
    "Civil Law & Civil Rights", "Commercial Law", "Company Law", "Company Secretarial Services", "Competition Law", "Constitutional Law", "Construction Company", "Consumer Protection Law", "Contract Law & Enforcement", "Copyright Law", 
    "Corporate Governance", "Corporate Law", "Criminal Law", "Customs Law", "Cyber Crime Law", "Debt Collection & Recovery", "Defamation Law", "Design Registration Services", "Divorce Law", "Drafting & Vetting", 
    "Due Diligence Services", "E-Commerce Law", "E-Contract Services", "E-Governance Law", "E-Waste Law", "Employment Law", "Energy Law", "Energy Projects", "Enforcement of Foreign Judgment", "Environmental Law", 
    "Escrow Services", "Estate Planning Law", "Expert Witnesses", "Family Law", "Federal Excise Law", "Foreign Exchange Company", "Franchising Law", "Human Resource Manual", "Human Rights Law", "Immigration & Citizenship", 
    "Import & Export Registration", "Income Tax Law", "Inheritance & Succession Law", "Insolvency Law", "Insurance Company", "Insurance Law", "Intellectual Property Enforcement", "Intellectual Property Law", "International Business Transactions", 
    "International Law", "International Tax Law", "Investment Law", "IT Services Company", "Joint Ventures", "Labour Law", "Land Acquisition Law", "Leasing Law", "Legal Translation Services", "Limited Liability Partnership", 
    "Liquefied Natural Gas Company", "Litigation", "Mediation Law", "Mergers & Acquisitions", "Mirror Judgment / Order", "Modaraba Company", "Mortgage Law", "Non Banking Finance Company", "Non Governmental Organization", "Offshore Company", 
    "Oil & Gas Law", "Patent Law", "Payroll Services", "Personal Injury", "Pharmaceutical Company", "Process Service", "Provident Fund", "Provisional Refusal Services", "Real Estate Law", "Recruitment Company", 
    "Sales Tax Law", "Sales Tax Refund", "Sales Tax Returns", "Satellite Launch Contracts", "Security Services Company", "Telecommunication Company", "Textile Company", "Trademark Law", "Travel Agency", "University Setup", "White Collar Crime"
  ];

  const handleImageChange = (e, type) => {
    const imageFile = e.target.files[0];
    if (!imageFile || !imageFile.type.match('image/*')) {
      toast.error('Please select a valid image file.');
      return;
    }
    else{
      if (type === 'front') {
        setFormData({
          ...formData,
          barCardImages: { ...formData.barCardImages, frontImage: imageFile },
        });
        setFrontImageURL(URL.createObjectURL(imageFile));
      } else {
        setFormData({
          ...formData,
          barCardImages: { ...formData.barCardImages, backImage: imageFile },
        });
        setBackImageURL(URL.createObjectURL(imageFile));
      }
  }
  };

  const handlenextpage = async (e) => {
    e.preventDefault();
    const barAssociation = formData.barAssociation.trim();
    const words = barAssociation.split(/\s+/);
    if (barAssociation.length < 11 || words.length < 2) {
      toast.error("Bar association is invalid.");
      return;
    }
    if (!frontImageURL) {
      toast.error('Bar card front image is required.');
      return;
    }
    if (!backImageURL) {
      toast.error('Bar card back image is required.');
      return;
    }

    dispatch({ type: 'UPDATE_FORM_1', payload: formData });
    setLoading(true);
    setTimeout(() => {
      console.log("Form 1:", formData);
      navigate('/editlawyerSignup2');
    }, 500);
  }

  return (
    <div className="signup-wrapper3">
      <div className="wrapper3">
        <form onSubmit={handlenextpage}>
          <h1>Lawyer Signup</h1>
          <div className="input-box3" id="practicearea">
            <label className="label">Update your legal practice areas:</label>
          </div>

          <Select
            className="reactselect"
            value={formData.areas}
            onChange={(areas) => setFormData({ ...formData, areas })}
            options={practiceAreas.map(area => ({ label: area, value: area }))}
            isSearchable
            isMulti
            placeholder="Search or select legal practice area..."
            required
          />

          <div className="input-box3" id="Barassocation">
            <label className="label">Update your Affiliated Bar Council:</label>
            <select
              id="barcouncil"
              value={formData.barAffiliation}
              onChange={(e) => setFormData({ ...formData, barAffiliation: e.target.value })}
              required
            >
              <option value="">Select Bar Council</option>
              <option value="Punjab Bar Council">Punjab Bar Council</option>
              <option value="Sindh Bar Council">Sindh Bar Council</option>
              <option value="Khyber Pakhtunkhwa Bar Council">Khyber Pakhtunkhwa Bar Council</option>
              <option value="Balochistan Bar Council">Balochistan Bar Council</option>
              <option value="Islamabad Bar Council">Islamabad Bar Council</option>
              <option value="Azad Jammu & Kashmir Bar Council">Azad Jammu & Kashmir Bar Council</option>
              <option value="Gilgit Baltistan Bar Council">Gilgit Baltistan Bar Council</option>
            </select>
          </div>

          <div className="input-box3">
            <label className="label">Updated your Affiliated Bar Association:</label>
            <input
              type="text"
              className="bar-association"
              name="barAssociation"
              placeholder="E.g: Rawalpindi bar association, etc."
              value={formData.barAssociation}
              required
              onChange={(e) => setFormData({ ...formData, barAssociation: e.target.value })}
            />
          </div>

          {/* Front image input for bar affiliation verification */}
          <div className="input-box3" id="img1">
            <label id="label-image1">Upload new front image of your bar card:</label>
            <input
              type="file"
              name="Front-image"
              id="uploadBtn"
              onChange={(e) => handleImageChange(e, 'front')}
              // required
              accept=".png, .jpg, .jpeg"
            />
             <label htmlFor="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>
            
            {frontImageURL ? (
              <img className="image" src={frontImageURL} alt="Front Image of Card" />
            ) : (
              <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
            )}
          </div>

          {/* Back image input for bar affiliation verification */}
          <div className="input-box3" id="img2">
            <label id="label-image2">Upload new back image of your bar card:</label>
            <input
              type="file"
              name="Back-image"
              id="uploadBtn2"
              onChange={(e) => handleImageChange(e, 'back')}
              // required
              accept=".png, .jpg, .jpeg"
            />
              <label htmlFor="uploadBtn2" className="upload-btn2"><i class="fa-solid fa-upload"></i>Upload Image</label>
            {backImageURL ? (
              <img className="image2" src={backImageURL} alt="Back Image of Card" />
            ) : (
              <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
          </div>

          {loading ? (
            <div className="loading-spinner">
              <ClipLoader color={"#007bff"} loading={loading} size={100} />
            </div>
          ) : (
            <button type="submit">Next</button>
          )}

          <div className="register-link3">
            <p>Form 1 of 7</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;
