import React, { useState, useEffect } from "react";
import "./Edit_LawyerSignup4.css";
import "../../styles/central.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import TimePicker from "react-time-picker";
import "react-time-picker/dist/TimePicker.css";
import defaultImageIcon from "../../styles/images/document4.png";
import ClipLoader from "react-spinners/MoonLoader";
import { useFormContext } from "./Edit_FormContext"; 
import { ToastContainer, toast } from 'react-toastify';


const Register = () => {
  const navigate = useNavigate();
  const [image, setImage] = useState();
  const { state, dispatch } = useFormContext();
  const [loading, setLoading] = useState(false); // Initialize loading state as false
  const [certificateImage,setcertificateImage]=useState(null)
  const [approvalImage,setapprovalImage]=useState(null)
  
  const [formData, setFormData] = useState({
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts:"",
    highCourt:"",
    certificates:{
      certificateImage: null,
      approvalImage: null,
    }
  });
  useEffect(() => {
    if (state.fetchedData.profileData) {
      const { profileData, images } = state.fetchedData;

      setFormData((prevFormData) => ({
        ...prevFormData,
        currentPosition: profileData.currentPosition || prevFormData.currentPosition,
        durationOfPractice: profileData.durationOfPractice || prevFormData.durationOfPractice,
        lowerCourts: profileData.lowerCourts || prevFormData.lowerCourts,
        highCourt: profileData.highCourt || prevFormData.highCourt,
        certificates: {
          certificateImage: images.certificateImage ? images.certificateImage : prevFormData.certificates.certificateImage,
          approvalImage: images.approvalImage ? images.approvalImage: prevFormData.certificates.approvalImage,
        },
      }));

      const baseURL = `http://localhost:5000`;

      if ( images.certificateImage) {
        setcertificateImage(`${baseURL}${images.certificateImage}`);
        
      } 

      if (images.approvalImage) {
        setapprovalImage(`${baseURL}${images.approvalImage}`);
      }
    
    }
   
  }, [state.fetchedData]); 

  
  const years = [];
    for (let year = 1980; year <= new Date().getFullYear(); year++) {
    years.push(year.toString());
    }
  const highCourts = [
    { name: "Lahore High Court", principalSeat: "Lahore", benches: ["Bahawalpur", "Multan", "Rawalpindi"] },
    { name: "Sindh High Court", principalSeat: "Karachi", benches: ["Sukkur", "Hyderabad", "Larkana", "Mirpurkhas"] },
    { name: "Peshawar High Court", principalSeat: "Peshawar", benches: ["Abbottabad", "Mingora", "Dera Ismail Khan", "Bannu"] },
    { name: "Balochistan High Court", principalSeat: "Quetta", benches: ["Sibi", "Turbat"] },
    { name: "Islamabad High Court", principalSeat: "Islamabad", benches: [] },
    { name: "Azad Kashmir High Court", principalSeat: "Muzaffarabad", benches: ["Kotli", "Mirpur", "Rawalakot"] },
    { name: "Gilgit-Baltistan Chief Court", principalSeat: "Gilgit", benches: ["Skardu"] },
  ];

  // Function to handle image selection
  const  handleFrontImageChange = (e) => {
    const imageFile = e.target.files[0];
    if (!imageFile || !imageFile.type.match('image/*')) {
      toast.error('Please select a valid image file.');
      return;
   }
    setFormData({
      ...formData,certificates: {...formData.certificates, certificateImage: imageFile,},
    });
    if (imageFile) { // Optional preview
          
          setcertificateImage(URL.createObjectURL(imageFile))
         
        }
  };
  const  handleBackImageChange = (e) => {
    const imageFile = e.target.files[0];
    if (!imageFile || !imageFile.type.match('image/*')) {
      toast.error('Please select a valid image file.');
      return;
   }
    setFormData({
      ...formData,certificates: {...formData.certificates, approvalImage: imageFile,},
    });
    if (imageFile) { // Optional preview
          
          setapprovalImage(URL.createObjectURL(imageFile))
         
        }
  };
  const handlenextpage =  async (e) => {
    e.preventDefault();

    const lowerCourts = formData.lowerCourts.trim();
    const words = lowerCourts.split(/\s+/);            
    if (lowerCourts.length < 7 || words.length < 2 ) {
        toast.error("Lower court names are improper.");
        return;
    }
    if(!formData.certificates.certificateImage){
      toast.error("Certificate Image is required");
      return;
    }
    if(!formData.certificates.approvalImage){
      toast.error("Approval Image is required");
      return;
    }

    dispatch({ type: 'UPDATE_FORM_4', payload: formData });
  
    setLoading(true);
    setTimeout(() => {
      console.log("Form 4:",formData)
      // Navigate to the next page
      navigate('/editlawyerSignup5');
    }, 500);
    
  }

  const handlePositionChange = (selectedOption) => {
    setFormData({ ...formData, currentPosition: selectedOption.value });
  };

  return (
    <div className="signup-wrapper8">
      <div className="wrapper8">
        <form onSubmit={handlenextpage}>
          <h1>Lawyer Signup</h1>

          <div className="input-box8">
            <label className="label">Update your current position:</label>
            
             <select
                    name="current-position"
                    className="current-position"
                    value={formData.currentPosition}
                    onChange={(e) => setFormData({ ...formData, currentPosition: e.target.value })}
                    required
                  >
                      <option value="">Select Current  Position</option>
                      <option value="Enrolled Lawyer/Advocate">Enrolled Lawyer/Advocate</option>
                      <option value="Advocate High Court">Advocate High Court</option>
                      <option value="Advocate Supreme Court">Advocate Supreme Court</option>
                      <option value="Senior Advocate Supreme Court">Senior Advocate Supreme Court</option>                
              </select>
          </div>

     
            <div>
              <div className="input-box8">
              <label className="label">Update your start year as practicing lawyer:</label>
              <select
                className="date"
                name="date"
                value={formData.durationOfPractice}
                onChange={(e) => setFormData({ ...formData, durationOfPractice: e.target.value })}
                required
            >
                <option value="">Select start year</option>
                {years.map((year) => (
                <option key={year} value={year}>
                    {year}
                </option>
                ))}
             </select>
            </div>
            <div className="input-box8">
                <label className="label">Update your practicing lower court names:</label>
                <input 
                type="text" 
                name="Lower_court_names"
                className="court-names"
                value={formData.lowerCourts} 
                placeholder="Lower court name 1,Lower court name2,...etc."
                onChange={(e) => setFormData({ ...formData, lowerCourts: e.target.value })}
                required
                />
            </div>

            </div>
            
        
    {formData.currentPosition === "Enrolled Lawyer/Advocate" && (
            <div>
                
              
            <div className="input-box8" id="img1">
                <label id="label-image1">Update Certificate of completion of six months apprenticeship</label>
                <input
                    type="file"
                    id="uploadBtn"
                    name="Front-image"
                    onChange={handleFrontImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>
                
            
             {certificateImage ? (
                <img className="image" src={certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>

            <div className="input-box8" id="img2">
                <label id="label-image2">Update Certificate issued by the Bar Council:</label>
                <input
                    type="file"
                    id="uploadBtn2"
                    name="Back-image"
                    onChange={handleBackImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn2" className="upload-btn2"><i class="fa-solid fa-upload"></i>Upload Image</label>
                
               {approvalImage ? (
                    <img className="image2" src={approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>

            </div>
          )}
          {formData.currentPosition === "Advocate High Court" && (
            <div>
               <div className="input-box8">
                <label className="label">Update your practicing high court name:</label>
                <select
                    name="high-court"
                    className="high-court"
                    value={formData.highCourt}
                    onChange={(e) => setFormData({ ...formData, highCourt: e.target.value })}
                    required
                  >
                    <option value="">Select High Court</option>
                    {highCourts.map((court) => (
                      <React.Fragment key={court.name}>
                        <option value={court.name}>{court.name} (Principal Seat) - {court.principalSeat}</option>
                        {court.benches.map((bench) => (
                          <option key={`${court.name}-${bench}`} value={`${court.name} ${bench} Bench`}>{bench} Bench</option>
                        ))}
                      </React.Fragment>
                    ))}
                  </select>
            </div>

           
              
            <div className="input-box8" id="img1">
                <label id="label-image1">Update two years Confirmation of practice in the lower Courts:</label>
                <input
                    type="file"
                    id="uploadBtn"
                    name="Front-image"
                    onChange={handleFrontImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>
                
            
             {certificateImage ? (
                <img className="image" src={certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>

            <div className="input-box8" id="img2">
                <label id="label-image2">Update Application Acknowledgment from High Court Judges:</label>
                <input
                    type="file"
                    id="uploadBtn2"
                    name="Back-image"
                    onChange={handleBackImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn2" className="upload-btn2"><i class="fa-solid fa-upload"></i>Upload Image</label>


               {approvalImage ? (
                    <img className="image2" src={approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>

            </div>
          )}

          {formData.currentPosition === "Advocate Supreme Court" && (
            <div>
               <div className="input-box8">
                <label className="label">Update your practicing high court name:</label>
                <select
                    name="high-court"
                    className="high-court"
                    value={formData.highCourt}
                    onChange={(e) => setFormData({ ...formData, highCourt: e.target.value })}
                    required
                  >
                    <option value="">Select High Court</option>
                    {highCourts.map((court) => (
                      <React.Fragment key={court.name}>
                        <option value={court.name}>{court.name} (Principal Seat) - {court.principalSeat}</option>
                        {court.benches.map((bench) => (
                          <option key={`${court.name}-${bench}`} value={`${court.name} ${bench} Bench`}>{bench} Bench</option>
                        ))}
                      </React.Fragment>
                    ))}
                  </select>
            </div>

            <div className="input-box8" id="img1">
                <label id="label-image1">Update seven years Confirmation of practice at the High Courts:</label>
                <input
                    type="file"
                    id="uploadBtn"
                    name="Front-image"
                    onChange={handleFrontImageChange}
                    accept=".png, .jpg, .jpeg"         
                />
                <label for="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>

            
             {certificateImage ? (
                <img className="image" src={certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>
            <div className="input-box8" id="img2">
                <label id="label-image2">Update Approval Notification from Supreme Court Judges' Panel:</label>
                <input
                    type="file"
                    id="uploadBtn2"
                    name="Back-image"
                    onChange={handleBackImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn2" className="upload-btn2"><i class="fa-solid fa-upload"></i>Upload Image</label>


               {approvalImage ? (
                    <img className="image2" src={approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>
            

          </div>
             
          )}
          {formData.currentPosition === "Senior Advocate Supreme Court" && (
            <div>
               <div className="input-box8">
                <label className="label">Update your practicing high court name:</label>
                <select
                    name="high-court"
                    className="high-court"
                    value={formData.highCourt}
                    required
                    onChange={(e) => setFormData({ ...formData, highCourt: e.target.value })}
                  >
                    <option value="">Select High Court</option>
                    {highCourts.map((court) => (
                      <React.Fragment key={court.name}>
                        <option value={court.name}>{court.name} (Principal Seat) - {court.principalSeat}</option>
                        {court.benches.map((bench) => (
                          <option key={`${court.name}-${bench}`} value={`${court.name} ${bench} Bench`}>{bench} Bench</option>
                        ))}
                      </React.Fragment>
                    ))}
                  </select>
               </div>
                <div className="input-box8" id="img1">
                <label id="label-image1">Update fifteen years Confirmation of practice in the Supreme Court:</label>
                <input
                    type="file"
                    id="uploadBtn"
                    name="Front-image"
                    onChange={handleFrontImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>

 
            
             {certificateImage ? (
                <img className="image" src={certificateImage} alt="Front Image of Card" />
                ):(
                  <img className="image" src={defaultImageIcon} alt="Default Image Icon" />
              )}
            </div>
            <div className="input-box8" id="img2">
                <label id="label-image2">Update Approval Notification from Supreme Court Judges' Panel:</label>
                <input
                    type="file"
                    id="uploadBtn2"
                    name="Back-image"
                    onChange={handleBackImageChange}
                    accept=".png, .jpg, .jpeg"
                />
                <label for="uploadBtn2" className="upload-btn2"><i class="fa-solid fa-upload"></i>Upload Image</label>


               {approvalImage ? (
                    <img className="image2" src={approvalImage} alt="Back Image of Card" />
               ):(
                <img className="image2" src={defaultImageIcon} alt="Default Image Icon" />
            )}
            </div>
                
           
            
            </div>

             
          )}

          {loading ? (
            <div className="loading-spinner">
              <ClipLoader color={"#007bff"} loading={loading} size={100} />
            </div>
          ) : (
            <button type="submit">
              Next
            </button>
          )}
          <div className="register-link8">
            <p>Form 4 of 7</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register