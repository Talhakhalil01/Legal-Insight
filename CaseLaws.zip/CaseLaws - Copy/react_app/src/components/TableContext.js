import React, { createContext, useContext, useState } from 'react';

const TableContext = createContext();

export const TableProvider = ({ children }) => {
  const [tableData, setTableData] = useState(null);
  const [queryData, setQueryData] = useState(null);
  const [search, setSearch] = useState("");
  const [loading2 , setLoading2] = useState(false);


  const updateTableData = (newData) => {
    setTableData(newData);
  };
  const updateQueryData = (newData2) => {
    setQueryData(newData2);
  };
  const updateSearch = (newData3) => {
    setSearch(newData3);
  };
  const updateLoading = (loading4) => {
    setLoading2(loading4);
  };
  

  return (
    <TableContext.Provider value={{ tableData,queryData,search,loading2, updateTableData,updateQueryData,updateSearch,updateLoading }}>
      {children}
    </TableContext.Provider>
  );
};

export const useTable = () => {
  const context = useContext(TableContext);
  if (!context) {
    throw new Error('useTable must be used within a TableProvider');
  }
  return context;
};
