import React, { useState, useEffect } from "react"
import "../styles/LawyerSignupGuide.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import 'react-phone-number-input/style.css'
import Select from 'react-select';
import { PropagateLoader } from 'react-spinners';
import { BallTriangle } from 'react-loader-spinner';
import ClipLoader from "react-spinners/MoonLoader";
import { useFormContext } from "./FormContext"; 
import { ToastContainer, toast } from 'react-toastify';

const Register = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const { state, dispatch } = useFormContext();
  const [checkbox,setcheckbox]=useState(false);

  const handlenextpage =  () => {
    navigate('/lawyerSignup');
  }
  const handlevaluechange =()=> {
    setcheckbox(!checkbox);
  }
  return (
    <div className="signup-wrapper01">
        <div className="wrapper01">
      <form>
        <h1>Welcome to Lawyer Signup</h1>
        <h2>Guidance Plan</h2>
        <ul>
          <li className="input-box01" id="label01">
            <strong>Introduction and Purpose:</strong> Welcome to the Lawyer Signup process. This profile will help showcase your expertise and connect you with potential clients. It's essential to provide accurate and complete information to create a compelling profile that attracts clients.
          </li>
          <li className="input-box01">
            <strong>Overview of Forms:</strong> 
            <ul>
              <li>Form 1: Basic Information - Provide essential details such as your name, email, and bar association affiliation.</li>
              <li>Form 2: Contact Details - Share your contact information and current location for better communication.</li>
              <li>Form 3: Education and Qualifications - Detail your legal education, graduation year, and any specialized degrees.</li>
              <li>Form 4: Professional Experience - Describe your current position, duration of practice, and courts you have appeared in.</li>
              <li>Form 5: Certifications and Experience - Highlight your bar license number, specialized certifications, and notable cases.</li>
              <li>Form 6: Office Details and Consultation - Provide your office address, hours of operation, and consultation fees.</li>
              <li>Form 7: Social Media Links - Share your social media profiles for networking and visibility.</li>
            </ul>
          </li>
          <li className="input-box01">
            <strong>Skipping Fields:</strong> Fields labeled 'if any' can be skipped if you don't have specific details. However, it's advisable to provide as much information as possible to enhance your profile and increase your chances of attracting clients.
          </li>
          <li className="input-box01">
            <strong>Data Accuracy:</strong> The data you enter can make a significant difference in attracting or missing potential clients. Ensure all information provided is accurate and truthful. False data may lead to the suspension or blocking of your profile, affecting your credibility and reputation.
          </li>
          <li className="input-box01">
            <strong>Data Privacy and Security:</strong> Rest assured, your personal and professional information will be handled securely. We prioritize your privacy and adhere to strict data protection standards. Your data will only be used for the purpose of creating your profile and connecting you with potential clients.
          </li>
          <li className="input-box01">
            <strong>Contact Support:</strong> If you encounter any issues during the signup process or have questions, please feel free to contact our support team via WhatsApp at +923035562974. We're here to assist you and ensure a smooth signup experience.
          </li>
          <div className="input-box01" id="label-last">
            <input type="checkbox" checked={checkbox} onChange={handlevaluechange} required /> I have read and understood the guidance plan and accept the terms and conditions. By checking this box, you acknowledge your agreement to comply with the guidelines provided.
          </div>
        </ul>
        {checkbox ? 
        (<button type="button" className="button1" onClick={handlenextpage}>Next</button>)
        :
        (<button type="button" className="button2" disabled>Next</button>)}
        </form>
      </div>
    </div> 
  )
};

export default Register;
