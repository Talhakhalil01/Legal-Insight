import React, { useState,useEffect } from "react"
import "../styles/signup.css"
import '../styles/central.css';
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import { MdEmail } from "react-icons/md";




const Signup = () => {
  
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: ""
  });
  
 axios.defaults.withCredentials=true;
  useEffect(() => {
    axios.get('http://localhost:5000')
      .then(res => {
        console.log(res);
        if(res.data.valid){
         
        }
        else{
               
        }
      })
      .catch((err) => {
        console.error(err);
      });
  }, []);

  const [showPassword, setShowPassword] = useState(false);
 

  const handleSignin=()=>{
    navigate('/signin');
  }
  
  const handleSubmit = async (event) => {
    event.preventDefault();
  
   
    
        const formData = new FormData(event.target);
        const data = {};
        formData.forEach((value, key) => {
          data[key] = value;
        });
        if (!data.fullName || !data.email || !data.password) {
          // Handle validation error, e.g., show an error message to the user
          console.log("Please enter both fullName,email and password.");
          alert('Username,email and password required');
          return;
        }
        else{
              try {
                const response = await fetch('http://localhost:5000/signup', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify(data),
                });
            
                if (response.ok) {
                  console.log('Form submitted successfully');
                  setFormData({
                    fullName: "",
                    email: "",
                    password: ""
                  });
                
                  // alert('Account created successfully');
                  navigate('/signin');
                  
                  
                } else {
                  console.error('Failed to submit form');
                }
              } catch (error) {
                console.error('Error submitting form:', error.message);
              }
      }
  };
  
    return (
    <div className="signup-wrapper">
      <div className="wrapper">
        <form action="" onSubmit={handleSubmit}>
          <h1>Sign Up</h1>

          <div className="input-box">
            <input 
            type="email"
            placeholder="Email"
            required
            name="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
            <MdEmail className="icon"/>
          </div>

          <div className="input-box">
            <input
             type="text"
              placeholder="Username"
              required
              name="fullName"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}/>
            <FaUser className="icon"/>

          </div>

          <div className="input-box">
            <input 
            type="password" 
            placeholder="Password" 
            required
            name="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            />
            <FaLock className="icon"/>
          </div>

          <button type="submit">Register</button>
          <div className="register-link">
            <p>Already have an account?<a href="#" onClick={handleSignin}>Sign In</a></p>
          </div>
        </form>
      </div>
     </div> 
    )
  

        
};
export default Signup;