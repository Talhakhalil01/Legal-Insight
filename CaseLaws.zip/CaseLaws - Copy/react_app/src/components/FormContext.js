import React, { createContext, useContext, useReducer } from 'react';

const FormContext = createContext();


const initialState = {
  form1: {
    areas: "",
    barAffiliation:"",
    barAssociation:"",
    barCardImages: {
      frontImage: null,
      backImage: null,
    },
  },
  form2: {
    name: "",
    email: "",
    phone: "",
    gender: "",
    province: "",
    city: ""
    
  },
  form3: {
    education: "",
    graduationYear: "",
    LLB: "",
    LLM:"",
    LLD:"",
    degrees:{
        LLBdegree: null,
        LAWGATresult: null,
    },
  },
  form4: {
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts: "",
    highCourt: "",
    certificates:{
      certificateImage: null,
      approvalImage: null,
    },
  },
  form5: {
    licenseNumber: "",
    certifications: "",
    caseExperience: "",
    notableCases: "",
    successStories: ""
  },
  form6: {
    officeAddress: "",
    officeHours: {
      Monday: { startTime: "09:00", endTime: "17:00" },
      Tuesday: { startTime: "09:00", endTime: "17:00" },
      Wednesday: { startTime: "09:00", endTime: "17:00" },
      Thursday: { startTime: "09:00", endTime: "17:00" },
      Friday: { startTime: "09:00", endTime: "17:00" },
      Saturday: { startTime: "00:00", endTime: "00:00" },
      Sunday: { startTime: "00:00", endTime: "00:00" }
    },
    consultationModes: [],
    consultationFees: {},
   },
   form7: {
    lawyerImage: null,
    facebook: "",
    whatsapp: "+92",
    linkedin: ""
  }
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'UPDATE_FORM_1':
      return { ...state, form1: { ...state.form1, ...action.payload } };
    case 'UPDATE_FORM_2':
      return { ...state, form2: { ...state.form2, ...action.payload } };
    case 'UPDATE_FORM_3':
      return { ...state, form3: { ...state.form3, ...action.payload } };
    case 'UPDATE_FORM_4':
      return { ...state, form4: { ...state.form4, ...action.payload } };
    case 'UPDATE_FORM_5':
      return { ...state, form5: { ...state.form5, ...action.payload } };
    case 'UPDATE_FORM_6':
      return { ...state, form6: { ...state.form6, ...action.payload } };
    case 'UPDATE_FORM_7':
      return { ...state, form7: { ...state.form7, ...action.payload } };
    case 'RESET_FORM':
        return initialState; 
    default:
      return state;
  }
};

// Step 3: Wrap Forms with Context Provider
export const FormProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const fetchDataAndSendToServer = () => {
    // Fetch data from state and send it to the server
    console.log("Data sent to server:", state);
    
  };

  return (
    <FormContext.Provider value={{ state, dispatch, fetchDataAndSendToServer }}>
      {children}
    </FormContext.Provider>
  );
};

// Step 4: Use Context in Forms
export const useFormContext = () => useContext(FormContext);

// Step 5: Send Data to Server
// At the end of the last form, retrieve data from the context and send it to the server
