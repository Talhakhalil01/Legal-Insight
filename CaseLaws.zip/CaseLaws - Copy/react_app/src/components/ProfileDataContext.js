import React, { createContext, useContext, useReducer } from 'react';

const FormContext2 = createContext();

const initialState2 = {
  form1: {
    areas: "",
    barAffiliation:"",
    barAssociation:"",
    barCardImages: {
      frontImage: null,
      backImage: null,
    },
  },
  form2: {
    name: "",
    email: "",
    phone: "",
    gender: "",
    province: "",
    city: ""
    
  },
  form3: {
    education: "",
    graduationYear: "",
    LLB: "",
    LLM:"",
    LLD:"",
    degrees:{
        LLBdegree: null,
        LAWGATresult: null,
    },
  },
  form4: {
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts: "",
    highCourt: "",
    certificates:{
      certificateImage: null,
      approvalImage: null,
    },
  },
  form5: {
    licenseNumber: "",
    certifications: "",
    caseExperience: "",
    notableCases: "",
    successStories: ""
  },
  form6: {
    officeAddress: "",
    officeHours: {
      Monday: { startTime: "09:00", endTime: "17:00" },
      Tuesday: { startTime: "09:00", endTime: "17:00" },
      Wednesday: { startTime: "09:00", endTime: "17:00" },
      Thursday: { startTime: "09:00", endTime: "17:00" },
      Friday: { startTime: "09:00", endTime: "17:00" },
      Saturday: { startTime: "00:00", endTime: "00:00" },
      Sunday: { startTime: "00:00", endTime: "00:00" }
    },
    consultationModes: [],
    consultationFees: {},
   },
   form7: {
    lawyerImage: null,
    facebook: "",
    whatsapp: "+92",
    linkedin: ""
  },
  fetchedData: {}
};

const reducer2 = (state2, action) => {
  switch (action.type) {
    case 'UPDATE_FORM_1':
      return { ...state2, form1: { ...state2.form1, ...action.payload } };
    case 'UPDATE_FORM_2':
      return { ...state2, form2: { ...state2.form2, ...action.payload } };
    case 'UPDATE_FORM_3':
      return { ...state2, form3: { ...state2.form3, ...action.payload } };
    case 'UPDATE_FORM_4':
      return { ...state2, form4: { ...state2.form4, ...action.payload } };
    case 'UPDATE_FORM_5':
      return { ...state2, form5: { ...state2.form5, ...action.payload } };
    case 'UPDATE_FORM_6':
      return { ...state2, form6: { ...state2.form6, ...action.payload } };
    case 'UPDATE_FORM_7':
      return { ...state2, form7: { ...state2.form7, ...action.payload } };
    case 'UPDATE_FORM_8':
        return { ...state2, form8: { ...state2.form8, ...action.payload } };
    case 'UPDATE_FETCHED_DATA':
        return { ...state2, fetchedData: action.payload }
        
    case 'RESET_FORM':
        return initialState2; 
    default:
      return state2;
  }
};

// Step 3: Wrap Forms with Context Provider
export const DataProvider = ({ children }) => {
  const [state2, dispatch2] = useReducer(reducer2, initialState2);

  const fetchData = () => {
    console.log("Data sent to server:", state2);
    
  };

  return (
    <FormContext2.Provider value={{ state2, dispatch2, fetchData}}>
      {children}
    </FormContext2.Provider>
  );
};

// Step 4: Use Context in Forms
export const useFormContext2 = () => useContext(FormContext2);

