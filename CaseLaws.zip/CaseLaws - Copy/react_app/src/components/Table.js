import React, { useState,useEffect } from "react"
import Judgement from './Judgement';
import { useNavigate,useLocation } from "react-router-dom";
import axios from 'axios';
import { useTable } from './TableContext'
import {useUser} from './UserContext'
import '../styles/advancesearchbar.css';
import '../styles/Table.css';
import ClipLoader from "react-spinners/SyncLoader";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { IoAddSharp } from "react-icons/io5";
import { FiMinus } from "react-icons/fi";



const Table = () => {
  const [selectedJudgement, setSelectedJudgement] = useState(null);
  const [searchButtonClicked, setSearchButtonClicked] = useState(false);
  const [userData, setUserData] = useState('');
  const navigate = useNavigate();
  const [bookmarkedCases, setBookmarkedCases] = useState([]);
  const { userdata, login, logout } = useUser();
  const { tableData, updateTableData } = useTable()
  const { queryData, updateQueryData } = useTable()
  const [tableData2, updateTableData2] = useState(null);
  const [numCases, setNumCases] = useState("50");
  const[tables,setTables]=useState('')
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchQuery, setSearchQuery] = useState(queryData || '');
  const {search, updateSearch} = useTable();
  const {loading2, updateLoading} = useTable();
  const location = useLocation();

  

  useEffect(() => {
      setSearchQuery(queryData);
  }, [queryData]);

  useEffect(() => {
    
    updateTableData2(tableData);
    if(tableData)
    {
      console.log("Table data is:::",tableData.length)
     
    }
    else{console.log("No data in table....................")}
  }, [tableData]);

  
   //Advance searchbar.js code//
   const [showOptions, setShowOptions] = useState(false);

   const toggleAdvanceOptions = () => {
     setShowOptions(!showOptions);
   };
   const [searchData, setSearchData] = useState({
     caseno: '',
     casesubject: '',
     casetitle: '',
     judgename: '',
     judgementdate: '',
     courtname: '',
     casecitation: '',
     SSCitation:'',
     keyword: '',
   });

   const updateQuery = () => {
    // Filter out fields with empty values
    const nonEmptyFields = Object.fromEntries(
      Object.entries(searchData).filter(([key, value]) => value.trim() !== '')
    );

     updateQueryData(nonEmptyFields);
  };
   const handleSearch = async (e) => {
     e.preventDefault(); // Prevent the default form submission behavior
     
 
     // Collect form data
     const formData = new FormData(e.target);
     const searchData = {};
     formData.forEach((value, key) => {
       searchData[key] = value;
     });
 
     // Send the form data to the server
     try {
       const response = await fetch('http://localhost:5000/search2', {
         method: 'POST',
         headers: {
           'Content-Type': 'application/json',
         },
         body: JSON.stringify(searchData),
       });
       if (!response.ok) {
         throw new Error('Failed to send form data to the server');
         updateTableData([]);
       }
       else
       {
            const searchData2 = await response.json();
            updateLoading(true); 
            console.log("Data received at advancesearchbar.js:", searchData2);
              updateTableData(searchData2);
              updateQuery();
              updateSearch("AdvanceSearchBar")

            setTimeout(() => {
                updateLoading(false);
            }, 700); 
           
       }
 
      
     } catch (error) {
       console.error('Error during search:', error);
       updateTableData([]);
      
     }
   };
   const handleChange = (e) => {
     const { name, value } = e.target;
     setSearchData((prevData) => ({
       ...prevData,
       [name]: value,
     }));
   };
   const handleClearData = () => {
     // Clear all the fields
     setSearchData({
       caseno: '',
       casesubject: '',
       casetitle: '',
       judgename: '',
       judgementdate: '',
       courtname: '',
       casecitation: '',
       keyword: '',
     });
   };

   //Table.js code/////////////////////////////////


  const openJudgementModal = (judgement) => {
    setSelectedJudgement(judgement);
  };

  const closeJudgementModal = () => {
    setSelectedJudgement(null);
  };

  
  const fetchCurrentUser = async () => {
    try {
      axios.defaults.withCredentials = true;
      const response = await axios.get('http://localhost:5000');
  
      if (response.data.valid) {
          setUserData(response.data.userData);
          return response.data.userData.username;
      } else {
        setUserData(null);
        return("null");
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      return null;
    }
  };
  
 
useEffect(() => {
  const getUserName = async () => {
    const userName = await fetchCurrentUser();
    if (userName) {
      fetchBookmarks(userName);
    } else {
      console.log("User not logged-in...");
    }
  };

  getUserName();
}, [userdata]);
  
  const isBookmarked = (caseNo) => {
    return bookmarkedCases.includes(caseNo);
  };
 
   // Fetch bookmarks when the component mounts
   const fetchBookmarks = async (userName) => {
    if (userName) {
      try {
        const response = await fetch(`http://localhost:5000/fetchbookmarks?userName=${userName}`);
        if (response.ok) {
          const bookmarkData = await response.json();
          setBookmarkedCases(bookmarkData);
       
        } else {
          console.error('Error fetching bookmarks:', response.statusText);
          toast.error("Error fetching bookmarks")
        }
      } catch (error) {
        console.error('Error fetching bookmarks:', error);
        console.log("Error fetching bookmarks")
      }
    } else {
      console.log("User not logged-in...");
    }
  };
     
  
   const handlesession = async (caseNo) => {
     if (bookmarkedCases.includes(caseNo)) 
    {
      toast.error('Case is already bookmarked!');

    } 
    else {
      if (userData) {
        // Prepare data to send to the server
        const bookmarkData = {
          userName: userData.username, // Assuming your user data has an 'email' property
          caseNo: caseNo,
        };
    
        try {
          // Send a POST request to the server to save the bookmark
          const response = await fetch('http://localhost:5000/bookmark', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(bookmarkData),
          });
    
          if (response.ok) {
            const responseData = await response.json();
            toast.success('Case Bookmarked Successfully!', { autoClose: 2000 });
            //console.log(responseData);
            setBookmarkedCases([...bookmarkedCases, caseNo]);
          } else {
            console.error('Error bookmarking judgment:', response.statusText);
            toast.error("Error bookmarking judgement")
          }
        } catch (error) {
          //console.error('Error bookmarking judgment:', error);
          toast.error('Error bookmarking judgment:', error);
        }
      } else {
        toast.error('Please Log in first');
        const currentPath = location.pathname.substring(1); // Remove leading slash
        navigate(`/signin?redirectTo=${currentPath}`);

      }
    }
    };

    // Function to handle button click and toggle searchButtonClicked
    const handleButtonClick = () => {
      setSearchButtonClicked(true); // Toggle the value
    };

    const handleInputChange = (e) => {
      setNumCases(e.target.value);
    };

 
    
    useEffect(() => {
      const handleShowButtonClick = async () => {
        if (tableData) {
          const totalRecords = tableData.length;
    
          // Calculate total pages
          const totalPages = Math.ceil(totalRecords / parseInt(numCases, 10));
          setTotalPages(totalPages);
    
          // Calculate the start and end indices of the current chunk
          let startIndex = (currentPage - 1) * parseInt(numCases, 10);
          let endIndex = Math.min(startIndex + parseInt(numCases, 10), totalRecords);
    
          // If startIndex exceeds totalRecords, set currentPage to 1
          if (startIndex >= totalRecords) {
            startIndex = 0;
            endIndex = Math.min(startIndex + parseInt(numCases, 10), totalRecords);
            setCurrentPage(1);
          }
    
          // Get the current chunk of data
          const currentChunk = tableData.slice(startIndex, endIndex);
    
          if (currentChunk) {
            console.log("Data at current chunk is:::", currentChunk.length);
          } else {
            console.log("No data in the current chunk");
          }
    
          updateTableData2(currentChunk);
    
          // Update the input field to display current page and total pages
          setTables(`${currentPage} of ${totalPages}`);
        }
      };
    
      handleShowButtonClick();
    }, [tableData, currentPage, numCases]);
    

    const handlePreviousClick = () => {
      if (currentPage > 1) {
        setCurrentPage((prevPage) => prevPage - 1);
      }
    };
    
    const handleNextClick = () => {
      if (currentPage < totalPages) {
        setCurrentPage((prevPage) => prevPage + 1);
      }
    };
  

    const stopWords = [
      "the", "a", "an", "in", "on", "at", "to", "from", "by", "is", "are", "was", "were", "be", "have", "has",
       "had", "will", "would", "could", "should", "may", "might", "do", "does", "did", "of", "and", "but", "or",
        "nor", "so", "as", "what", "which", "how", "their", "our", "its", "his", "her", "these", "those", "each",
         "some", "any", "all", "many", "most", "other", "same", "well", "only", "if", "else", "when", "where", "why",
          "how", "again", "further", "then", "once", "here", "there", "all", "any", "much", "most", "other", "same",
           "such", "than", "too", "very", "can", "for", "no", "more", "out", "up", "over", "down", "in", "into", "on",
            "upon", "with", "between"
    ];
   
    const highlightMatch = (text, searchQuery) => {
      if (!searchQuery) {
        return text;
      }
    
      let regexPattern;

      if (searchQuery.startsWith('"') && searchQuery.endsWith('"')) {
        
          const keywords = searchQuery.slice(1, -1);
          // Construct regex pattern for exact match
          regexPattern = `${keywords.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`;
      } 
      
      else {
        const words = searchQuery.split(' ').filter(word => word.trim() !== '');

        // Filter out stopwords
        const filteredWords = words.filter(word => !stopWords.includes(word.toLowerCase()));
        // Construct regex pattern to match individual words
        regexPattern = `\\b(${filteredWords.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})\\b`;
      }
    
      // Create regex object
      const regex = new RegExp(regexPattern, 'ig');
    
      // Highlight matched text
      return text.replace(regex, (match) => `^^^${match}^^^`);
    };
    
    
    const highlightMatch2 = (text,keywords) => {
      
      if (!searchQuery) 
      {
          return text;
      }
  
    
    const words = keywords.split(' ').filter(word => word.trim() !== '');
  
    // Filter out stopwords
    const filteredWords = words.filter(word => !stopWords.includes(word.toLowerCase()));

    const regex = new RegExp(`\\b(${filteredWords.join('|')})\\b`, 'ig');
  
    return text.replace(regex, (match) => (
      `^^^${match}^^^`
    ));
  
    
  };
    
    const RenderHighlightedText = ({ text,column }) => {
      
        if(search=="MainSearchbar")
          {
              const highlightedText = highlightMatch(text, searchQuery);
              const parts = highlightedText.split('^^^');
            
              return (
                <div>
                  {parts.map((part, index) => (
                    index % 2 === 0 ? (
                      <span key={index}>{part}</span>
                    ) : (
                      <span key={index} className="highlight">{part}</span>
                    )
                  ))}
                </div>
              );
          }
        
        else if(search=="AdvanceSearchBar")
        {
           // Check if the current column is present in the search query
            if (searchQuery && searchQuery[column]) {
              const keywords = searchQuery[column];
              const highlightedText = highlightMatch2(text, keywords);
              const parts = highlightedText.split('^^^');

              return (
                <div>
                  {parts.map((part, index) => (
                    index % 2 === 0 ? (
                      <span key={index}>{part}</span>
                    ) : (
                      <span key={index} className="highlight">{part}</span>
                    )
                  ))}
                </div>
                );
              } 
              else {
                // Handle the case when the column is not present in the search query
                return <span>{text}</span>;
              }

        }
        else{
          return <span>{text}</span>;
        }
    };
    
    
  
  
  return (

    <div className="advancesearchbar">
      <div className="advance-search-bar">
      <button type="button" className={`button4 ${showOptions ? 'showOptions' : ''}`} onClick={toggleAdvanceOptions}>
        {showOptions ? 'Hide Advance Search Options' : 'Show Advance Search Options'}
      </button>

      {showOptions && (
        <form onSubmit={handleSearch}>
          {/* Your existing input fields and buttons go here */}
          <input
          type="text"
          placeholder="Search with case no."
          className="caseno"
          name="caseno"
          value={searchData.caseno}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with case subject"
          className="casesubject"
          name="casesubject"
          value={searchData.casesubject}
          onChange={handleChange}
        />
         <input
          type="text"
          placeholder="Search with case title"
          className="casetitle"
          name="casetitle"
          value={searchData.casetitle}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with judge name"
          className="judgename"
          name="judgename"
          value={searchData.judgename}
          onChange={handleChange}
        />
       <input
          type="text"
          placeholder="Search with judgement date:DD-MM-YYYY"
          className="judgementdate"
          name="judgementdate"
          value={searchData.judgementdate}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with court name"
          className="courtname"
          name="courtname"
          value={searchData.courtname}
          onChange={handleChange}
        />
        <input
          type="text"
          placeholder="Search with case citation"
          className="casecitation"
          name="casecitation"
          value={searchData.casecitation}
          onChange={handleChange}
        />
        
        
        <input
          type="text"
          placeholder="Search with specific keyword"
          className="keyword"
          name="keyword"
          value={searchData.keyword}
          onChange={handleChange}
        />
        <button type="button" className='button5' onClick={handleClearData}>ClearData</button>
       <button type="submit" className='button3' onClick={handleButtonClick}>Search</button>
        </form>
      )}
    </div>

    {/*Display "No results found" message */}
    

    {/* Table.js code */ }
    <div className="table-container">
    {loading2 ? (
        <div className="loading-spinner">
              <div className="loader">
               <ClipLoader
                  loading={loading2}
                  color="#083e78"
                  margin={5}
                />
                </div>
                {/* <span>Please Wait</span> */}
            </div>
          ) : (
            

      <div className="table">

        {tableData2  && tableData2.length > 0 ? (
          
          <React.Fragment>

                 <div className="options">
                 <div className="show-cases">
                      <span>Show</span>
                      <select
                                className="show-num"
                                name="show-num"
                                value={numCases}
                                onChange={handleInputChange}
                                // onClick={handleShowButtonClick}
                                 
                               
                              >
                                <option value="20">20</option>
                                <option value="50">50</option>
                                <option value="70">70</option>
                                <option value="100">100</option>
                                <option value="150">150</option>
                                {/* <option value="100">100</option> */}
                               
                              
                              </select>
                      <span>Cases</span>
                      <button className="previous" onClick={handlePreviousClick}>Prev</button>
                      <input
                        type="text"
                        name="tables"
                        value={tables}
                        className="tables"
                        readOnly
                      />
                      <button onClick={handleNextClick}>Next</button>
                  </div>
                  

                 <div className="records-found">
                  Records found: {tableData ? tableData.length : 0}
                  </div>
                 </div>
                  
                              
          
          <table>
            <thead>
              <tr>
               <th className='th'>Sr No.</th>
                <th className='th'>Case no.</th>
                <th className='th'>Case Subject</th>
                <th className='th'>Case Title</th>
                <th className='th'>Author Judge</th>
                <th className='th'>Court</th>
                <th className='th'>Judgement Date</th>
                <th className='th'>Citation</th>
                <th className='th'>Other Citation</th> 
                <th className='th'>Judgement</th>
                <th className='th'>Bookmark</th>
              </tr>
            </thead>
            <tbody>
              {tableData2.map((row, index) => (
                <React.Fragment key={index}>
                  <tr> 
                      <td className='td sno'><div>{(currentPage - 1) * parseInt(numCases, 10) + index + 1}</div></td>
                      <td className='td cno'><div><RenderHighlightedText text={row.CaseNo} column={'caseno'}  /></div></td>        
                      <td className='td csub'><div><RenderHighlightedText text={row.CaseSubject} column={'casesubject'}/></div> </td>
                      <td className='td ctitle'><div><RenderHighlightedText text={row.CaseTitle} column={'casetitle'}/></div></td>
                      <td className='td ajudge'><div><RenderHighlightedText text={row.AuthorJudge} column={'judgename'}/></div></td>
                      <td className='td cname'><div><RenderHighlightedText text={row.Court} column={'courtname'}/></div></td>
                      <td className='td jdate'><div><RenderHighlightedText text={row.JudgementDate} column={'judgementdate'}/></div></td>
                      <td className='td scitation'><div><RenderHighlightedText text={row.SCCitation} column={'casecitation'}/></div></td> 
                      <td className='td citation'><div><RenderHighlightedText text={row.Citation} column={'casecitation'}/></div></td>           
                      <td className="button1"><button className="opencaselaw" onClick={() => openJudgementModal(<RenderHighlightedText text={row.Judgement} column={'keyword'}/>)}>
                            Read Full Text</button></td>
                      <td className="button2">
                      <button
                        className={isBookmarked(row.CaseNo) ? 'bookmarked' : 'bookmark'}
                        onClick={() => handlesession(row.CaseNo)}
                      >
                        {isBookmarked(row.CaseNo) ? 'Bookmarked' : 'Bookmark'}
                      </button>
                    </td>
                  </tr>
                  <tr>
                                         <td colSpan="11" className='tagline'>
                                            {row.Tagline ? <RenderHighlightedText text={"Tagline: " + row.Tagline} column={'keyword'} /> : null}
                                          </td>
                  </tr>
                </React.Fragment>
              ))}
            </tbody>
          </table>
          </React.Fragment>
           ) :(tableData2 !== null && tableData2.length === 0 ? (
            <div className="error">No Results Found</div>
          ) : null)}
        {selectedJudgement && (
          <Judgement judgement={selectedJudgement} onClose={closeJudgementModal} />
        )}
      </div>)}
    </div>
    
    </div>
    
    
  );
        
};

export default Table;






