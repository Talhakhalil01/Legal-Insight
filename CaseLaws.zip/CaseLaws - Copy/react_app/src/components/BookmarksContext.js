import React, { createContext, useContext, useState } from 'react';

const BookmarksContext = createContext();

export const BookmarksProvider = ({ children }) => {
  const [bookmarkedCases, setBookmarkedCases] = useState([]);

  const updateBookmarkedCases = (cases) => {
    setBookmarkedCases(cases);
  };

  return (
    <BookmarksContext.Provider value={{ bookmarkedCases, updateBookmarkedCases }}>
      {children}
    </BookmarksContext.Provider>
  );
};

export const useBookmarks = () => {
  return useContext(BookmarksContext);
};
