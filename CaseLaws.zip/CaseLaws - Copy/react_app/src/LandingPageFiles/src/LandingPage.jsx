import React from 'react';
import Navbar from "./components/Navbar";
import HeroSection from "./components/HeroSection";
import FeatureSection from "./components/FeatureSection";
import Workflow from "./components/Workflow";
import Footer from "./components/Footer";
import Pricing from "./components/Pricing";
import Testimonials from "./components/Testimonials";
import BackToTopButton from "./components/BackToTopButton";
import './components/styles/tailwind.css';  // Import the new CSS file

const LandingPage = () => {
  return (
    <div className='landingPage'>
      <Navbar />
      <div className="landingPage-container">
        <HeroSection />
        <FeatureSection />
        <Workflow />
        <Pricing />
        <Testimonials />
        <Footer />
        <BackToTopButton />
      </div>
    </div>
  );
};

export default LandingPage;
