import { Menu, X } from "lucide-react";
import { useState,useEffect } from "react";
import logo from "../assets/newlogo.png";
import { Link } from 'react-scroll';
import { navItems } from "../constants";
import './styles/Navbar.css'; 
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { RiAccountCircleFill } from "react-icons/ri";
import Profile from '../../../components/Profile';
import { useUser } from '../../../components/UserContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Navbar = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState('');
  const { userdata } = useUser();
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
        if (response.data.valid) {
          setUserData(response.data.userData);
        } else {
          setUserData(null);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchCurrentUser();
  }, [userdata]);


  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  const closePopup = () => {
    setShowPopup(false);
  };

  const handleLogin=()=>{
    navigate('/signin');
  }
  const handleSignup=()=>{
    navigate('/signup');
  }

  return (
    <nav className="navbar2">
      <div className="navbar-container2">
        <div className="navbar-inner">
          <div className='mylogo2'></div>
          <ul className="navbar-menu">
            {navItems.map((item, index) => (
              <li key={index}>
                <Link 
                  to={item.href} 
                  smooth={true} 
                  spy={true}
                  duration={500}
                  offset={-70} // Adjust this value if you have a fixed header
                  className="navbar-link"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="navbar-actions">
            <button className="sign-in" onClick={handleLogin}>
              Sign In
            </button>
            <button
              className="create-account" onClick={handleSignup}>
              Create account
            </button>
            <button className={`login-button ${userData ? 'logged-in' : 'logged-out'}`} onClick={togglePopup}>
              <RiAccountCircleFill className="login-icon" />
            </button>
          </div>
          {showPopup && (
            <div className="popup-overlay" onClick={closePopup}>
              <div className="popup" onClick={(e) => e.stopPropagation()}>
                <Profile />
              </div>
            </div>
          )}
          {/* <div className="navbar-toggle">
            <button onClick={toggleNavbar}>
              {mobileDrawerOpen ? <X /> : <Menu />}
            </button>
          </div> */}
        </div>
        {/* {mobileDrawerOpen && (
          <div className="mobile-drawer">
            <ul>
              {navItems.map((item, index) => (
                <li key={index} className="mobile-menu-item">
                  <Link 
                    to={item.href} 
                    smooth={true} 
                    duration={500}
                    offset={-70} // Adjust this value if you have a fixed header
                    onClick={toggleNavbar} // Close mobile drawer on link click
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mobile-actions">
              <button className="sign-in">
                Sign In
              </button>
              <button className="create-account">
                Create an account
              </button>
            </div>
          </div>
        )} */}
      </div>
    </nav>
  );
};

export default Navbar;
