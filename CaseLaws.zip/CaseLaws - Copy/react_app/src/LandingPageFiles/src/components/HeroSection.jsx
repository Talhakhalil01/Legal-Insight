import React, { useState,useEffect } from 'react';
import axios from 'axios';
import video4 from "../assets/video1.mp4";
import video3 from "../assets/video3.mp4";
import './styles/HeroSection.css';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../../../components/UserContext';
import { ToastContainer, toast } from 'react-toastify';
import { useFormContext2 } from "../../../components/ProfileDataContext";

const HeroSection = () => {
  
  const[userData,setuserData]=useState('');
  const[profileData,setprofileData]=useState('');
  const { userdata } = useUser();
  const navigate = useNavigate();
  const {dispatch2,fetchData } = useFormContext2();
  const [loading , setLoading] = useState(false);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5000');
    
        if (response.data.valid) {
            setuserData(response.data.userData);
            
        } else {
          setuserData(null);

        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        return null;
      }
    };
    fetchCurrentUser();
    
  }, []);


  
  const checkLawyerAccount = async () => {
    try {

          axios.defaults.withCredentials = true;
          const response = await axios.get('http://localhost:5000/check-lawyer-account');
          return response.data;

    } catch (error) {
      console.error('Error checking lawyer account:', error);
      throw error;
    }
  };
  
  const handleLawyersAccountClick = async () => {
    if (userData) {
      try {
        const { hasLawyerAccount, status } = await checkLawyerAccount();
        if (hasLawyerAccount) {
          if (status === 'Approved') {
            navigate('/view');
          } else if (status === 'Pending') {
            navigate('/thankyou');
          } else if (status === 'Rejected') {
            navigate('/rejected');
          }
        } else {
          navigate('/lawyerGuide');
        }
      } catch (error) {
        console.log("Error while checking account:",error)
        toast.error('Error checking account');
      }
    } else {
      navigate('/signin?redirectTo=check-profile');
    }
  };
  
  
  const handleCaseLawsClick = () => {
    navigate('/caselaw');
  };

  const handleSearchForLawyerClick = () => {
    navigate('/search');
  };

  

  return (
    <div className="hero-section">
      <h1 className="hero-title">
        Navigate the legal maze, Find 
        <br/>
        <span className="highlight"> your perfect lawyer</span>
      </h1>
      <p className="hero-description">
        Welcome to Legal Insight, your comprehensive platform for navigating the 
        legal landscape with ease. Discover case laws, connect with qualified lawyers,
        and streamline your legal journey, all in one convenient hub!
      </p>
      <div className="button-container2">
      <button className="primary-button" onClick={handleCaseLawsClick}>Case Laws</button>
      <button className="secondary-button" onClick={handleSearchForLawyerClick}>Search For Lawyer</button>
      <button className="primary-button" onClick={handleLawyersAccountClick}>Lawyers - Account</button>
    </div>
      <div className="video-container">
        <video autoPlay loop muted className="video">
          <source src={video4} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <video autoPlay loop muted className="video">
          <source src={video3} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
    </div>
  );
};

export default HeroSection;
