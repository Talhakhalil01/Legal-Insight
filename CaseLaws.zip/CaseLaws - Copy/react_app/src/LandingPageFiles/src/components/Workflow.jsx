import { CheckCircle2 } from "lucide-react";
import codeImg from "../assets/code.jpg";
import { checklistItems } from "../constants";
import './styles/Workflow.css'; // Import the new CSS file

const Workflow = () => {
  return (
    <div id="workflow" className="workflow-container">
      <h2 className="workflow-title">
        Navigate Legal Insight in four{" "}
        {/* <span className="highlight2">
        four simple
        </span> */}
        <br/>
        <span className="highlight2">
        simple steps.
        </span>
      </h2>
      <div className="workflow-content">
        <div className="workflow-image-container">
          <img src={codeImg} alt="Coding" className="workflow-image"/>
        </div>
        <div className="workflow-steps">
          {checklistItems.map((item, index) => (
            <div key={index} className="workflow-step">
              <div className="workflow-icon-container">
                <CheckCircle2 className="workflow-icon" />
              </div>
              <div>
                <h5 className="workflow-step-title">{item.title}</h5>
                <p className="workflow-step-description">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Workflow;
