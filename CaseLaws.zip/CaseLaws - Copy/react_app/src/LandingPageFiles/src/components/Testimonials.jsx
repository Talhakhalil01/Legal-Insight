import { testimonials } from "../constants";
import './styles/Testimonials.css'; // Import the new CSS file

const Testimonials = () => {
  return (
    <div id="testimonials" className="testimonials-container">
      <h2 className="testimonials-title">
        What People are saying
      </h2>
      <div className="testimonials-content">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="testimonial">
            <div className="testimonial-card">
              <p>{testimonial.text}</p>
              <div className="testimonial-user">
                <img
                  className="user-image"
                  src={testimonial.image}
                  alt=""
                />
                <div>
                  <p>{testimonial.user}</p>
                  <span className="user-company">
                    {testimonial.company}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Testimonials;
