import React from "react";
import { resourcesLinks, platformLinks, communityLinks } from "../constants";
import './styles/Footer.css';
import { FaFacebook } from "react-icons/fa";
import { IoLogoWhatsapp } from "react-icons/io";
import { BsLinkedin } from "react-icons/bs";
import { FaInstagramSquare } from "react-icons/fa";


const Footer = () => {
  return (
    <footer className="footer-container">
      <div className="footer-grid">
        <div className="link-block">
          <h3 className="footer-heading">Case Laws</h3>
          <ul className="footer-list">
            <li>
              <a href="/" className="footer-link">Home</a>
            </li>
            <li>
              <a href="/search" className="footer-link">Search Case Laws</a>
            </li>
            <li>
              <a href="/bookmark" className="footer-link">Bookmarked Case Laws</a>
            </li>
            <li>
              <a href="/profile" className="footer-link">User Profile</a>
            </li>
          </ul>
        </div>
        <div className="link-block">
          <h3 className="footer-heading">Lawyer Profiling & Hiring</h3>
          <ul className="footer-list">
            
            <li>
              <a href="/lawyerSignup" className="footer-link">Lawyer Signup</a>
            </li>
            <li>
              <a href="/view" className="footer-link">View Profile</a>
            </li>
            <li>
              <a href="/editlawyerSignup" className="footer-link">Edit Lawyer Profile</a>
            </li>
            <li>
              <a href="/search" className="footer-link">Find Lawyer</a>
            </li>
            
            
          </ul>
        </div>
       
        <div className="link-block">
          <h3 className="footer-heading">Contact Us</h3>
          <ul className="footer-list">
            <li>Email: <a href="mailto:talhakhalil974@gmail.com" className="footer-link">talhakhalil974@gmail.com</a></li>
            <li>Phone: <a href="tel:+9230355620974" className="footer-link">+92 303 55620974</a></li>
          </ul>
        </div>
        <div className="link-block">
          <h3 className="footer-heading">Social Media</h3>
          <div className="social-links2">
              <a href="https://facebook.com/legalinsight" className="social-link2"> <FaFacebook /></a>
              <a href="https://linkedin.com/in/legalinsight" className="social-link2"><BsLinkedin /></a>
              <a href="https://instagram.com/legalinsight" className="social-link2"><FaInstagramSquare /></a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>Copyright &copy; 2024 LEGAL INSIGHT. All rights reserved.</p>
        {/* <p>
          <a href="/privacy-policy" className="footer-bottom-link">Privacy Policy</a> | 
          <a href="/terms-of-service" className="footer-bottom-link">Terms of Service</a> | 
          <a href="/about" className="footer-bottom-link">About Us</a> | 
          <a href="/contact" className="footer-bottom-link">Contact</a>
        </p> */}
      </div>
    </footer>
  );
};

export default Footer;
