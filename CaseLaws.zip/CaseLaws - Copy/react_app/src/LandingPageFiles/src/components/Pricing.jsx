import { CheckCircle2 } from "lucide-react";
import { pricingOptions } from "../constants";
import './styles/Pricing.css'; // Import the new CSS file

const Pricing = () => {
  return (
    <div id="pricing" className="pricing-container">
      <h2 className="pricing-title">
        Pricing
      </h2>
      <div className="pricing-options">
        {pricingOptions.map((option, index) => (
          <div key={index} className="pricing-option">
            <div className="pricing-card">
              <p className="pricing-card-title">
                {option.title}
                {option.title === "Pro" && (
                  <span className="most-popular">
                    (Most Popular)
                  </span>
                )}
              </p>
              <p className="pricing-card-price">
                <span className="price-amount">{option.price}</span>
                <span className="price-duration">/Month</span>
              </p>
              <ul className="pricing-features">
                {option.features.map((feature, index) => (
                  <li key={index} className="pricing-feature">
                  <div className="icon-container2">
                     <CheckCircle2 className="tick-icon"/>
                  </div>
                   
                    <span className="feature-text">{feature}</span>
                  </li>
                ))}
              </ul>
              <button
                className="subscribe-button"
              >
                Subscribe
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Pricing;
