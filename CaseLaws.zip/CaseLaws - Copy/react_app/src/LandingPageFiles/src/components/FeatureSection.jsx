import { features } from "../constants";
import './styles/FeatureSection.css'; // Import the new CSS file

const FeatureSection = () => {
  return (
    <div id="features" className="feature-section">
      <div className="text-center">
        <span className="feature-badge">Feature</span>
        <h2 className="feature-title">
          Streamline your legal journey with{" "}
          <br/>
          <span className="highlight">
            Legal Insight
          </span>
        </h2>
      </div>
      <div className="features-container">
        {features.map((feature, index) => (
          <div key={index} className="feature-item">
            <div className="feature-icon-container">
              <div className="feature-icon">
                {feature.icon}
              </div>
              <div>
                <h5 className="feature-text">{feature.text}</h5>
                <p className="feature-description">
                  {feature.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FeatureSection;
