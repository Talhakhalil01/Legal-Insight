import { BotMessageSquare } from "lucide-react";
import { BatteryCharging } from "lucide-react";
import { Fingerprint } from "lucide-react";
import { ShieldHalf } from "lucide-react";
import { PlugZap } from "lucide-react";
import { GlobeLock } from "lucide-react";

import judge1 from "../assets/profile-pictures/judge1.jpg";
import judge2 from "../assets/profile-pictures/judge2.jpg";
import judge3 from "../assets/profile-pictures/judge3.jpg";
import judge4 from "../assets/profile-pictures/judge4.jpg";
import judge5 from "../assets/profile-pictures/judge5.jpg";
import judge6 from "../assets/profile-pictures/judge6.jpg";

export const navItems = [
  { label: "Features", href: "features" },
  { label: "Workflow", href: "workflow" },
  { label: "Pricing", href: "pricing" },
  { label: "Testimonials", href: "testimonials" },
];

export const testimonials = [
  {
    user: "Mr. Jsutice Javed Iqbal",
    company: "Supreme Court of Pakistan",
    image: judge1,
    text: "This platform significantly enhances the accessibility and efficiency of legal research. The user-friendly interface and comprehensive resources are invaluable to legal professionals.",
  },
  {
    user: "Mr. Justice Shahid Waheed",
    company: "Supreme Court of Pakistan",
    image: judge2,
    text: "The integration of OCR technology and the meticulous verification process ensure that the data is both accurate and reliable. This is a game-changer for legal practice in Pakistan.",
  },
  {
    user: "Mr. Justice Sajjad Ali Shah",
    company: "Supreme Court of Pakistan",
    image: judge3,
    text: "Having quick access to reported judgments and a seamless lawyer-client interaction system makes this platform an essential tool for the legal community.",
  },
  {
    user: "Mr. Justice Shahid Karim",
    company: "Lahore High Court",
    image: judge4,
    text: "The platform's innovative approach to digitizing case law documents and ensuring data integrity is commendable. It is an excellent resource for both lawyers and clients.",
  },
  {
    user: "Mr. Justice Jawad Hassan",
    company: "Lahore High Court",
    image: judge5,
    text: "This web application addresses the core challenges faced by the legal profession today. Its comprehensive features and secure communication options make it a reliable resource.",
  },
  {
    user: "Mr. Justice Shahid Karim",
    company: "Lahore High Court",
    image: judge6,
    text: "The emphasis on transparency and trust in the platform, coupled with its advanced search functionalities, provides an unparalleled experience for legal practitioners.",
  },
];


export const features = [
  {
    icon: <BotMessageSquare />,
    text: "Comprehensive Case Laws",
    description:
      "Access a vast collection of case laws and judgments, designed for easy navigation. Find relevant legal precedents efficiently with our advanced search functionality.",
  },
  {
    icon: <Fingerprint />,
    text: "Lawyer Profiles and Portfolios",
    description:
      "Lawyers can create detailed profiles showcasing their expertise and experience. Potential clients can view these profiles to make informed decisions.",
  },
  {
    icon: <ShieldHalf />,
    text: "Advanced Lawyer Search",
    description:
      "Utilize advanced search tools to find the perfect lawyer based on practice area, location, and experience. Connect with the right legal professional for your needs.",
  },
  {
    icon: <BatteryCharging />,
    text: "User-Friendly Interface",
    description:
      "Enjoy a seamless experience with our intuitive interface designed for both legal professionals and users. Find legal information and connect with lawyers easily.",
  },
  {
    icon: <PlugZap />,
    text: "Legal Insights and Resources",
    description:
      "Stay informed with curated articles and legal insights. Our regularly updated content keeps you abreast of the latest legal trends and developments.",
  },
  {
    icon: <GlobeLock />,
    text: "Client Reviews and Ratings",
    description:
      "Read genuine reviews and ratings from previous clients. Make informed decisions by seeing the experiences and feedback of others who have used the lawyers' services.",
  },
];

export const checklistItems = [
  {
    title: "Search for Case Laws",
    description:
      "Find relevant case laws and judgments using our advanced search tool.",
  },
  {
    title: "Create a Lawyer Profile",
    description:
      "Lawyers can sign up and showcase their qualifications and expertise.",
  },
  {
    title: "Connect with a Lawyer",
    description:
      "Search and contact lawyers directly through our secure platform.",
  },
  {
    title: "Access Legal Resources",
    description:
      "Explore curated articles and updates on legal trends and developments.",
  },
];

export const pricingOptions = [
  {
    title: "Free",
    price: "$0",
    features: [
      "Access basic case law search.",
      "Create a limited lawyer profile",
      "Connect with up to 3 lawyers per month",
      "Receive basic legal insights and updates",
    ],
  },
  {
    title: "Pro",
    price: "$19.90",
    features: [
      "Advanced case law search features",
      "Create and enhance lawyer profiles with more details",
      "Unlimited connections with lawyers",
      "Access premium legal resources and insights",
    ],
  },
  {
    title: "Enterprise",
    price: "$49.99",
    features: [
      "All features of the Pro plan",
      "Dedicated account manager",
      "Customized solutions and advanced analytics",
      "Priority support and enhanced security features",
    ],
  },
];

export const resourcesLinks = [
  { href: "#", text: "Getting Started" },
  { href: "#", text: "Documentation" },
  { href: "#", text: "Tutorials" },
  { href: "#", text: "API Reference" },
  { href: "#", text: "Community Forums" },
];

export const platformLinks = [
  { href: "#", text: "Features" },
  { href: "#", text: "Supported Devices" },
  { href: "#", text: "System Requirements" },
  { href: "#", text: "Downloads" },
  { href: "#", text: "Release Notes" },
];

export const communityLinks = [
  { href: "#", text: "Events" },
  { href: "#", text: "Meetups" },
  { href: "#", text: "Conferences" },
  { href: "#", text: "Hackathons" },
  { href: "#", text: "Jobs" },
];
