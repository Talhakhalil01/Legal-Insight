export const Register=()=>{
    return(
        <>Register</>
    )
}
