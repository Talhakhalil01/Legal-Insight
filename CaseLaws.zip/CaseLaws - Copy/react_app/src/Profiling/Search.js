import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { initialResults } from "./data";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { useParams } from "react-router-dom";
import ClipLoader from "react-spinners/SyncLoader";
import { useLocation } from "react-router-dom";
import { FaThumbsUp } from "react-icons/fa";
import "./Search.css";

const lawAreas = [
  "Administrative Law", "Admiralty & Aviation Law", "Agribusiness", "Alternative Dispute Resolution", "Appellate Practice", "Arbitration Law", "Asset Management Company", "Asset Search & Background Investigation", "Attestation & Legalization Services", 
  "Banking & Finance", "Blue Collar Crime", "Brokerage Company", "Business Law", "Business Tax Planning", "Capital Markets", "Child Abduction Law", "Child Adoption", "Child Custody Law", "Citizenship & Residency", 
  "Civil Law & Civil Rights", "Commercial Law", "Company Law", "Company Secretarial Services", "Competition Law", "Constitutional Law", "Construction Company", "Consumer Protection Law", "Contract Law & Enforcement", "Copyright Law", 
  "Corporate Governance", "Corporate Law", "Criminal Law", "Customs Law", "Cyber Crime Law", "Debt Collection & Recovery", "Defamation Law", "Design Registration Services", "Divorce Law", "Drafting & Vetting", 
  "Due Diligence Services", "E-Commerce Law", "E-Contract Services", "E-Governance Law", "E-Waste Law", "Employment Law", "Energy Law", "Energy Projects", "Enforcement of Foreign Judgment", "Environmental Law", 
  "Escrow Services", "Estate Planning Law", "Expert Witnesses", "Family Law", "Federal Excise Law", "Foreign Exchange Company", "Franchising Law", "Human Resource Manual", "Human Rights Law", "Immigration & Citizenship", 
  "Import & Export Registration", "Income Tax Law", "Inheritance & Succession Law", "Insolvency Law", "Insurance Company", "Insurance Law", "Intellectual Property Enforcement", "Intellectual Property Law", "International Business Transactions", 
  "International Law", "International Tax Law", "Investment Law", "IT Services Company", "Joint Ventures", "Labour Law", "Land Acquisition Law", "Leasing Law", "Legal Translation Services", "Limited Liability Partnership", 
  "Liquefied Natural Gas Company", "Litigation", "Mediation Law", "Mergers & Acquisitions", "Mirror Judgment / Order", "Modaraba Company", "Mortgage Law", "Non Banking Finance Company", "Non Governmental Organization", "Offshore Company", 
  "Oil & Gas Law", "Patent Law", "Payroll Services", "Personal Injury", "Pharmaceutical Company", "Process Service", "Provident Fund", "Provisional Refusal Services", "Real Estate Law", "Recruitment Company", 
  "Sales Tax Law", "Sales Tax Refund", "Sales Tax Returns", "Satellite Launch Contracts", "Security Services Company", "Telecommunication Company", "Textile Company", "Trademark Law", "Travel Agency", "University Setup", "White Collar Crime"
];



const cities = [
  "Abbaspur", "Ahmadpur East", "Ahmadpur Sial", "Adenzai", "Aliabad", "Allai", "Alipur", "Alpuri", "Ambar Utman Khel", "Aram Bagh", "Arifwala", "Attock", "Astore", "Awaran",
  "Babusar", "Badin", "Bagh", "Baghbana", "Bahawalnagar", "Bahawalpur City", "Bahawalpur Saddar", "Bakrani", "Baldia", "Balnigor", "Balanari", "Baltistan", "Bannu", "Bara", "Barkhan", "Barikot", "Barshore", "Barnala", "Batagram", "Bela", "Bettani", "Besima", "Besham", "Bhimber", "Bhiria", "Bhakkar", "Bhalwal", "Bhera", "Bhag", "Buni", "Bulri Shah Karim",
  "Buleda", "Burewala",
  "Chagai", "Chagharzai", "Chakesar", "Chamkani", "Chalt", "Chaman", "Chamber", "Chilas", "Chiltan", "Chitral", "Chorbut", "Chowk Sarwar Shaheed", "Chunian", "Charhoi", "Charsadda", "Chishtian",
  "Dadyal", "Daharki", "Dahli", "Danyor", "Dara Adam Khel", "Daraban", "Darazinda", "Darya Khan", "Dasht", "Dasht Mastung", "Dassu", "Datta Khel", "Daur Maira", "Dera Adam Khel", "Dera Bugti", "Dera Ghazi Khan", "Dera Ismail Khan", "Dera Murad Jamali", "Depalpur", "Dhadar", "Dhirkot", "Dina", "Diplo", "Dokri", "Dossali", "Drosh", "Duki", "Dossali", "Drosh", "Duki", "Dobandi",
  "Faiz Ganj", "Fateh Jang", "Fatehpur Thakiala", "Fatehpur Thakiala", "Faisalabad City", "Faisalabad Sadar", "Fort Abbas",
  "Gagra", "Gandakha", "Gandoi", "Garhi Khairo", "Garhi Yasin", "Garekhat", "Ghazni Khel", "Gharyum", "Ghulam Khan", "Gichk", "Gilgit", "Gishkaur", "Gojal", "Gojra", "Gulistan", "Gulistan-e-Jouhar", "Gulshan-E-Iqbal", "Gulzar-E-Hijri", "Gumbat", "Gulabpur", "Gultari", "Gupis", "Gurez", "Gurjar", "Gwadar",
  "Hafizabad", "Haji Kot", "Haldi", "Hangu", "Haripur", "Harnai", "Hattian Bala", "Hazro", "Hassan Abdal", "Havelian", "Hajira", "Haveli", "Hunza", "Hub",
  "Ibrahim Hyderi", "Islamkot", "Ismail Zai", "Ittehad",
  "Jalalpur Jattan", "Jalalpur Pirwala", "Jampur", "Jandola", "Jaranwala", "Jatoi", "Jhandan", "Jhang", "Jhal Jhao", "Jhal Magsi", "Jiwani", "Johan", "Jinnah", "Jinnah", "Joharabad", "Judba", "Juglot",
  "Kabal", "Kahan", "Kakki", "Kalat", "Kalkot", "Kalakhel", "Kallar Kahar", "Kallar Syedan", "Kandia", "Kandhkot", "Kanmetharzai", "Kanraj", "Karak", "Karor Lal Esan", "Karkh", "Karachi", "Karkh", "Kattan", "Kerpalu", "Khal", "Khander", "Khar Bajaur", "Kharan", "Khaplu", "Kharmang", "Khattak", "Khataf", "Kheta", "Khipro", "Khipro", "Khushab", "Killa Saifullah", "Kingri", "Kingri", "Khoast", "Khoro Chan", "Khurshidabad", "Khuzdar", "Kohistan", "Kolai-Palas", "Kot Addu", "Kot Chutta", "Kot Diji", "Kot Ghulam Muhammad", "Kot Momin", "Kot Radha Kishan", "Kotli", "Kubo Saeed Khan", "Kunjah", "Kurram", "Kutmandai", "Keti Bunder",
  "Lakki Marwat", "Lal Qilla", "Landi Kotal", "Lachi", "Lahore Cantonment", "Lahore City", "Lahor", "Lalian", "Layyah", "Loiband", "Lodhran", "Loralai", "Lower Chitral", "Lower Dir", "Lower Kohistan", "Lower Kurram", "Lower Orakzai", "Lower South Waziristan", "Lyari", "Lund Khwar",
  "Mach", "Maiwand", "Makin", "Malakand", "Malkhana", "Mamund", "Mand", "Mang", "Manghopir", "Mansehra", "Mankera", "Manshera", "Mastuj", "Mashkay", "Mashkel", "Mathra", "Mehar", "Mehrabpur", "Mekhtar", "Meryan", "Mian Channu", "Minchinabad", "Mirpur", "Mir Ali", "Mirpur Bathoro", "Mirpur Khas", "Mirpur Mathelo", "Mirpur Sakro", "Mirpur Shah", "Miran Shah", "Mirwan", "Moga", "Mohmand", "Moola", "Mumtazabad", "Multan Khurd", "Muslim Bagh", "Muzaffarabad", "Muzafrabad", "Muzafarabad", "Muzafargarh",
  "Nag", "Nagar", "Naltar", "Nankana Sahib", "Nasarpur", "Nasirabad", "Nathiagali", "Nok Kundi", "North Karachi", "Nowshera", "Nowshera Virkan", "Nushki",
  "Okara", "Orakzai", "Ormara", "Ornach",
  "Paharpur", "Panjgur", "Panjpai", "Pasni", "Paroa", "Paroom", "Pattoki", "Pasrur", "Peshawar", "Peshtakhara", "Phelawagh", "Pindiali", "Pindiali", "Piplan", "Pir Mahal", "Punial", "Puran",
  "Qambar", "Qasimabad", "Quaidabad",
  "Raiwind", "Rajanpur", "Razmak", "Razar", "Rawalakot", "Rawalpindi", "Renala Khurd", "Rohri", "Rustam",
  "Sadar", "Sadar", "Sadar", "Samahni", "Samaro", "Sambrial", "Samundri", "Sangla Hill", "Sangan", "Sar-Kharan", "Sardar Kot", "Saroona", "Sarawakai", "Sarawakai", "Sarogha", "Sehnsa", "Sehwan", "Seo", "Serwekai", "Sibi", "Shabqadar", "Shah Bandar", "Shah Faisal", "Shah Murad", "Shah Faisal", "Shah Faisal Rahu", "Shah Faisal", "Shahdadpur", "Shahpur", "Sharda", "Shakargarh", "Shaktoi", "Shankiari", "Sharhar Murad", "Sherani", "Shewa", "Shinki", "Shinkiari", "Sinjhoro", "Sohbatpur", "Sohawa", "Solband", "Sobho Dero", "Sobho Dero", "Spinwam", "Suntsar", "Sui", "Surab", "Swabi",
  "Takht Bhai", "Takht-e-Nasrati", "Tangir", "Tando Adam Khan", "Tando Bago", "Tando Ghulam Hyder", "Tando Mohammad Khan", "Tangwani", "Tangi", "Tank", "Taxila", "Taftan", "Thal", "Tharparkar", "Thari Mirwah", "Thul", "Timergara", "Toi Khulla", "Topi", "Torghar", "Tohmulk", "Toisar", "Tump", "Turbat",
  "Upper Chitral", "Upper Dir", "Upper Kohistan", "Upper Kurram", "Upper Orakzai", "Upper South Waziristan", "Usta Mohammad", "Uthal", "Utmankhel",
  "Vehari", "Wadh", "Wana", "Wari", "Washuk", "Wazir", "Wazirabad",
  "Yasin", "Yake Ghund", "Yazman",
  "Zafarwal", "Zamuran", "Zarghoon", "Zehri", "Ziarat",
];


const Search = () => {

  const [searchResults, setSearchResults] = useState([]);
  const [selectedLawArea, setSelectedLawArea] = useState("");
  const [location, setLocation] = useState("");
  const [lawyerName, setLawyerName] = useState("");
  const [error, setError] = useState("");

  const [loading, setLoading] = useState(false);
  const baseURL = `http://localhost:5000/images/`;



  // setImageURL(`${baseURL}${images.lawyerImage}`);

 

  const handleSearch = async () => {
    setLoading(true);
    if(selectedLawArea || location || lawyerName)
    {
      try {
      const response = await axios.get('http://localhost:5000/search-lawyer', {
        params: {
          lawArea: selectedLawArea,
          location: location,
          lawyerName: lawyerName
        }
      });
      
     
          const uniqueResults = [];
          const seen = new Set();
          response.data.forEach(result => {
            if (!seen.has(result.ID)) {
              seen.add(result.ID);
              uniqueResults.push({
                ...result,
                lawyerImage: result.lawyerImage ? `${baseURL}${result.lawyerImage}` : null
              });
            }
          });
          
          
          console.log("Query Results",uniqueResults)
          setSearchResults(uniqueResults);
          setLoading(false);
       

    } catch (error) {
      
      if (error.status === 404) {
        toast.error("No records found with given query!!!")
     }
     else{
      setLoading(false);
      setSearchResults([]);
      console.error('Error fetching search results:', error);
      toast.error("No records found with given query!!!")
     }
    }
  }
  else{
    toast.error("Atleast one field required!!!")

  }
  };

  const formatPracticeAreas = (areas) => {
    if (Array.isArray(areas)) {
      return areas.join(', ');
    } else {
      return areas;
    }
  };



  const calculateNetRating = (reviews) => {
    if (reviews && reviews.length > 0) {
      const totalRating = reviews.reduce((acc, review) => acc + review.rating, 0);
      const averageRating = totalRating / reviews.length;
        return averageRating.toFixed(1);
    } else {
          return 0;
    }
  };

  const calculateExperience = (dateString) => {
    const currentYear = new Date().getFullYear();
    const inputYear = parseInt(dateString, 10);
    return currentYear - inputYear;
  };



  const generateStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      if (i <= rating) {
        stars.push(<span key={i} className="star">&#9733;</span>); // filled star
      } else {
        stars.push(<span key={i} className="star-empty">&#9734;</span>); // empty star
      }
    }
    return stars;
};
  return (
    <div className="search-container">
      <div className="search-content">
        <h1 className="search-title">Lawyer Search</h1>
        <div className="search-form">
          <div className="search-fields">
            <div className="search-field">
              <label htmlFor="lawArea" className="search-label">
                Law Area
              </label>
              <select
                id="lawArea"
                className="search-select"
                value={selectedLawArea}
                onChange={(e) => setSelectedLawArea(e.target.value)}
              >
                <option value="">
                  Select Law Area
                </option>
                {lawAreas.map((area, index) => (
                  <option key={index} value={area}>
                    {area}
                  </option>
                ))}
              </select>
            </div>
            <div className="search-field">
              <label htmlFor="location" className="search-label">
                City/Location
              </label>
              <select
                id="location"
                type="text"
                className="search-select"
                placeholder="Enter City or Location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              >
                <option value="">
                  Select Location
                </option>
                {cities.map((area, index) => (
                  <option key={index} value={area}>
                    {area}
                  </option>
                ))}
                </select>
            </div>
            <div className="search-field">
              <label htmlFor="lawyerName" className="search-label">
                Lawyer Name
              </label>
              <input
                id="lawyerName"
                type="text"
                className="search-input"
                placeholder="Enter Lawyer's Name"
                value={lawyerName}
                onChange={(e) => setLawyerName(e.target.value)}
              />
            </div>
            
            <div className="search-button-container">
              <button onClick={handleSearch} className="search-button">
                Search
              </button>
            </div>
            </div>
          </div>
        

        <div className="search-results">

          {searchResults.length>0 && <p className="heading">Search Results({searchResults.length}):</p> }
          {searchResults.map((result) => (
            
            <a
              href={`/profile?id=${result.ID}`}
              key={result.ID}
              className="search-result"
            >
              <div className="profile-header">
                {result.lawyerImage && <img src={result.lawyerImage} alt={result.name} className="profile-picture" />}
                <div className="profile-details">
                  <h1>{result.name}</h1>
                  <p className="profile-text">{result.currentPosition}</p>
                  <p className="profile-text">{result.barAffiliation}</p>
                  <p className="profile-text">Practiced in {result.area}</p>
                  <p className="profile-text">{result.city}</p>

                  <div className="bottom-column">
                    <div className="experience">
                      <p>Experience</p> 
                      <span>{calculateExperience(result.durationOfPractice)} Yrs</span>
                    </div>  
                    <div className="reviews">
                        <p>Reviews</p>
                        <span><FaThumbsUp /> {result.totalReviews}</span>
                      </div>
                      <div className="rating">
                        <p>Rating</p>
                        <span className="rating">{parseFloat(result.netRating).toFixed(1)}</span>
                      </div>
                  </div>
                </div>
                <div className="button-container">
                  <button className="view-button">View</button>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Search;
