import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
// import ClipLoader from "react-spinners/MoonLoader";
import { ToastContainer, toast } from 'react-toastify';
import { useParams } from "react-router-dom";
import { FaFacebook } from "react-icons/fa";
import { IoLogoWhatsapp } from "react-icons/io";
import { BsLinkedin } from "react-icons/bs";
import ClipLoader from "react-spinners/SyncLoader";
import { useLocation } from "react-router-dom";
import StarRating from "./StarRating";
import "./Profile.css";
import { BiSolidError } from "react-icons/bi";





const Profile = () => {


  const navigate=useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const id = queryParams.get("id");


  const [reviewRating, setReviewRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const [reviewCategory, setReviewCategory] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [imageURL, setImageURL] = useState(null);
  const [dataFetched, setDataFetched] = useState(false);


  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "+92",
    gender: "",
    province: "",
    city: "",
    areas: [],
    barAffiliation: "",
    barAssociation: "",
    

    education: "",
    graduationYear: "",
    LLB: "",
    LLM: "",
    LLD: "",
    
    
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts: "",
    highCourt: "",
    

    licenseNumber: "",
    certifications: "",
    caseExperience: "",
    notableCases: "",
    successStories: "",
    officeAddress: "",
    officeHours: {
      Monday: { startTime: "09:00", endTime: "17:00" },
      Tuesday: { startTime: "09:00", endTime: "17:00" },
      Wednesday: { startTime: "09:00", endTime: "17:00" },
      Thursday: { startTime: "09:00", endTime: "17:00" },
      Friday: { startTime: "09:00", endTime: "17:00" },
      Saturday: { startTime: "00:00", endTime: "00:00" },
      Sunday: { startTime: "00:00", endTime: "00:00" }
    },
    consultationModes: [],
    consultationFees: {},
    lawyerImage: null,
    facebook: "",
    whatsapp: "+92",
    linkedin: "",
  
  
  date: "",
  reviews:[]

  });

    const fetchProfileData = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`http://localhost:5000/fetch-profile-id?id=${id}`);
        const { profileData, practiceAreas, consultationModes, officeHours, reviews, images } = response.data;

        const officeHoursObject = officeHours.reduce((acc, { dayOfWeek, startTime, endTime }) => {
          acc[dayOfWeek] = { startTime, endTime };
          return acc;
        }, {});

        const modesOptions = consultationModes.map(modeobj => ({
          value: modeobj.mode,
          label: modeobj.mode,
        }));

        const consultationFees = consultationModes.reduce((acc, { mode, fee }) => {
          acc[mode] = fee;
          return acc;
        }, {});

        const baseURL = `http://localhost:5000`;

        if (images.lawyerImage) setImageURL(`${baseURL}${images.lawyerImage}`);

        setFormData(prevFormData => ({
          ...prevFormData,
          name: profileData.name || prevFormData.name,
          email: profileData.email || prevFormData.email,
          phone: profileData.phone || prevFormData.phone,
          gender: profileData.gender || prevFormData.gender,
          province: profileData.province || prevFormData.province,
          city: profileData.city || prevFormData.city,
          areas: practiceAreas || prevFormData.areas,
          barAffiliation: profileData.barAffiliation || prevFormData.barAffiliation,
          barAssociation: profileData.barAssociation || prevFormData.barAssociation,
          education: profileData.education || prevFormData.education,
          graduationYear: profileData.graduationYear || prevFormData.graduationYear,
          LLB: profileData.LLB || prevFormData.LLB,
          LLM: profileData.LLM || prevFormData.LLM,
          LLD: profileData.LLD || prevFormData.LLD,
          currentPosition: profileData.currentPosition || prevFormData.currentPosition,
          durationOfPractice: profileData.durationOfPractice || prevFormData.durationOfPractice,
          lowerCourts: profileData.lowerCourts || prevFormData.lowerCourts,
          highCourt: profileData.highCourt || prevFormData.highCourt,
          licenseNumber: profileData.licenseNumber || prevFormData.licenseNumber,
          certifications: profileData.certifications || prevFormData.certifications,
          caseExperience: profileData.caseExperience || prevFormData.caseExperience,
          notableCases: profileData.notableCases || prevFormData.notableCases,
          successStories: profileData.successStories || prevFormData.successStories,
          officeAddress: profileData.officeAddress || prevFormData.officeAddress,
          officeHours: { ...prevFormData.officeHours, ...officeHoursObject },
          consultationModes: modesOptions || prevFormData.consultationModes,
          consultationFees: { ...prevFormData.consultationFees, ...consultationFees },
          lawyerImage: images.lawyerImage ? images.lawyerImage : prevFormData.lawyerImage,
          facebook: profileData.facebook || prevFormData.facebook,
          whatsapp: profileData.whatsapp || prevFormData.whatsapp,
          linkedin: profileData.linkedin || prevFormData.linkedin,
          date: profileData.signupDate || prevFormData.date,
          reviews: reviews || prevFormData.reviews,
        }));

        console.log("Fetched Data:", response.data);
        setLoading(false);
      } catch (error) {
        setLoading(false);
        console.error("Error:", error);
        toast.error('Error while fetching profile data:', error);
      }


  };


  useEffect(() => {
    fetchProfileData();
  }, [id]);

  const handleAddReview = async (event) => {
    event.preventDefault();

    try {
      
      axios.defaults.withCredentials = true;
      const response = await axios.post('http://localhost:5000/submit-review', {
        id,
        rating: reviewRating,
        category: reviewCategory,
        reviewText,
      });
      
      if (response.status === 200) {
        console.log('Review submitted successfully');
        reset();
        fetchProfileData();


      }
    } catch (error) {
         
      console.error('Error submitting review:', error);

      if (error.response) {
        if (error.response.status === 401) {
             navigate(`/signin?redirectTo=profile?id=${id}`);
        } else if (error.response.status === 409) {
          setError('Your review is already submitted!!!');
          reset();
          setTimeout(() => {
            setError("");
        }, 5000); 
          
        } else {
          toast.error('Error submitting review:', error.response.data.error);
        }
      } else {
        toast.error('Error submitting review:', error.message);
      }
    }
   
  };
  const reset = () =>{
    setReviewRating(0);
    setReviewText("");
    setReviewCategory("");

  }
  const formatOfficeHours = (officeHours) => {
    return (
      <div className="office-hours">
        {Object.entries(officeHours).map(([day, { startTime, endTime }]) => (
          <div key={day} className="office-hours-day">
            <span className="day">{day}:</span>
            <div className="time">
              <span className="start-time">{startTime}</span>
              <span className="dash">-</span>
              <span className="end-time">{endTime}</span>
          </div>
          </div>
        ))}
      </div>
    );
  };

  const formatConsultationFees = (consultationFees) => {
    return (
      <div className="consultation-fees">
        {Object.entries(consultationFees).map(([mode, fee]) => (
          <div key={mode} className="consultation-fees-mode">
            <div className="mode-fee">
                  <span className="mode">{mode}:</span>
                  <span className="fee">{fee}rs</span>
            </div>
          </div>
        ))}
      </div>
    );
  };
  const formatPracticeAreas = () => {
    const areas=formData.areas;
    if (Array.isArray(areas)) {
      const areaNames = areas.map(areaObj => areaObj.area);
      return areaNames.join(", ");
    } else if (typeof areas === 'object' && areas !== null && 'area' in areas) {
      return areas.area;
    } else {
      return "";
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };
  
  const calculateNetRating = (reviews) => {
    if (reviews && reviews.length > 0) {
      const totalRating = reviews.reduce((acc, review) => acc + review.rating, 0);
      const averageRating = totalRating / reviews.length;
        return averageRating.toFixed(1);
    } else {
          return 0;
    }
  };
  const generateStars = (rating) => {
      const stars = [];
      for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
          stars.push(<span key={i} className="star">&#9733;</span>); // filled star
        } else {
          stars.push(<span key={i} className="star-empty">&#9734;</span>); // empty star
        }
      }
      return stars;
  };
  

  return (
    <div className="profile-container2">

{loading ? (
        <div className="loading-spinner">
              <div className="loader">
               <ClipLoader
                  loading={loading}
                  color="#083e78"
                  margin={5}
                />
                </div>
                {/* <span>Please Wait</span> */}
            </div> ) 
        :
        (
      <div>
      <h1 className="search-title2">Profile Result</h1>
      <div className="profile-wrapper">
        <div className="profile-header">
         {imageURL && <img src={imageURL} alt={formData.name} className="profile-picture" />}
          <div className="profile-details">

            <h1>{formData.name}</h1>
            <p className="profile-text">{formData.currentPosition}</p>
            <p className="profile-text">{formData.barAffiliation}</p>
            <p className="profile-text">{formatPracticeAreas()}</p>
            <p className="profile-text">{formData.city}</p>
            <span>Rating: {calculateNetRating(formData.reviews)}</span>
                   
          </div>
          
         
          
        </div>
        <div className="profile-info">
       
          
                <div className="data-block">
                <h2 className="section-title">Basic Information</h2>
                <p className="profile-text">Practice Areas:{formatPracticeAreas()}</p>
                <p className="profile-text">Bar Affiliation: {formData.barAffiliation}</p>
                <p className="profile-text">Bar Association: {formData.barAssociation}</p>
                    
          </div>
             
                <div className="data-block">
                <h2 className="section-title">Personal Details</h2>
                <p className="profile-text">Name: {formData.name}</p>
                <p className="profile-text">Email: {formData.email}</p>
                <p className="profile-text">Phone no.: {formData.phone}</p>
                <p className="profile-text">Province: {formData.province}</p>
                <p className="profile-text">City: {formData.city}</p>
                </div>
               
                <div className="data-block">
                    <h2 className="section-title">Education</h2>
                    <p className="profile-text">Education: {formData.education}</p>
                    <p className="profile-text">LLB From: {formData.LLB}</p>
                    <p className="profile-text">LLM From: {formData.LLM}</p>
                    <p className="profile-text">LLD From: {formData.LLD}</p>
                </div>

         
            <div className="data-block">
              <h2 className="section-title">Professional Details</h2>
              <p className="profile-text">Current Position: {formData.currentPosition}</p>
              <p className="profile-text">Duration of Practice: {formData.durationOfPractice}</p>
              <p className="profile-text">Lower Courts: {formData.lowerCourts}</p>
              <p className="profile-text">High Court: {formData.highCourt}</p>
             </div>
           
            <div className="data-block">
              <h2 className="section-title">License and Certifications</h2>
              <p className="profile-text">Certifications: {formData.certifications}</p>
              <p className="profile-text">Case Experience: {formData.caseExperience}</p>
              <p className="profile-text">Notable Cases: {formData.notableCases}</p>
              <p className="profile-text">Success Stories: {formData.successStories}</p>
            
            </div>
         
            <div className="data-block">
            <h2 className="section-title">Social Media and Contact</h2>
              <p className="profile-text">Contact Number: {formData.phone}</p>
              <div className="social-links">
                {formData.facebook && (
                  <a href={formData.facebook} className="social-link">
                    <FaFacebook />
                  </a>
                )}
                {formData.whatsapp && (
                  <a href={`https://wa.me/${formData.whatsapp}`} className="social-link">
                    <IoLogoWhatsapp />
                  </a>
                )}
                {formData.linkedin && (
                  <a href={formData.linkedin} className="social-link">
                    <BsLinkedin />
                  </a>
                )}
                </div>
            </div>
            
        
        
         <div className="data-block">
            <h2 className="section-title">Office Details</h2>
            <p className="profile-text">Office Address: {formData.officeAddress}</p>
            <div className="profile-text">Office Hours:</div>
            {formatOfficeHours(formData.officeHours)}
            <p className="profile-text">Consultation Modes: {formData.consultationModes.map(mode => mode.label).join(", ")}</p>
            <div className="profile-text">
                Consultation Fees:  {formatConsultationFees(formData.consultationFees)}
                        
            </div>
          </div>
          <div>
            <h2 className="section-title2">Reviews and Ratings({formData.reviews.length})</h2>
            <div className="reviews">
              {formData.reviews && formData.reviews.map((review, index) => (
                  <div key={index} className="review">
                    <p className="review-title">{review.category}</p>
                    <p className="review-user">{review.Username}</p>
                    <div className="review-rating">
                      Rating: {generateStars(review.rating)}
                    </div>
                    <p className="review-text"> Review: {review.reviewText}</p>
                    <p className="review-text">Review Date: {formatDate(review.reviewDate)}</p>
                  </div>
                ))}
            </div>
            
          </div>
        </div>
        
      <div className="give-rating">
           <h2 className="section-title2">Add a Review</h2>
           <form>

           <div class="custom-flex-container">
            <label class="custom-label" for="category">
              Review Category:
            </label>
            <select
              id="category"
              value={reviewCategory}
              onChange={(e) => setReviewCategory(e.target.value)}
              class="custom-select"
              required
            >
              <option value="">Select Category</option>
              <option value="Consultation">Consultation</option>
              <option value="Case Handling">Case Handling</option>
              <option value="Communication">Communication</option>
              <option value="Professionalism">Professionalism</option>
              <option value="Results Achieved">Results Achieved</option>
            </select>
            </div>
                <div className="profile-star-rating">
                  <StarRating
                    rating={reviewRating}
                    onRatingChange={setReviewRating}
                    required
                  />
                </div>
                <textarea
                  className="profile-textarea"
                  rows="4"
                  value={reviewText}
                  onChange={(e) => setReviewText(e.target.value)}
                  placeholder="Write your review here"
                  required
                ></textarea>
                {error && 
                  <div className="profile-error"> 
                      <BiSolidError className="error-icon" />
                      {error}
                  </div>}
                <button
                  className="profile-button"
                  onClick={handleAddReview}
                >
                  Submit Review
                </button>
            </form>

      </div>
    </div>
    </div>)}

  </div>
  );
};

export default Profile;
