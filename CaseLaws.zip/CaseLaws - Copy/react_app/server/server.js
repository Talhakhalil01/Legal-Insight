const express = require('express');
const app = express();
const port = 3000; // You can change this as needed

app.get('/', (req, res) => {
  res.send('Welcome to your backend server!');
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
