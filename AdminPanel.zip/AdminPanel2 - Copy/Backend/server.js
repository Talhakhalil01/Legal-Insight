const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const sql = require('mssql/msnodesqlv8');
const cors = require('cors');
const cookieParser = require('cookie-parser');



const port = 5002;

const app = express();
app.use(cors(
  {
    origin:["http://localhost:3001"],
    methods:["POST","GET","DELETE"],
    credentials:true
  }
));
app.use(express.json({ limit: '50mb' })); // Adjust the limit as needed
app.use(cookieParser());
app.use(bodyParser.json({ limit: '50mb' })); // Adjust the limit as needed
app.use(
  session({
    secret: 'secret', // Change this to a secure random key
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: false,
      maxAge:1000 * 60 * 60 * 24 * 30
       }
  })
);

// Database Configuration
const dbConfig = {
  user: 'your_username', 
  password: 'your_password', 
  server: 'DESKTOP-65ER0LH\\SQLEXPRESS01',
  database: 'CaseLaws',
  driver: 'msnodesqlv8',
  options: {
    trustedConnection: true,
    enableArithAbort: true,
  },
  pool: {
    max: 10, 
    min: 0,  
    idleTimeoutMillis: 30000, 
    acquireTimeoutMillis: 60000, 
    },
};

app.get('/', async (req, res) => {
  
  if (req.session.userData) {
    return res.json({ valid: true, userData: req.session.userData });
  } 
  else {
   
    return res.json({ valid: false });
  }
});

// Add this route to handle logout
app.post('/logout', (req, res) => {
// Destroy the session
req.session.destroy((err) => {
  if (err) {
    console.error('Error destroying session:', err);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  } else {
    // Respond with success
    res.clearCookie('connect.sid'); // Clear the session cookie
    res.status(200).json({ success: true, message: 'Logout successful' });
  }
});
});

app.get('/api', (req, res) => {
res.send('Hello from the server!My name is talha khalil');
});



// Route to handle login POST requests from signup.js
app.post('/login', async (req, res) => {
  try {
    // Assuming your login form sends an object with email and password
    const { username, password } = req.body;

    // Check if the provided credentials match the predefined values
    if (username == "talhakhalil974@gmail.com" && password == "12345") {
      // Set user session
      req.session.userData = {
        username: "talhakhalil974@gmail.com", // Set the username as needed
      };
      console.log("User logged in:", req.session.userData);
      res.status(200).json({ success: true });
    } else {
      console.log('Invalid credentials');
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Error handling login:', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});

// Route to handle adding judgments
app.post('/add', async (req, res) => {
  try {
    const {
      caseno,
      casesubject,
      casetitle,
      courtname,
      judgename,
      judgementdate,
      casecitation,
      othercitation,
      tagline,
      judgement,
    } = req.body;

    // Insert the judgment data into the database using parameterized query
    const query = `
      INSERT INTO CaseLaws4 (
        CaseNo,
        CaseSubject,
        CaseTitle,
        Court,
        AuthorJudge,
        JudgementDate,
        Citation,
        SCCitation,
        Tagline,
        Judgement
      ) VALUES (
        @caseno,
        @casesubject,
        @casetitle,
        @courtname,
        @judgename,
        @judgementdate,
        @casecitation,
        @othercitation,
        @tagline,
        @judgement
      )
    `;

    const pool = await sql.connect(dbConfig);
    const request = pool.request();

    // Bind parameters to the query
    request.input('caseno', sql.NVarChar(225), caseno);
    request.input('casesubject', sql.NVarChar(100), casesubject);
    request.input('casetitle', sql.NVarChar(400), casetitle);
    request.input('courtname', sql.NVarChar(80), courtname);
    request.input('judgename', sql.NVarChar(225), judgename);
    request.input('judgementdate', sql.NVarChar(225), judgementdate);
    request.input('casecitation', sql.NVarChar(225), casecitation);
    request.input('othercitation', sql.NVarChar(225), othercitation);
    request.input('tagline', sql.NVarChar(sql.MAX), tagline);
    request.input('judgement', sql.NVarChar(sql.MAX), judgement);

    const result = await request.query(query);

    res.status(200).json({ success: true, message: 'Judgment added successfully' });
  } catch (error) {
    console.error('Error adding judgment:', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});


// Updated endpoint for handling judgment edit
app.post('/edit', async (req, res) => {
  const {
    caseno0,
    caseno,
    casesubject,
    casetitle,
    judgename,
    judgementdate,
    courtname,
    casecitation,
    othercitation,
    tagline,
    judgement
  } = req.body;

  try {
    // Construct the SET part of the SQL query based on non-empty fields
    const setStatements = [
      caseno && 'CaseNo = @caseno',
      casesubject && 'CaseSubject = @casesubject',
      casetitle && 'CaseTitle = @casetitle',
      judgename && 'AuthorJudge = @judgename',
      judgementdate && 'JudgementDate = @judgementdate',
      courtname && 'Court = @courtname',
      casecitation && 'SCCitation = @casecitation',
      othercitation && 'Citation = @othercitation',
      tagline && 'Tagline = @tagline',
      judgement && 'Judgement = @judgement',
    ].filter(Boolean).join(', ');

    if (setStatements) {
      // Update the corresponding judgment in the database if any field is non-empty
      const pool = await sql.connect(dbConfig);
      const result = await pool
        .request()
        .input('caseno0', sql.NVarChar(225), caseno0)  // Add input for existing case number
        .input('caseno', sql.NVarChar(100), caseno)
        .input('casesubject', sql.NVarChar(400), casesubject)
        .input('casetitle', sql.NVarChar(80), casetitle)
        .input('judgename', sql.NVarChar(225), judgename)
        .input('judgementdate', sql.NVarChar(225), judgementdate)
        .input('courtname', sql.NVarChar(225), courtname)
        .input('casecitation', sql.NVarChar(225), casecitation)
        .input('othercitation', sql.NVarChar(225), othercitation)
        .input('tagline', sql.NVarChar(sql.MAX), tagline)
        .input('judgement', sql.NVarChar(sql.MAX), judgement)
        .query(`
          UPDATE CaseLaws4
          SET ${setStatements}
          WHERE CaseNo = @caseno0  -- Use the existing case number in the WHERE clause
        `);

      sql.close();

      if (result.rowsAffected[0] === 0) {
        // No rows were updated, meaning the row with caseno0 does not exist
        res.status(404).json({ success: false, message: 'Judgment with the provided CaseNo does not exist' });
      } else {
        // Row was successfully updated
        res.status(200).json({ success: true });
      }
    } else {
      // No non-empty fields to update
      res.status(400).json({ success: false, message: 'No fields provided for update' });
      console.log('No fields provided for update');
    }
  } catch (error) {
    console.error('Error editing judgment:', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});


app.delete('/delete', async (req, res) => {
  
  const caseno = req.body.caseno;
  console.log('Deleting case:', caseno);

  try {
    const pool = await sql.connect(dbConfig);
    const result = await pool
      .request()
      .input('caseno', sql.NVarChar(225), caseno)
      .query('DELETE FROM CaseLaws4 WHERE CaseNo = @caseno');

    sql.close();

    if (result.rowsAffected[0] > 0) {
      res.status(200).json({ success: true });
    } else {
      res.status(404).json({ success: false, message: 'Judgement not found' });
    }
  } catch (error) {
    console.error('Error deleting judgement:', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});



// API endpoint to get signup request counts
app.get('/signup-requests', async (req, res) => {
  let pool;
  try {
    
    pool = await sql.connect(dbConfig);

    const result = await pool.request().query(`
      SELECT 
        COUNT(CASE WHEN Status = 'pending' THEN 1 END) as pendingCount,
        COUNT(CASE WHEN Status = 'Approved' THEN 1 END) as approvedCount
      FROM LawyerSignupData
    `);



    res.status(200).json({
      pendingCount: result.recordset[0].pendingCount,
      approvedCount: result.recordset[0].approvedCount,
    });
  } catch (error) {
    console.error('Error fetching signup requests:', error);
    res.status(500).send('Server Error');
  }
  finally {
    if (pool) {
      console.log('Closing the connection pool');
      // pool.close();
    }
  }
});


// app.get('/all', async (req, res) => {
//   try {
//     const pool = await sql.connect(dbConfig);
    
//     // Use ORDER BY to sort the results by the ID column in descending order
//     const result = await pool.request().query('SELECT * FROM CaseLaws3 ORDER BY ID DESC');

//     sql.close();

//     res.status(200).json(result.recordset);
//   } catch (error) {
//     console.error('Error fetching CaseLaws:', error.message);
//     res.status(500).json({ success: false, message: 'Internal Server Error' });
//   }
// });


let cachedData = null;
let cachedRowCount = 0;



app.get('/all', async (req, res) => {
  let pool;
  try {
    pool = await sql.connect(dbConfig);

    // Fetch the current row count
    const rowCountResult = await pool.request()
      .query("SELECT COUNT(*) AS 'rowCount' FROM CaseLaws4");
    const currentRowCount = rowCountResult.recordset[0].rowCount;

    if (currentRowCount !== cachedRowCount) {
      console.time("Time to fetch rows")
      // If row count has changed, fetch new data
      const result = await pool.request()
        .query('SELECT ID, CaseNo, CaseSubject, CaseTitle, Court, AuthorJudge, JudgementDate, Citation, SCCitation, Tagline, Judgement FROM CaseLaws4 ORDER BY ID DESC');

      cachedData = result.recordset;
      cachedRowCount = currentRowCount;
      console.timeEnd("Time to fetch rows")
    }

    res.status(200).json(cachedData);
  } catch (error) {
    console.error('Error fetching CaseLaws:', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  } finally {
    if (pool) {
      console.log('Closing the connection pool');
      // pool.close(); // Ensure the connection is closed in the finally block
    }
  }
});


app.get('/all2', async (req, res) => {
  try {
    const pool = await sql.connect(dbConfig);

    console.time("Time to fetch rows2")
      // If row count has changed, fetch new data
      const result = await pool.request()
        .query('SELECT  ID, CaseNo, CaseSubject, CaseTitle, Court, AuthorJudge, JudgementDate, Citation, SCCitation, Tagline, Judgement FROM CaseLaws4 ORDER BY ID DESC');

      cachedData = result.recordset;

      

    sql.close();
    
    console.timeEnd("Time to fetch rows2")
    res.status(200).json(cachedData);
  } catch (error) {
    console.error('Error fetching CaseLaws(2):', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});


app.get('/fetch-requests', async (req, res) => {
  try {
    const pool = await sql.connect(dbConfig);

    const result = await pool.request()
    .query("SELECT ID, name, signupDate FROM LawyerSignupData WHERE Status = 'pending' ORDER BY ID ASC");


    const lawyerSignupData = result.recordset;

    sql.close();

    res.status(200).json(lawyerSignupData);
  } catch (error) {
    console.error('Error fetching LawyerSignupData:', error.message);
    res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
});


app.get('/fetch-profile-id', async (req, res) => {
  try {
    const lawyerId = req.query.id;
    if (!lawyerId) {
      return res.status(400).json({ error: 'Lawyer ID is required' });
    }

    const pool = await sql.connect(dbConfig);

    const query = `
      SELECT * FROM LawyerSignupData WHERE ID = @LawyerId;
      SELECT area FROM PracticeAreas WHERE lawyerId = @LawyerId;
      SELECT mode, fee FROM ConsultationModes WHERE lawyerId = @LawyerId;
      SELECT dayOfWeek, startTime, endTime FROM OfficeHours WHERE lawyerId = @LawyerId;
    `;

    const result = await pool.request()
      .input('LawyerId', sql.Int, lawyerId)
      .query(query);

    const profileData = result.recordsets[0][0];

    if (!profileData) {
      return res.status(404).json({ error: 'No profile found for the given ID' });
    }
    const practiceAreas = result.recordsets[1];
    const consultationModes = result.recordsets[2];
    const officeHours = result.recordsets[3];


    const images = {
      frontImage: profileData.frontImage ? `/images/${profileData.frontImage}` : null,
      backImage: profileData.backImage ? `/images/${profileData.backImage}` : null,
      LLBdegree: profileData.LLBdegree ? `/images/${profileData.LLBdegree}` : null,
      LAWGATresult: profileData.LAWGATresult ? `/images/${profileData.LAWGATresult}` : null,
      certificateImage: profileData.certificateImage ? `/images/${profileData.certificateImage}` : null,
      approvalImage: profileData.approvalImage ? `/images/${profileData.approvalImage}` : null,
      lawyerImage: profileData.lawyerImage ? `/images/${profileData.lawyerImage}` : null,
    };

    res.status(200).json({
      profileData,
      practiceAreas,
      consultationModes,
      officeHours,
      images,
    });

    await pool.close();
  } catch (error) {
    console.error('Error fetching profile data:', error);
    res.status(500).json({ error: 'An error occurred while fetching profile data' });
  }
});


app.post('/update-status-approved/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('ID', sql.Int, id)
      .query("UPDATE LawyerSignupData SET Status = 'Approved', verificationDate = GETDATE() WHERE ID = @ID");

    res.status(200).json({ message: 'Profile approved successfully' });
  } catch (err) {
    console.error('Error updating profile status to approved:', err);
    res.status(500).json({ message: 'Failed to approve profile' });
  }
});


app.post('/update-status-rejection/:id', async (req, res) => {
  const { id } = req.params;
  const { rejections, notes } = req.body;

  try {
    const pool = await sql.connect(dbConfig);
    await pool.request()
      .input('ID', sql.Int, id)
      .input('Rejections', sql.NVarChar, rejections.join(', '))
      .input('Notes', sql.NVarChar, notes)
      .query("UPDATE LawyerSignupData SET Status = 'Rejected', RejectionNotes = @Notes, rejections = @Rejections, verificationDate = GETDATE() WHERE ID = @ID");

    res.status(200).json({ message: 'Profile rejected successfully' });
  } catch (err) {
    console.error('Error updating profile status to rejected:', err);qx 
    res.status(500).json({ message: 'Failed to reject profile' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
