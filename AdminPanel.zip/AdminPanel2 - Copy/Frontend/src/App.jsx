import React, { useEffect, useState } from 'react';
import './App.css';
import { BrowserRouter, Route, Routes, useLocation } from 'react-router-dom';
import Sidebar from './layout/Sidebar/Sidebar';
import Login from './layout/Login/signin';
import Content from './layout/Content/Content';
import Add from './layout/Outer/Add_Fix';
import All from './layout/Outer/All';
import Edit from './layout/Outer/Edit_Fix';
import Delete from './layout/Outer/Delete_Fix';
import OCR from './OCR/OCRComponent';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { TableProvider } from './layout/Outer/TableContext'
import { SearchDataProvider } from './layout/Outer/Searchdatacontext';
import ReviewRequests from './components/ReviewRequest/ReviewRequest';
import Profile from './components/ReviewRequest/Profile';

function App() {
  
  const location = useLocation();

  // State to track whether to render the Sidebar
  const [shouldRenderSidebar, setShouldRenderSidebar] = useState(true);

  // Use useEffect to update shouldRenderSidebar based on route changes
  useEffect(() => {
    // Update shouldRenderSidebar based on the current route
    setShouldRenderSidebar(!['/'].includes(location.pathname));
  }, [location.pathname]);


  return (
    <div className='app'>
      {shouldRenderSidebar && <Sidebar />}

      <Routes>
        <Route path="/" element={<Login/>} />
        <Route path="/dashboard" element={<Content />} />
        <Route path="/all-judgements" element={<All />} />
        <Route path="/add-judgement" element={<Add />} />
        <Route path="/delete-judgement" element={<Delete />} />
        <Route path="/edit-judgement" element={<Edit />} />
        <Route path="/review-requests" element={<ReviewRequests />} />
        <Route path="/ocr" element={<OCR/>} />
        <Route path="/profile/:id" element={<Profile/>} />

      </Routes>
      <ToastContainer
          position="top-center"
          autoClose={1000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
          style={{ width: '350px' }} 
          />
    </div>
    
  );
}

function MainApp() {
  return (
    <BrowserRouter>
      <TableProvider>
      <SearchDataProvider>
        <App />
      </SearchDataProvider>
      </TableProvider>
      
      
    </BrowserRouter>
  );
}

export default MainApp;