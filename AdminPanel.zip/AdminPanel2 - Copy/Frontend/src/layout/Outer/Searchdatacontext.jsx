import React, { createContext, useContext, useState } from 'react';

// Create a context with an initial value
const SearchDataContext = createContext();

// Create a provider component that will wrap your components
export const SearchDataProvider = ({ children }) => {
  const [activeLinkIdx, setActiveLinkIdx] = useState();
  const [searchData, setSearchData] = useState({
    caseno: '',
    casesubject: '',
    casetitle: '',
    judgename: '',
    judgementdate: '',
    courtname: '',
    casecitation: '',
    othercitation:'',
    tagline: '',
    judgement: '',
  });
  const [searchData2, setSearchData2] = useState({
    caseno0: '',
    caseno:'',
    casesubject: '',
    casetitle: '',
    judgename: '',
    judgementdate: '',
    courtname: '',
    casecitation: '',
    othercitation:'',
    tagline: '',
    judgement: '',
  });

  const handleClearData = () => {
    // Clear all the fields
    setSearchData({
      caseno: '',
      casesubject: '',
      casetitle: '',
      judgename: '',
      courtname: '',
      judgementdate: '',
      casecitation: '',
      othercitation:'',
      tagline: '',
      judgement: '',
    });
  };
  const handleClearData2 = () => {
    // Clear all the fields
    setSearchData2({
      caseno0: '',
      caseno: '',
      casesubject: '',
      casetitle: '',
      judgename: '',
      courtname: '',
      judgementdate: '',
      casecitation: '',
      othercitation:'',
      tagline: '',
      judgement: '',
    });
  };

  return (
    <SearchDataContext.Provider value={{ searchData, setSearchData,searchData2, setSearchData2,activeLinkIdx,setActiveLinkIdx, handleClearData,handleClearData2 }}>
      {children}
    </SearchDataContext.Provider>
  );
};

// Create a custom hook to use the context
export const useSearchData = () => {
  const context = useContext(SearchDataContext);
  if (!context) {
    throw new Error('useSearchData must be used within a SearchDataProvider');
  }
  return context;
};
