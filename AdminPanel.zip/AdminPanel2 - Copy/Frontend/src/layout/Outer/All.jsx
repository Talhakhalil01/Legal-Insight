import { iconsImgs } from "../../utils/images";
import "./AllJudgments.css";
import ContentTop from '../../components/F_AddJudgement/AddJudgments';
// import ContentTop from '../../components/ContentTop/ContentTop';
import React, { useEffect, useState } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import './Table.css';
import { navigationLinks } from '../../data/data';
import axios from 'axios';
import { useTable } from './TableContext';
import Judgement from './Judgement';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ClipLoader from "react-spinners/MoonLoader";
import { useSearchData } from './Searchdatacontext';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { IoWarning } from "react-icons/io5";




const All = () => {

  const navigate = useNavigate();
  const [selectedJudgement, setSelectedJudgement] = useState(null);
  const [searchButtonClicked, setSearchButtonClicked] = useState(false);
  const { tableData, updateTableData, loading2, updateLoading } = useTable();
  const [tableData2, updateTableData2] = useState(null);
  const [numCases, setNumCases] = useState("100");
  const[tables,setTables]=useState('')
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const { searchData2, setSearchData2,setActiveLinkIdx } = useSearchData();

  useEffect(() => {
    const pathToIdMapping = {
      '/': 1,
      '/all-judgements': 2,
      '/add-judgement': 3,
      '/delete-judgement': 4,
      '/edit-judgement': 5,
      '/review-requests': 6
    };

    const currentPath = location.pathname;
    const newActiveLinkIdx = pathToIdMapping[currentPath] || 1; // Default to 1 if path not found

    setActiveLinkIdx(newActiveLinkIdx);
  }, [location, setActiveLinkIdx]);

  
  useEffect(() => {
    
    updateTableData2(tableData);
    if(tableData)
    {
      console.log("Table data is:::",tableData.length)
     
    }
    else{console.log("No data in table....................")}
  }, [tableData]);

  useEffect(() => {
    console.log("Table block rendered")
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5002');
    
        if (response.data.valid) {
        } else {

               navigate("/");
               toast.error("Unauthorized access")
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchCurrentUser();
    
  }, []);

  useEffect(() => {
    const fetchCaseLaws = async () => {

      if (!tableData || tableData.length === 0) {
          updateLoading(true);
          try {
            const response = await axios.get('http://localhost:5002/all');
            updateTableData(response.data);
            updateLoading(false)
          } catch (error) {
            console.error('Error fetching CaseLaws:', error.message);
            updateLoading(false)
            
          }
    }
    };

    fetchCaseLaws();
   
  }, []);

  useEffect(() => {
    const handleShowButtonClick = async () => {
      if (tableData) {
        const totalRecords = tableData.length;
  
        // Calculate total pages
        const totalPages = Math.ceil(totalRecords / parseInt(numCases, 10));
        setTotalPages(totalPages);
  
        // Calculate the start and end indices of the current chunk
        let startIndex = (currentPage - 1) * parseInt(numCases, 10);
        let endIndex = Math.min(startIndex + parseInt(numCases, 10), totalRecords);
  
        // If startIndex exceeds totalRecords, set currentPage to 1
        if (startIndex >= totalRecords) {
          startIndex = 0;
          endIndex = Math.min(startIndex + parseInt(numCases, 10), totalRecords);
          setCurrentPage(1);
        }
  
        // Get the current chunk of data
        const currentChunk = tableData.slice(startIndex, endIndex);
  
        if (currentChunk) {
          console.log("Data at current chunk is:::", currentChunk.length);
        } else {
          console.log("No data in the current chunk");
        }
  
        updateTableData2(currentChunk);
  
        // Update the input field to display current page and total pages
        setTables(`${currentPage} of ${totalPages}`);
      }
    };
  
    handleShowButtonClick();
  }, [tableData, currentPage, numCases]);
  
  const handleInputChange = (e) => {
    setNumCases(e.target.value);
  };

  const handlePreviousClick = () => {
    if (currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);
    }
  };
  
  const handleNextClick = () => {
    if (currentPage < totalPages) {
      setCurrentPage((prevPage) => prevPage + 1);
    }
  };

  
  const openJudgementModal = (judgement) => {
    setSelectedJudgement(judgement);
  };

  const closeJudgementModal = () => {
    setSelectedJudgement(null);
  };

  // If tableData is empty and the search button has been clicked, display a message
  if (!tableData || (tableData.length === 0 && searchButtonClicked)) {
    console.log('No data received at table.js', tableData);
    alert("No data found")
    return <div className="error">No results found</div>;
  }
  const handleCaseEdit = (row) => {
    setSearchData2({
      caseno0: row.CaseNo,
      caseno: row.CaseNo, 
      casesubject: row.CaseSubject,
      casetitle: row.CaseTitle,
      judgename: row.AuthorJudge,
      courtname: row.Court,
      judgementdate: row.JudgementDate,
      casecitation: row.SCCitation,
      othercitation: row.Citation,
      tagline: row.Tagline,
      judgement: row.Judgement,
    });
    console.log("Form data:",searchData2)
    setActiveLinkIdx(5);
    navigate('/edit-judgement');
    
  };
  
  const handleCaseDelete = (caseno) => {
    confirmAlert({
      // title: 'Confirm to submit',
      // <IoWarning />
      message: 'Are you sure you want to delete this case law?',
      buttons: [
        {
          label: 'Yes',
          onClick: async () => {
            try {
              const response = await axios.delete('http://localhost:5002/delete', {
                data: { caseno }
              });

              if (response.data.success) {
                toast.success('Judgement deleted successfully');
                updateTableData((prevData) => prevData.filter(row => row.CaseNo !== caseno));   
              } 
              else {
                toast.error('Failed to delete judgement');
              }
             
            } catch (error) {
              console.error('Error deleting case law:', error);
              toast.error('Failed to delete case law');
            }
          }
        },
        {
          label: 'No',
          onClick: () => {}
        }
      ]
    });
  };


  
  return (
<div className='outer_add_judge'>
    <ContentTop/>
    {loading2 ? 
                (<div className="loading-spinner">
                      <ClipLoader
                        color={"#fe6c00"}
                        loading={loading2}
                        size={100}
                      />
                  </div>)
                  :
    (
    <div className='grid1_outer'> 
      <div className='grid2_inner'>
       <h1>All Judgements      {tableData ? tableData.length : 0}</h1> 
       <br></br>
       
       <div className="table-container">
       <div className="options">
                 <div className="show-cases">
                      <span>Show</span>
                      <select
                                className="show-num"
                                name="show-num"
                                value={numCases}
                                onChange={handleInputChange}
                                // onClick={handleShowButtonClick}
                                 
                               
                              >
                                <option value="100">100</option>
                                <option value="200">200</option>
                                <option value="300">300</option>
                                <option value="400">400</option>
                                <option value="500">500</option>
                                {/* <option value="100">100</option> */}
                               
                              
                              </select>
                      <span>Cases</span>
                      <button className="previous" onClick={handlePreviousClick}>Prev</button>
                      <input
                        type="text"
                        name="tables"
                        value={tables}
                        className="tables"
                        readOnly
                      />
                      <button onClick={handleNextClick}>Next</button>
                  </div>
                  

                
                 </div>
   
      <div className="table">
      
        {tableData2  && tableData2.length > 0 ? (
          
          <table>
            <thead>
              <tr>
                <th className='th'>Case no.</th>
                <th className='th'>Case Subject</th>
                <th className='th'>Case Title</th>
                <th className='th'>Author Judge</th>
                <th className='th'>Court</th>
                <th className='th'>Judgement Date</th>
                <th className='th'>Citation</th>
                <th className='th'>Other Citation</th>
                <th className='th'>Judgement</th>
                <th className='th'>Edit Judgement</th>
                <th className='th'>Delete Judgement</th>
                
              </tr>
            </thead>
            <tbody>
              {tableData2.map((row, index) => (
                <React.Fragment key={index}>
                  <tr>
                    <td className='td cno'><div>{row.CaseNo}</div></td>
                    <td className='td csub'><div>{row.CaseSubject}</div></td>
                    <td className='td ctitle'><div>{row.CaseTitle}</div></td>
                    <td className='td ajudge'><div>{row.AuthorJudge}</div></td>
                    <td className='td cname'><div>{row.Court}</div></td>
                    <td className='td jdate'><div>{row.JudgementDate}</div></td>
                    <td className='td citation'><div>{row.SCCitation}</div></td>
                    <td className='td othercitation'><div>{row.Citation}</div></td>
                    <td className="button1"><button className="opencaselaw" onClick={() => openJudgementModal(row.Judgement)}>
                      Read Full Text</button></td>
                    <td className="button1"><button className="edit-btn" onClick={() =>handleCaseEdit(row)}>
                      Edit</button></td>
                    <td className="button1"><button className="delete-btn" onClick={() => handleCaseDelete(row.CaseNo)}>
                      Delete</button></td>
                  </tr>
                  <tr>
                    <td colSpan="11" className='tagline'>{row.Tagline}</td>
                  </tr>
                </React.Fragment>
              ))}
            </tbody>
          </table>
        ) :(tableData2 !== null && tableData2.length === 0 ? (
          <div className="error">No Results Found</div>
        ) : null)}
        {selectedJudgement && (
          <Judgement judgement={selectedJudgement} onClose={closeJudgementModal} />
        )}
      </div>
    </div>
       
       </div>

    </div>
)}
    </div>
  )
}

export default All;
