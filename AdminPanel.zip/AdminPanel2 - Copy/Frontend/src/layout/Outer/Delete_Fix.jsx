import React, { useEffect, useState } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import "./Delete_Fix.css";
import ContentTop from '../../components/F_AddJudgement/AddJudgments';
import { navigationLinks } from '../../data/data';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useSearchData } from './Searchdatacontext';

const Delete = () => {
  const navigate = useNavigate();
  const [searchData, setSearchData] = useState({
    caseno: ''
  });
  const {setActiveLinkIdx } = useSearchData();

  useEffect(() => {
    const pathToIdMapping = {
      '/': 1,
      '/all-judgements': 2,
      '/add-judgement': 3,
      '/delete-judgement': 4,
      '/edit-judgement': 5,
      '/review-requests': 6
    };

    const currentPath = location.pathname;
    const newActiveLinkIdx = pathToIdMapping[currentPath] || 1; // Default to 1 if path not found

    setActiveLinkIdx(newActiveLinkIdx);
  }, [location, setActiveLinkIdx]);


  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5002');
    
        if (response.data.valid) {
            //Do nothing
        } else {
               navigate("/");
               toast.error("Unauthorized access")
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchCurrentUser();
    
  }, []);
 
  const handleSubmission = async (e) => {
    e.preventDefault();

    try {
      const caseno= searchData.caseno;
      
      const response = await axios.delete('http://localhost:5002/delete', {
              data: { caseno }
            });
      if (response.data.success) {
        toast.success('Judgement deleted successfully');
        // Optionally, clear the form or perform any other actions after deletion
        setSearchData({ caseno: '' });
      } else {
        toast.error('Failed to delete judgement');
      }
    } catch (error) {
      console.error('Error deleting judgement:', error.message);
      toast.error(`Error deleting judgement: ${error.message}`);
    }
  };

 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSearchData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

 
  return (
    <div className='outer_add_judge3'>
    <ContentTop/>
     <div className='grid1_outer'> 
      <div className='grid2_inner'>
       <h1>Delete Judgement</h1> 
       <br></br>
        <form onSubmit={handleSubmission}>
        <label className="lable_out">
              Case No:
              <input className="inputs_in"  id="in1"
                type="text"
                placeholder='Enter the Case no. of case that needs to be deleted'
                name="caseno"
                value={searchData.caseno}
                onChange={handleChange}
                required
                
              />
        </label>
        <br></br>
           
            
           
            {/* Submit button */}
            <br></br>
            <button className="sub_button" type="submit">Delete Judgement</button>
        </form>
       
   
       </div>

     </div>

     
      
    </div>
  );
}

export default Delete;
