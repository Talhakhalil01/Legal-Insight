import React, { useEffect, useState } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import "./Edit_Fix.css";
import ContentTop from '../../components/F_AddJudgement/AddJudgments';
import { navigationLinks } from '../../data/data';
import Add from '../../components/AddJudgement/AddJudgments'
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useSearchData } from './Searchdatacontext';
import { useTable } from './TableContext';


const Edit = () => {
  const navigate = useNavigate();
  const { tableData, updateTableData, loading2, updateLoading } = useTable();
  const { searchData2, setSearchData2, handleClearData2,setActiveLinkIdx } = useSearchData();

  useEffect(() => {
    const pathToIdMapping = {
      '/': 1,
      '/all-judgements': 2,
      '/add-judgement': 3,
      '/delete-judgement': 4,
      '/edit-judgement': 5,
      '/review-requests': 6
    };

    const currentPath = location.pathname;
    const newActiveLinkIdx = pathToIdMapping[currentPath] || 1; // Default to 1 if path not found

    setActiveLinkIdx(newActiveLinkIdx);
  }, [location, setActiveLinkIdx]);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5002');
    
        if (response.data.valid) {
            //Do nothing
        } else {
               navigate("/");
               toast.error("Unauthorized access")
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchCurrentUser();
    
  }, []);

  
  const fetchCaseLaws = async () => {

        updateLoading(true);
        try {
          const response = await axios.get('http://localhost:5002/all2');
          updateTableData(response.data);
          updateLoading(false)
        } catch (error) {
          console.error('Error fetching CaseLaws:', error.message);
          updateLoading(false)
          
        }
  
  };

  
  const handleSubmission = async (e) => {
    e.preventDefault();
    
    try {
      const response = await axios.post('http://localhost:5002/edit', searchData2);
      if (response.data.success) {
        fetchCaseLaws();
        toast.success('Judgement edited successfully');
        handleClearData2(); // Clear form fields on successful submission
      } 
      else {
        // Handle other errors
        toast.error('Error editing judgement');
      }
    } catch (error) {
      console.error('Error editing judgement:', error.message);
      toast.error(`Error editing judgement: ${error.message}`);
    }
  };

  

 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSearchData2((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

 
  return (
    <div className='outer_add_judge2'>
    <ContentTop/>
     <div className='grid1_outer'> 
      <div className='grid2_inner'>
       <h1>Edit Judgement</h1> 
       <br></br>
        <form onSubmit={handleSubmission} className='form2'>
        <label className="lable_out">
              Existing Case No:
              <input className="inputs_in"  id="in10"
                type="text"
                placeholder='Case no. is required to specify the case to be edited'
                name="caseno0"
                value={searchData2.caseno0}
                onChange={handleChange}
                required
                tabIndex="1"
                
              />
        </label>
       
        <label className="lable_out">
             New Case No:
              <input className="inputs_in"  id="in1"
                type="text"
                placeholder='Enter new case no.'
                name="caseno"
                value={searchData2.caseno}
                onChange={handleChange}
                tabIndex="2"
              
                
              />
        </label>
        <br></br>
            <label className="lable_out">
            New Case Subject:
              <input className="inputs_in" id="in2"
                   type="text"
                   placeholder='Enter new case subject'
                   name="casesubject"
                   value={searchData2.casesubject}
                   onChange={handleChange}
                   tabIndex="3"
                  
               
              />
            </label >
            <br></br>
            <label className="lable_out">
            New Case Title:
              <input className="inputs_in" id="in3"
                type="text"
                placeholder='Enter new case title'
                name="casetitle"
                value={searchData2.casetitle}
                onChange={handleChange}
                tabIndex="4"
               
              />
            </label>

            <br></br>
            <label className="lable_out">
            New Court:
              <input className="inputs_in" id="in4"
                   type="text"
                   placeholder='Enter new court name'
                   name="courtname"
                   value={searchData2.courtname}
                   onChange={handleChange}
                   tabIndex="5"
               
              />
            </label>

            <br></br>
            <label className="lable_out">
            New Author Judge:
              <input className="inputs_in" id="in5"
                type="text"
                placeholder='Enter new author Judge'
                name="judgename"
                value={searchData2.judgename}
                onChange={handleChange}
                tabIndex="6"
                
              />
            </label>

            <br></br>
            <label className="lable_out">
            New Judgement Date:
              <input className="inputs_in" id="in6"
                type="text"
                placeholder='Enter new judgement date'
                name="judgementdate"
                value={searchData2.judgementdate}
                onChange={handleChange}
                tabIndex="7"
              />
            </label>

            <br></br>
            <label className="lable_out">
            New Citation:
              <input className="inputs_in" id="in7"
                type="text"
                placeholder='Enter new case citation'
                name="casecitation"
                value={searchData2.casecitation}
                onChange={handleChange}
                tabIndex="8"
               
              />
            </label>

            <br></br>
            <label className="lable_out">
            New other Citation:
              <input className="inputs_in" id="in11"
                type="text"
                placeholder='Enter new other citation'
                name="othercitation"
                value={searchData2.othercitation}
                onChange={handleChange}
                tabIndex="8"
               
              />
            </label>

            <br></br>
            <label className="lable_out">
            New Tagline:
              <input className="inputs_in" id="in8"
                type="text"
                placeholder='Enter new tagline'
                name="tagline"
                value={searchData2.tagline}
                onChange={handleChange}
                tabIndex="9"
               
              />
            </label>

            <br></br>
            <label className="lable_out2">
            <span className='label'>New Judgment:</span>
              <textarea
                className="inputs_in2"
                id="in9"
                placeholder='Enter new judgement'
                name="judgement"
                value={searchData2.judgement}
                onChange={handleChange}
                tabIndex="10"
              />
            </label>
           
            {/* Submit button */}
            <br></br>
            <button id='edit1' className="sub_button" type="submit">Edit Judgement</button>
        </form>
       
   
       </div>

     </div>

     
      
    </div>
  );
}

export default Edit;
