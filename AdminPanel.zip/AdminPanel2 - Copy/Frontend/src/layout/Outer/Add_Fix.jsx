import React, { useEffect, useState } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import "./Add_Fix.css";
import ContentTop from '../../components/F_AddJudgement/AddJudgments';
import { navigationLinks } from '../../data/data';
import Add from '../../components/AddJudgement/AddJudgments'
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Link } from 'react-router-dom';
import { useSearchData } from './Searchdatacontext';


const Content = () => {
  const navigate = useNavigate();
  const { searchData, setSearchData, handleClearData } = useSearchData();
  const {setActiveLinkIdx } = useSearchData();

  useEffect(() => {
    const pathToIdMapping = {
      '/': 1,
      '/all-judgements': 2,
      '/add-judgement': 3,
      '/delete-judgement': 4,
      '/edit-judgement': 5,
      '/review-requests': 6
    };

    const currentPath = location.pathname;
    const newActiveLinkIdx = pathToIdMapping[currentPath] || 1; // Default to 1 if path not found

    setActiveLinkIdx(newActiveLinkIdx);
  }, [location, setActiveLinkIdx]);


  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5002');
    
        if (response.data.valid) {
            //Do nothing
        } else {
               navigate("/");
               toast.error("Unauthorized access")
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchCurrentUser();
    
  }, []);
  const handleSubmission = async (e) => {
    e.preventDefault();
  
    try {
      const response = await axios.post('http://localhost:5002/add', searchData);
  
      if (response.data.success) {
        toast.success('Judgment added successfully');
        handleClearData(); // Clear form fields on successful submission
      } else {
        toast.error('Failed to add judgment');
      }
    } catch (error) {
      console.error('Error adding judgment:', error.message);
      toast.error(`Error adding judgment: ${error.message}`);
    }
  };

 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSearchData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

 
  return (
    <div className='outer_add_judge'>
    <ContentTop/>
     <div className='grid1_outer'> 
      <div className='grid2_inner'>
       <h1>Add Judgement</h1> 
       <br></br>
        <form onSubmit={handleSubmission}>
        <label className="lable_out">
              Case No:
              <input className="inputs_in"  id="in1"
                type="text"
                name="caseno"
                value={searchData.caseno}
                onChange={handleChange}
                required
                
              />
        </label>
        <br></br>
            <label className="lable_out">
              Case Subject:
              <input className="inputs_in" id="in2"
                   type="text"
                   name="casesubject"
                   value={searchData.casesubject}
                   onChange={handleChange}
                   required
               
              />
            </label >
            <br></br>
            <label className="lable_out">
              Case Title:
              <input className="inputs_in" id="in3"
                type="text"
                name="casetitle"
                value={searchData.casetitle}
                onChange={handleChange}
                required
               
              />
            </label>

            <br></br>
            <label className="lable_out">
              Court:
              <input className="inputs_in" id="in4"
                   type="text"
                   name="courtname"
                   value={searchData.courtname}
                   onChange={handleChange}
                   required
               
              />
            </label>

            <br></br>
            <label className="lable_out">
            Author Judge:
              <input className="inputs_in" id="in5"
                type="text"
                name="judgename"
                value={searchData.judgename}
                onChange={handleChange}
                required
                
              />
            </label>

            <br></br>
            <label className="lable_out">
            Judgement Date:
              <input className="inputs_in" id="in6"
                type="text"
                name="judgementdate"
                value={searchData.judgementdate}
                onChange={handleChange}
                required
              />
            </label>

            <br></br>
            <label className="lable_out">
            Citation:
              <input className="inputs_in" id="in7"
                type="text"
                name="casecitation"
                value={searchData.casecitation}
                onChange={handleChange}
                required
               
              />
            </label>

            <br></br>
            <label className="lable_out">
            Other Citation:
              <input className="inputs_in" id="in10"
                type="text"
                name="othercitation"
                value={searchData.othercitation}
                onChange={handleChange}
                required
               
              />
            </label>

            <br></br>
            <label className="lable_out">
            Tagline:
              <input className="inputs_in" id="in8"
                type="text"
                name="tagline"
                value={searchData.tagline}
                onChange={handleChange}
                required
               
              />
            </label>

            <br></br>
            <label className="lable_out2">
              <span className='label'>Judgment:</span>
              <textarea
                className="inputs_in2"
                id="in9"
                name="judgement"
                value={searchData.judgement}
                onChange={handleChange}
                required
              />
            </label>
           
            {/* Submit button */}
            <br></br>
            <br></br>
            <Link to="/ocr">
            <button  className="sub_button2" >Scan Judgement</button>
            </Link>
            <button className="sub_button" type="submit">Add Judgement</button>
     
            
        
        </form>
       
   
       </div>

     </div>

     
      
    </div>
  );
}

export default Content;
