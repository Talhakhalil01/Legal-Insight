import React, { createContext, useContext, useState } from 'react';

const TableContext = createContext();

export const TableProvider = ({ children }) => {
  const [tableData, setTableData] = useState([]);
  const [loading2 , setLoading2] = useState(false);


  const updateTableData = (newData) => {
    setTableData(newData);
  };

  const updateLoading = (loading4) => {
    setLoading2(loading4);
  };
  

  return (
    <TableContext.Provider value={{ tableData,loading2, updateTableData, updateLoading }}>
      {children}
    </TableContext.Provider>
  );
};

export const useTable = () => {
  const context = useContext(TableContext);
  if (!context) {
    throw new Error('useTable must be used within a TableProvider');
  }
  return context;
};
