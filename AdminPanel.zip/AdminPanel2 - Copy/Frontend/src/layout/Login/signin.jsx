import React, { useState,useEffect } from "react"
import "./signin.css"
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { FaUser,FaLock } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useUser } from '../Login/UserContext';




const Signin = () => 
{
    
  
  const navigate = useNavigate();

 
  const [formData2, setFormData2] = useState({
    email: "",
    password: ""
  });
 
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5002');
    
        if (response.data.valid) {

          navigate("/dashboard")
        
        } else {
                   
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        
      }
    };
    fetchCurrentUser();
    
  }, []);


  const [showPassword2, setShowPassword2] = useState(false);


  
  const handleSubmit2 = async (event) => {
    event.preventDefault();

    const data = {
      username: formData2.email,
      password: formData2.password
    };

    try {
      const response = await fetch('http://localhost:5002/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include'
      });

      if (response.ok) {
        setFormData2({
          email: "",
          password: ""
        });
        navigate('/dashboard');

        // Perform actions based on successful login
       // For example, redirect to a dashboard or update UI
      } else {
        // console.error('Login failed');
        // alert('No record found with given data');
        toast.error("Incorrect cridentials")
      }
    } catch (error) {
      toast.error("Server error during login")
    }
  };
 
  
    return (
        <div className="signup-wrapper">
        <div className="wrapper">
          <form action="" onSubmit={handleSubmit2}>
            <h1>Sign In</h1>
  
            <div className="input-box">
              <input 
              type="text"
              placeholder="Email"
              required
              name="email"
              value={formData2.email}
              onChange={(e) => setFormData2({ ...formData2, email: e.target.value })}
              />
              <MdEmail className="icon"/>
            </div>
  
            <div className="input-box">
              <input 
              type="password" 
              placeholder="Password" 
              required
              name="password"
              value={formData2.password}
              onChange={(e) => setFormData2({ ...formData2, password: e.target.value })}
              />
              <FaLock className="icon"/>
            </div>
  
            <button type="submit">Login</button>
            {/* <div className="register-link">
              <p>Don't have an account?<a href="#" onClick={handleSignup}>Sign Up</a></p>
            </div> */}
          </form>
        </div>
       </div> 
    )
  

};
export default Signin;