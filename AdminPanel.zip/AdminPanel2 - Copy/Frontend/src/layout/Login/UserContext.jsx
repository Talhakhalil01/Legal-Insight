// UserContext.js
import React, { createContext, useContext, useState } from 'react';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [userdata, setUserdata] = useState(null);

  const login = () => {
    setUserdata(1);
  };

  const logout = () => {
    setUserdata(0);
  };

  return (
    <UserContext.Provider value={{ userdata, login, logout }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  return useContext(UserContext);
};
