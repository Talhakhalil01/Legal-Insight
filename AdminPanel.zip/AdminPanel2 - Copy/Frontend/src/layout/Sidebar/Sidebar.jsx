import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { iconsImgs } from '../../utils/images';
import { navigationLinks } from '../../data/data';
import { useSearchData } from '../Outer/Searchdatacontext';
import "./Sidebar.css";

const Sidebar = () => {
  const {activeLinkIdx, setActiveLinkIdx} = useSearchData();
  const [sidebarClass, setSidebarClass] = useState("");
  const navigate = useNavigate();

   useEffect(() => {
    // Update active link index based on the current route
    const currentRoute = navigationLinks.find(link => link.title.toLowerCase() === window.location.pathname.substring(1));
    if (currentRoute) {
      setActiveLinkIdx(currentRoute.id);
    }
  }, []);
  useEffect(() => {
    // Add any other necessary sidebar state updates
  }, [activeLinkIdx]);

  const handleLinkClick = (link) => {
    setActiveLinkIdx(link.id);
    
    console.log(`Clicked on ${link.title}, navigating to ${link.id === 3 ? '/add-judgment' : `/${link.title.toLowerCase()}`}`);
    
  if (link.id === 1 && window.location.pathname !== '/') {
    navigate('/');
  }
    if (link.id === 2) {
      navigate('/all-judgements');
    }
    // Redirect to "/add-judgments" if the clicked link is "Add Judgments"
    if (link.id === 3) {
      navigate('/add-judgement');
    }
    // Redirect to "/add-judgments" if the clicked link is "Add Judgments"
    if (link.id === 4) {
      navigate('/edit-judgement');
    }
    // Redirect to "/add-judgments" if the clicked link is "Add Judgments"
    if (link.id === 5) {
      navigate('/delete-judgement');
    }
  };

  return (
    <div className={`sidebar ${sidebarClass}`}>
    <div className="user-info">
        <div className="info-img img-fit-cover">
          <img src={iconsImgs.compliant} alt="profile image" />
        </div>
        <span className="info-name">Legal-insight</span>
      </div>

    <nav className="navigation">
      <ul className="nav-list">
        {navigationLinks.map((navigationLink) => (
          <li className="nav-item" key={navigationLink.id}>
            <Link
             to={navigationLink.id === 3 ? '/add-judgement' : `/${navigationLink.title.toLowerCase().replace(' ', '-')}`}
              className={`nav-link ${navigationLink.id === activeLinkIdx ? 'active' : ''}`}
              onClick={() => handleLinkClick(navigationLink)}
            >
              <img src={navigationLink.image} className="nav-link-icon" alt={navigationLink.title} />
              <span className="nav-link-text">{navigationLink.title}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  </div>
  );
}

export default Sidebar;
