import React, { useEffect, useState } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import "./Content.css";
import ContentTop from '../../components/ContentTop/ContentTop';
import { navigationLinks } from '../../data/data';
import ContentMain from '../../components/ContentMain/ContentMain';
import Sidebar from '../Sidebar/Sidebar';

import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Content = () => {
  const navigate = useNavigate();
  const [activeLinkIdx, setActiveLinkIdx] = useState(1);

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        axios.defaults.withCredentials = true;
        const response = await axios.get('http://localhost:5002');
    
        if (response.data.valid) {
            

        } else {

               
               navigate("/");
               toast.error("Unauthorized access")
               
  
          
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchCurrentUser();
    
  }, []);

  useEffect(() => {
    // Update active link index based on the current route
    const currentRoute = navigationLinks.find(link => link.title.toLowerCase() === window.location.pathname.substring(1));
    console.log("Current Route:", currentRoute); // Add this line for debugging
    if (currentRoute) {
      setActiveLinkIdx(currentRoute.id);
    }
  }, []);

  const handleLinkClick = (link) => {
    console.log("Link Clicked:", link); // Add this line for debugging
    setActiveLinkIdx(link.id);
    navigate(`/${link.title.toLowerCase()}`);
  };

  return (
    <div className='main-content'>
      
      <ContentTop />
      <ContentMain/>
      <Outlet />

      {/* Render the corresponding component or a default message */}
      {navigationLinks.map((link) => (
        <React.Fragment key={link.id}>
          {link.id === activeLinkIdx && link.component && (
            <link.component />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

export default Content;
