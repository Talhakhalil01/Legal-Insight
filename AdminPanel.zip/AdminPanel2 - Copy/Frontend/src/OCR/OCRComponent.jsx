import React, { useState, useRef, useEffect } from "react";
import { createWorker } from "tesseract.js";
import './OCRComponent.css';
import 'react-toastify/dist/ReactToastify.css';
import { toast } from "react-toastify";
import { useSearchData } from '../layout/Outer/Searchdatacontext';
import { useNavigate  } from "react-router-dom";
import { HiArrowCircleLeft } from "react-icons/hi";
import { HiArrowCircleRight } from "react-icons/hi";




const OCRComponent = () => {
  const [language, setLanguage] = useState("eng");
  const [files, setFiles] = useState([]); // Array to hold selected files
  const [recognizedTexts, setRecognizedTexts] = useState(''); // Array to store extracted text for each file
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("");
  const { setSearchData } = useSearchData();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleLanguageChange = (event) => {
    setLanguage(event.target.value);
  };

  const handleFileChange = (event) => {
    setFiles(Array.from(event.target.files));
    setCurrentIndex(0);
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % files.length);
  };

  const handlePrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + files.length) % files.length);
  };

 const preprocessImage = (image) => {
    // Create a canvas element
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    // Calculate the new dimensions (75% of original)
    const width = image.width * 0.75;
    const height = image.height * 0.75;

    // Set canvas dimensions to the new dimensions
    canvas.width = width;
    canvas.height = height;

    // Draw the resized image on the canvas
    ctx.drawImage(image, 0, 0, width, height);


    // Return the processed image as a blob
    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        resolve(blob);
      });
    });
  };

  const processImage = async (file, index) => {
    const worker = await createWorker();

    const img = new Image();
    img.src = URL.createObjectURL(file);

    return new Promise((resolve) => {
      img.onload = async () => {
        const processedImageBlob = await preprocessImage(img);

        const { data } = await worker.recognize(processedImageBlob, language);
        await worker.terminate();

       setRecognizedTexts((prev) => {
          const updatedTexts = [...prev];
           updatedTexts[index] = ` \n Page:${index+1} \n`
          updatedTexts[index] += data.text.replace(/\n\s*\n/g, "\n");
           updatedTexts[index] += ` \n Page:${index+1} \n`
          return updatedTexts;
        });
        setProgress((index + 1) / files.length); // Update progress for each file
        setStatus(
          `Recognized ${index + 1} out of ${files.length} images. Processing...`
        ); // Update status message
        console.log(`Recognized ${index + 1} out of ${files.length} images. Processing...`);
        
        resolve();
      };
    });
  };

  const handleStartRecognition = async () => {
    setStatus("Starting...");
    setRecognizedTexts([]); // Clear previous results before starting

    const promises = files.map((file, index) => processImage(file, index));
    await Promise.all(promises);
        setStatus("Done"); // Set status to "Done" after all files are processed
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(recognizedTexts);
    toast.success("Text copied to clipboard");
  
    // Replace the judgement field in the searchData context
    setSearchData((prevData) => ({
      ...prevData,
      judgement: recognizedTexts.join("\n"), // Join recognizedTexts array into a single string
    }));
  
    // Navigate to the /add-judgement route
    navigate("/add-judgement");
  };
  
  // Trigger file input click event on component mount
  useEffect(() => {
    fileInputRef.current.click();
  }, []);
  
  return (
    <div className="OCR">
      <h1>Optical Character Recognition</h1>
      <select className="languages" value={language} onChange={handleLanguageChange}>
        {/* ... language options ... */}
        <option value="afr"> Afrikaans </option>
        <option value="ara"> Arabic </option>
        <option value="aze"> Azerbaijani </option>
        <option value="bel"> Belarusian </option>
        <option value="ben"> Bengali </option>
        <option value="bul"> Bulgarian </option>
        <option value="cat"> Catalan </option>
        <option value="ces"> Czech </option>
        <option value="chi_sim"> Chinese </option>
        <option value="chi_tra"> Traditional Chinese </option>
        <option value="chr"> Cherokee </option>
        <option value="dan"> Danish </option>
        <option value="deu"> German </option>
        <option value="ell"> Greek </option>
        <option value="eng">English</option>
        <option value="enm"> English (Old) </option>
        <option value="meme"> Internet Meme </option>
        <option value="epo"> Esperanto </option>
        <option value="epo_alt"> Esperanto alternative </option>
        <option value="equ"> Math </option>
        <option value="est"> Estonian </option>
        <option value="eus"> Basque </option>
        <option value="fin"> Finnish </option>
        <option value="fra"> French </option>
        <option value="frk"> Frankish </option>
        <option value="frm"> French (Old) </option>
        <option value="glg"> Galician </option>
        <option value="grc"> Ancient Greek </option>
        <option value="heb"> Hebrew </option>
        <option value="hin"> Hindi </option>
        <option value="hrv"> Croatian </option>
        <option value="hun"> Hungarian </option>
        <option value="ind"> Indonesian </option>
        <option value="isl"> Icelandic </option>
        <option value="ita"> Italian </option>
        <option value="ita_old"> Italian (Old) </option>
        <option value="jpn"> Japanese </option>
        <option value="kan"> Kannada </option>
        <option value="kor"> Korean </option>
        <option value="lav"> Latvian </option>
        <option value="lit"> Lithuanian </option>
        <option value="mal"> Malayalam </option>
        <option value="mkd"> Macedonian </option>
        <option value="mlt"> Maltese </option>
        <option value="msa"> Malay </option>
        <option value="nld"> Dutch </option>
        <option value="nor"> Norwegian </option>
        <option value="pol"> Polish </option>
        <option value="por"> Portuguese </option>
        <option value="ron"> Romanian </option>
        <option value="rus"> Russian </option>
        <option value="slk"> Slovakian </option>
        <option value="slv"> Slovenian </option>
        <option value="spa"> Spanish </option>
        <option value="spa_old"> Old Spanish </option>
        <option value="sqi"> Albanian </option>
        <option value="srp"> Serbian (Latin) </option>
        <option value="swa"> Swahili </option>
        <option value="swe"> Swedish </option>
        <option value="tam"> Tamil </option>
        <option value="tel"> Telugu </option>
        <option value="tgl"> Tagalog </option>
        <option value="tha"> Thai </option>
        <option value="tur"> Turkish </option>
        <option value="ukr"> Ukrainian </option>
        <option value="urd"> Urdu </option>
        <option value="vie"> Vietnamese </option>s
      </select>


      <input
                    type="file"
                    id="uploadBtn"
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    multiple
      />
      <label for="uploadBtn" className="upload-btn"><i class="fa-solid fa-upload"></i>Upload Image</label>
               

      {/* {files.length > 0 && (
        <div className="image-preview-container">
          {files.map((file, index) => (
            <div key={index} className="image-preview">
              <img className="image" src={URL.createObjectURL(file)} alt={`Preview of image ${index + 1}`} />
            </div>
          ))}
          <button className="recognize" onClick={handleStartRecognition}>Recognize All</button>
        </div>
      )} */}
      

      {files.length > 0 && (
        <div className="image-preview-container">
          <div className="image-preview">
            <img
              className="image"
              src={URL.createObjectURL(files[currentIndex])}
              alt={`Preview of image ${currentIndex + 1}`}
            />
          </div>
          {files.length>1 && (

          <div>
            {(currentIndex !== 0 &&
          <button className="previous" onClick={handlePrevious}><HiArrowCircleLeft className="icon" /></button>
            )}
            {(currentIndex+1 !== files.length &&
          <button className="next" onClick={handleNext}><HiArrowCircleRight className="icon"/></button>
            )}
          </div>
          )}
          <button className="recognize" onClick={handleStartRecognition}>
            Recognize All
          </button>
        </div>
      )}

      
      {/* {status === "Recognizing..." && <progress className="progress-bar" value={progress} max="1" />} */}
      <p style={{color:"white"}}>
      {status}

      </p>
      {recognizedTexts && (
        <div className="result">
          <button className="copy" onClick={handleCopy }>Copy Text</button>
          <pre className="result2">{recognizedTexts}</pre>
        </div>
      )}
    </div>
  );
};

export default OCRComponent;
