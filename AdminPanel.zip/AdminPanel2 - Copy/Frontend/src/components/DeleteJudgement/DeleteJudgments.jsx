import React, { useState } from "react";
import "./DeleteJudgments.css";
import { iconsImgs } from "../../utils/images";
import { budget } from "../../data/data";

const Delete = () => {
  const [formData, setFormData] = useState({
    CaseNo: "",
    CaseSubject: "",
    CaseTitle: "",
    Court: "",
    AuthorJudge: "",
    JudgementDate: "",
    Citation: "",
    Tagline: "",
    Judgement: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);

    // Perform further logic, like sending data to the server
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  return (
    <div className="grid-two-item grid-common grid-c4">
      <div className="grid-c-title">
        <h3 className="grid-c-title-text">Delete Judgement</h3>
        <button className="grid-c-title-icon">
          <img src={iconsImgs.plus} alt="Plus Icon" />
        </button>
      </div>
      <div className="grid-c-top text-silver-v1">
        <h2 className="lg-value">Judgement Form</h2>
      </div>
      <div className="grid-c4-content bg-jet">
        <div className="grid-items">
          {/* Add Judgments Form */}
          <form onSubmit={handleSubmit}>
            <label className="lables">
              Case No:
              <input className="inputs"  id="input1"
                type="text"
                name="CaseNo"
                value={formData.CaseNo}
                onChange={handleChange}
              />
            </label>
            
           

            <br></br>
            
           
          
            <button className="sub_button" type="submit">Delete Judgement</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Delete;
