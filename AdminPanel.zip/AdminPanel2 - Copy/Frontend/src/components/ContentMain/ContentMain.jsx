import React,{ useEffect, useState } from 'react';
import Cards from '../AllJudgement/AllJudgments'
import Transactions from "../Transactions/Transactions";
import { useTable } from '../../layout/Outer/TableContext';
import "./ContentMain.css";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios';
import ClipLoader from "react-spinners/MoonLoader";



const ContentMain = ({ selectedLink }) => {
  const { tableData, updateTableData } = useTable()
  const {loading2, updateLoading} = useTable();
  let content;

  switch (selectedLink) {
    case 'all judgments':
      content = <AllJudgments />;
      break;
    case 'add judgments':
      content = <AddJudgments />;
      break;


    default:
      content = null; // Default content when no link is selected
  }
  
  

    useEffect(() => {
        updateLoading(true);
        const fetchCaseLaws = async () => {
          try {
            const response = await axios.get('http://localhost:5002/all');
            updateTableData(response.data);
            updateLoading(false);
          } 
          catch (error) {
            console.error('Error fetching CaseLaws:', error.message);
            toast.error('Error fetching CaseLaws');
            updateLoading(false)
          }
        };
    
        fetchCaseLaws();
      }, []);



  return (
    <div className="main-content-holder">
      {loading2 &&
                <div className="loading-spinner">
                      <ClipLoader
                        color={"#fe6c00"}
                        loading={loading2}
                        size={100}
                      />
                  </div>
      }

      <div className="content-grid-one">
        <Cards/>
        <Transactions/>
        
      </div>
    
      <div className="content-grid-two">
      </div>
    </div>
  );

}
export default ContentMain;
