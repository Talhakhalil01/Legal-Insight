import "./Transactions.css";
import React, { useEffect, useState } from 'react';
import { transactions } from "../../data/data";
import { iconsImgs } from "../../utils/images";
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';

const Transactions = () => {
  const [pendingCount, setPendingCount] = useState(0);
  const [approvedCount, setApprovedCount] = useState(0);

  useEffect(() => {
    const fetchSignupRequests = async () => {
      try {
        const response = await axios.get('http://localhost:5002/signup-requests');
        setPendingCount(response.data.pendingCount);
        setApprovedCount(response.data.approvedCount);
      } catch (error) {
        console.error('Error fetching signup requests:', error);
        toast.error('Failed to fetch signup requests');
      }
    };

    fetchSignupRequests();
  }, []);
  


  return (
    <div className="grid-one-item grid-common grid-c1">
    <div className="grid-c-title">
      <h3 className="grid-c-title-text">Signup Requests</h3>
    </div>
    <div className="grid-c1-content">
      <p>Requests pending</p>
      <div className="lg-value">{pendingCount}</div>
      <div className="card-logo-wrapper">
        <div>
          <p>Requests approved</p>
          <div className="lg-value">{approvedCount}</div>
        </div>
        <div className="card-logo">
          <img src={iconsImgs.review} alt="Review logo" />
        </div>
      </div>
    </div>
  </div>
  )
}

export default Transactions
