import { iconsImgs } from "../../utils/images";
import "./AllJudgments.css";

const All = () => {
  return (
    <div className="grid-one-item grid-common grid-c1">

        
        <div className="grid-c-title">
            <h3 className="grid-c-title-text">All Judgements</h3>
            <button className="grid-c-title-icon">
                <img src={ iconsImgs.plus } />
            </button>
        </div>
        <div className="grid-c1-content">
            <p>Judgements</p>
            <div className="lg-value">140</div>

            <div className="card-logo-wrapper">
                <div>
                 <a href="#">  <p className="text text-silver-v1 expiry-text">See All</p>
                 </a> 
                
                </div>
                <div className="card-logo">
                <img src={ iconsImgs.compliant } />
                 
                </div>
            </div>
        </div>
    </div>
  )
}

export default All;
