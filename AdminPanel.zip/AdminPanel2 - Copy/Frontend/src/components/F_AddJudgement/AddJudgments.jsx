
import "./AddJudgments.css";
import React, { useEffect, useState } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import ContentTop from '../ContentTop/ContentTop';
//import Add from '../AddJudgement/AddJudgments';
import { navigationLinks } from '../../data/data';


const F_Add = () => {
  const navigate = useNavigate();




  return (
    <div className='F_Add'>
      <ContentTop />
     
    </div>
    
  );
}

export default F_Add;
