import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { iconsImgs } from "../../utils/images";
import "./AllJudgments.css";
import { useTable } from '../../layout/Outer/TableContext';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios';
import ClipLoader from "react-spinners/MoonLoader";
import { useSearchData } from '../../layout/Outer/Searchdatacontext';
const All = () => {

  const { tableData, updateTableData } = useTable()
  const {activeLinkIdx, setActiveLinkIdx} = useSearchData();
  
  useEffect(() => {
    const pathToIdMapping = {
      '/': 1,
      '/all-judgements': 2,
      '/add-judgement': 3,
      '/delete-judgement': 4,
      '/edit-judgement': 5,
      '/review-requests': 6
    };

    const currentPath = location.pathname;
    const newActiveLinkIdx = pathToIdMapping[currentPath] || 1; // Default to 1 if path not found

    setActiveLinkIdx(newActiveLinkIdx);
  }, [location, setActiveLinkIdx]);


  return (
    <div className="grid-one-item grid-common grid-c1">        
      <div className="grid-c-title">
        <h3 className="grid-c-title-text">All Judgements</h3>
        <Link 
             to="/add-judgement" 
             className="grid-c-title-icon">
          <img src={iconsImgs.plus} alt="Add Judgement" />
        </Link>
      </div>
      <div className="grid-c1-content">
        <p>Judgements</p>
        <div className="lg-value">{tableData ? tableData.length : 0}</div>

        <div className="card-logo-wrapper">
          <div>
            <Link 
               to="/all-judgements">
               <p className="text text-silver-v1 expiry-text">See All</p>
            </Link>
          </div>
          <div className="card-logo">
            <img src={iconsImgs.compliant} alt="Compliant" />
          </div>
        </div>
      </div>
      
    </div>
  );
};

export default All;
