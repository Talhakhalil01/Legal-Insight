import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import ContentTop from '../F_AddJudgement/AddJudgments';
import axios from 'axios';
import './ProfileVerification.css';
import { ToastContainer, toast } from 'react-toastify';

const Profile = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(1);
  const [currentTab, setCurrentTab] = useState(1);
  const [notes, setNotes] = useState("");
  const [approvals, setApprovals] = useState([]);
  const [rejections, setRejections] = useState([]);
  const [loading, setLoading] = useState(false);

  const [frontImageURL, setFrontImageURL] = useState(null);
  const [backImageURL, setBackImageURL] = useState(null);
  const [LLBdegree, setLLBdegree] = useState(null);
  const [LAWGATresult, setLAWGATresult] = useState(null);
  const [certificateImage, setCertificateImage] = useState(null);
  const [approvalImage, setApprovalImage] = useState(null);
  const [imageURL, setImageURL] = useState(null);
  const [dataFetched, setDataFetched] = useState(false);





  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "+92",
    gender: "",
    province: "",
    city: "",
    areas: [],
    barAffiliation: "",
    barAssociation: "",
    barCardImages: {
      frontImage: null,
      backImage: null,
    },
    education: "",
    graduationYear: "",
    LLB: "",
    LLM: "",
    LLD: "",
    degrees: {
      LLBdegree: null,
      LAWGATresult: null,
    },
    currentPosition: "",
    durationOfPractice: "",
    lowerCourts: "",
    highCourt: "",
    certificates: {
      certificateImage: null,
      approvalImage: null,
    },
    licenseNumber: "",
    certifications: "",
    caseExperience: "",
    notableCases: "",
    successStories: "",
    officeAddress: "",
    officeHours: {
      Monday: { startTime: "09:00", endTime: "17:00" },
      Tuesday: { startTime: "09:00", endTime: "17:00" },
      Wednesday: { startTime: "09:00", endTime: "17:00" },
      Thursday: { startTime: "09:00", endTime: "17:00" },
      Friday: { startTime: "09:00", endTime: "17:00" },
      Saturday: { startTime: "00:00", endTime: "00:00" },
      Sunday: { startTime: "00:00", endTime: "00:00" }
    },
    consultationModes: [],
    consultationFees: {},
    lawyerImage: null,
    facebook: "",
    whatsapp: "+92",
    linkedin: "",
  

  });
 


  const fetchProfileData = async () => {
    // setLoading(true);
    try {
      const response = await axios.get(`http://localhost:5002/fetch-profile-id?id=${id}`);
      const { profileData, practiceAreas, consultationModes, officeHours, reviews, images } = response.data;

      const officeHoursObject = officeHours.reduce((acc, { dayOfWeek, startTime, endTime }) => {
        acc[dayOfWeek] = { startTime, endTime };
        return acc;
      }, {});

      const modesOptions = consultationModes.map(modeobj => ({
        value: modeobj.mode,
        label: modeobj.mode,
      }));

      const consultationFees = consultationModes.reduce((acc, { mode, fee }) => {
        acc[mode] = fee;
        return acc;
      }, {});

      const baseURL = `http://localhost:5000`;

      if (images.frontImage) setFrontImageURL(`${baseURL}${images.frontImage}`);
      if (images.backImage) setBackImageURL(`${baseURL}${images.backImage}`);
      if (images.LLBdegree) setLLBdegree(`${baseURL}${images.LLBdegree}`);
      if (images.LAWGATresult) setLAWGATresult(`${baseURL}${images.LAWGATresult}`);
      if (images.certificateImage) setCertificateImage(`${baseURL}${images.certificateImage}`);
      if (images.approvalImage) setApprovalImage(`${baseURL}${images.approvalImage}`);
      if (images.lawyerImage) setImageURL(`${baseURL}${images.lawyerImage}`);

      setFormData(prevFormData => ({
        ...prevFormData,
        name: profileData.name || prevFormData.name,
        email: profileData.email || prevFormData.email,
        phone: profileData.phone || prevFormData.phone,
        gender: profileData.gender || prevFormData.gender,
        province: profileData.province || prevFormData.province,
        city: profileData.city || prevFormData.city,
        areas: practiceAreas || prevFormData.areas,
        barAffiliation: profileData.barAffiliation || prevFormData.barAffiliation,
        barAssociation: profileData.barAssociation || prevFormData.barAssociation,
        education: profileData.education || prevFormData.education,
        graduationYear: profileData.graduationYear || prevFormData.graduationYear,
        LLB: profileData.LLB || prevFormData.LLB,
        LLM: profileData.LLM || prevFormData.LLM,
        LLD: profileData.LLD || prevFormData.LLD,
        currentPosition: profileData.currentPosition || prevFormData.currentPosition,
        durationOfPractice: profileData.durationOfPractice || prevFormData.durationOfPractice,
        lowerCourts: profileData.lowerCourts || prevFormData.lowerCourts,
        highCourt: profileData.highCourt || prevFormData.highCourt,
        licenseNumber: profileData.licenseNumber || prevFormData.licenseNumber,
        certifications: profileData.certifications || prevFormData.certifications,
        caseExperience: profileData.caseExperience || prevFormData.caseExperience,
        notableCases: profileData.notableCases || prevFormData.notableCases,
        successStories: profileData.successStories || prevFormData.successStories,
        officeAddress: profileData.officeAddress || prevFormData.officeAddress,
        officeHours: { ...prevFormData.officeHours, ...officeHoursObject },
        consultationModes: modesOptions || prevFormData.consultationModes,
        consultationFees: { ...prevFormData.consultationFees, ...consultationFees },
        lawyerImage: images.lawyerImage ? images.lawyerImage : prevFormData.lawyerImage,
        facebook: profileData.facebook || prevFormData.facebook,
        whatsapp: profileData.whatsapp || prevFormData.whatsapp,
        linkedin: profileData.linkedin || prevFormData.linkedin,
        date: profileData.signupDate || prevFormData.date,
      }));

      console.log("Fetched Data:", response.data);
      // setLoading(false);
    } catch (error) {
      // setLoading(false);
      console.error("Error:", error);
      toast.error('Error while fetching profile data:', error);
    }


};



useEffect(() => {
  fetchProfileData();
}, [id]);

  
const handleTabClick = (tabIndex) => {
  if (tabIndex <= forms.length) {
    setActiveTab(tabIndex);
  }
  else{
    setCurrentTab(8)
    console.log("Actice tab:",activeTab)
  }
};
useEffect(() => {

  if (currentTab === forms.length + 1) {
    const totalForms = forms.length;
    const totalReviewed = approvals.length + rejections.length;

    if (totalReviewed === totalForms) {
      if (rejections.length > 0) {
        updateStatusRejection();
      } else {
        updateStatusApproved();
      }
    } 
    else {
      toast.error("Please review all the forms");
    }
  }
}, [approvals, rejections,currentTab]);

const handleApproveSection = (section) => {
  if (!approvals.includes(section)) {
      setApprovals(prevApprovals => [...prevApprovals, section]);
      setRejections(prevRejections => prevRejections.filter(item => item !== section));
      handleTabClick(activeTab+1);
  }
};

const handleRejectSection = (section) => {
  if (!rejections.includes(section)) {
      setRejections(prevRejections => [...prevRejections, section]);
      setApprovals(prevApprovals => prevApprovals.filter(item => item !== section));
      handleTabClick(activeTab + 1);
  }
};

const handleNotesChange = (e) => {
  setNotes(e.target.value);
};

const updateStatusApproved = () => {
  // Call your API to update status as approved
  axios.post(`http://localhost:5002/update-status-approved/${id}`)
    .then(response => {
      toast.success("Profile approved successfully");
      navigate(`/review-requests`);
    })
    .catch(error => {
      console.error('Error updating status to approved:', error);
      toast.error("Failed to approve profile");
    });
};

const updateStatusRejection = () => {
  // Call your API to update status as rejected
  axios.post(`http://localhost:5002/update-status-rejection/${id}`, {
    rejections,
    notes
  })
    .then(response => {
      toast.success("Profile rejected successfully");
      navigate(`/review-requests`);
    })
    .catch(error => {
      console.error('Error updating status to rejected:', error);
      toast.error("Failed to reject profile");
    });
};

 
  const formatOfficeHours = (officeHours) => {
    return (
      <div className="office-hours">
        {Object.entries(officeHours).map(([day, { startTime, endTime }]) => (
          <div key={day} className="office-hours-day">
            <span className="day">{day}:</span>
            <div className="time">
              <span className="start-time">{startTime}</span>
              <span className="dash">-</span>
              <span className="end-time">{endTime}</span>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const formatConsultationFees = (consultationFees) => {
    return (
      <div className="consultation-fees">
        {Object.entries(consultationFees).map(([mode, fee]) => (
          <div key={mode} className="consultation-fees-mode">
            <div className="mode-fee">
              <span className="mode">{mode}:</span>
              <span className="fee">{fee}rs</span>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const formatPracticeAreas = () => {
    const areas = formData.areas;
    if (Array.isArray(areas)) {
      const areaNames = areas.map(areaObj => areaObj.area);
      return areaNames.join(", ");
    } else if (typeof areas === 'object' && areas !== null && 'area' in areas) {
      return areas.area;
    } else {
      return "";
    }
  }

  const forms = [
    {
      title: "Practice Areas and Bar Information",
      fields: [
        { label: "Areas", value: formatPracticeAreas() },
        { label: "Bar Affiliation", value: formData.barAffiliation },
        { label: "Bar Association", value: formData.barAssociation },
      ],
      documents: ["Front Bar Card","Back Bar Card"],
    },
    {
      title: "Personal Information",
      fields: [
        { label: "Name", value: formData.name },
        { label: "Email", value: formData.email },
        { label: "Phone", value: formData.phone },
        { label: "Gender", value: formData.gender },
        { label: "Province", value: formData.province },
        { label: "City", value: formData.city },
      ],
      documents: [],
    },
    {
      title: "Education",
      fields: [
        { label: "Education", value: formData.education },
        { label: "Graduation Year", value: formData.graduationYear },
        { label: "LLB", value: formData.LLB },
        { label: "LLM", value: formData.LLM },
        { label: "LLD", value: formData.LLD },
      ],
      documents: ["LLB Degree", "LAW GAT Result"],
    },
    {
      title: "Professional Experience",
      fields: [
        { label: "Current Position", value: formData.currentPosition },
        { label: "Duration of Practice", value: formData.durationOfPractice },
        { label: "Lower Courts", value: formData.lowerCourts },
        { label: "High Court", value: formData.highCourt },
      ],
      documents: ["Certificate Image", "Approval Image"],
    },
    {
      title: "Additional Information",
      fields: [
        { label: "License Number", value: formData.licenseNumber },
        { label: "Certifications", value: formData.certifications },
        { label: "Case Experience", value: formData.caseExperience },
        { label: "Notable Cases", value: formData.notableCases },
        { label: "Success Stories", value: formData.successStories },
      ],
      documents: [],
    },
    {
      title: "Office Details",
      fields: [
        { label: "Office Address", value: formData.officeAddress },
        { label: "Office Hours", value: formatOfficeHours(formData.officeHours) },
        { label: "Consultation Modes", value:  formData.consultationModes.map(mode => mode.label).join(", ") },
        { label: "Consultation Fees", value: formatConsultationFees(formData.consultationFees) },
      ],
      documents: [],
    },
    {
      title: "Social Media and Contact",
      fields: [
        { label: "Facebook", value: formData.facebook },
        { label: "WhatsApp", value: formData.whatsapp },
        { label: "LinkedIn", value: formData.linkedin },
      ],
      documents: [],
    },
  ];
  
  
  

  return (
    <div className="profile-container">
      <ContentTop/>
    <div className="profile-content">
      <div className="profile-header">
        <img
          src={imageURL}
          alt={formData.name}
          className="profile-image"
        />
        <div>
          <h1 className="profile-name">{formData.name}</h1>
          <div className="profile-social-links">
            <a
              href={formData.facebook}
              target="_blank"
              rel="noopener noreferrer"
            >
              <i className="fab fa-facebook profile-facebook-icon"></i>
            </a>
            <a
              href={formData.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
            >
              <i className="fab fa-whatsapp profile-whatsapp-icon"></i>
            </a>
            <a
              href={formData.linkedin}
              target="_blank"
              rel="noopener noreferrer"
            >
              <i className="fab fa-linkedin profile-linkedin-icon"></i>
            </a>
          </div>
        </div>
      </div>

      <div className="profile-forms">
        <div className="profile-tabs">
          {forms.map((form, index) => (
            <button
              key={index}
              className={`profile-tab ${
                activeTab === index + 1 ? "active-tab" : ""
              }`}
              onClick={() => handleTabClick(index + 1)}
            >
              {form.title}
            </button>
          ))}
        </div>

        <div className="profile-form-content">
          {/* <h2 className="form-title">{forms[activeTab - 1].title}</h2> */}
          <div className="form-fields">
            {forms[activeTab - 1].fields.map((field, index) => (
              <p key={index}>
                <strong>{field.label}:</strong> {field.value}
              </p>
            ))}
            {forms[activeTab - 1].documents.length > 0 && (
              <div className="form-documents">
                <h3 className="documents-title">Documents:</h3>
                {forms[activeTab - 1].documents.map((doc, index) => (
                  <p key={index}>{doc}</p>
                ))}
              </div>
            )}
            <div className="form-actions">
              <button
                className="approve-button"
                onClick={() => handleApproveSection(forms[activeTab - 1].title)}
              >
                {approvals.includes(forms[activeTab - 1].title) ? "Approved" : "Approve"}
              </button>
              <button
                className="reject-button"
                onClick={() => handleRejectSection(forms[activeTab - 1].title)}
              >
                {rejections.includes(forms[activeTab - 1].title) ? "Rejected" : "Reject"}
            
              </button>
          </div>
          </div>
         
          <textarea
            className="notes-textarea"
            value={notes}
            onChange={handleNotesChange}
            placeholder="Add notes here..."
            
          ></textarea>
        </div>
      {activeTab === 1 && (
            <div className="documents-container">
                <div className="barcard-document-viewer">
                  <div className="image-container">
                    <label className="label1">Front Bar Card:</label>
                    <img src={frontImageURL} alt={"Front Bar Card"} className=""/>

                  </div>  
    
                  <div className="image-container">
                    <label className="label2">Back Bar Card:</label>
                    <img src={backImageURL} alt={"Back Bar Card"} className=""/>
                  </div>

                </div>
                <div className="degrees-document-viewer">

                <div className="image-container">
                    <label className="label1">LLB Degree:</label>
                    <img src={LLBdegree} alt={"LLB Degree"} className="LLB"/>
                </div>

                <div className="image-container">
                    <label className="label1">LAW-GAT Result:</label>
                    <img src={LAWGATresult} alt={"LAW-GAT Result"} className="LAW-GAT"/>
                </div>


                </div>
                <div className="certificates-document-viewer">

                <div className="image-container">
                    <label className="label1">Certificate Image:</label>
                    <img src={certificateImage} alt={"Certificate Image"} className=""/>
                </div>

                <div className="image-container">
                    <label className="label1">Approval Image:</label>
                    <img src={approvalImage} alt={"Approval Image"} className=""/>

                </div>
                    
                </div>
            </div>
        )}

        {activeTab === 3 && (
            <div className="documents-container">

                <div className="degrees-document-viewer">

                <div className="image-container">
                    <label className="label1">LLB Degree:</label>
                    <img src={LLBdegree} alt={"LLB Degree"} className="LLB"/>
                </div>

                <div className="image-container">
                    <label className="label1">LAW-GAT Result:</label>
                    <img src={LAWGATresult} alt={"LAW-GAT Result"} className="LAW-GAT"/>
                </div>


                </div>

                <div className="barcard-document-viewer">
                  <div className="image-container">
                    <label className="label1">Front Bar Card:</label>
                    <img src={frontImageURL} alt={"Front Bar Card"} className=""/>

                  </div>  
    
                  <div className="image-container">
                    <label className="label2">Back Bar Card:</label>
                    <img src={backImageURL} alt={"Back Bar Card"} className=""/>
                  </div>

                </div>
               
                <div className="certificates-document-viewer">

                <div className="image-container">
                    <label className="label1">Certificate Image:</label>
                    <img src={certificateImage} alt={"Certificate Image"} className=""/>
                </div>

                <div className="image-container">
                    <label className="label1">Approval Image:</label>
                    <img src={approvalImage} alt={"Approval Image"} className=""/>

                </div>
                    
                </div>
            </div>
        )}
        {activeTab === 4 && (
            
            <div className="documents-container">
                
                <div className="certificates-document-viewer">

                      <div className="image-container">
                          <label className="label1">Certificate Image:</label>
                          <img src={certificateImage} alt={"Certificate Image"} className=""/>
                      </div>

                      <div className="image-container">
                          <label className="label1">Approval Image:</label>
                          <img src={approvalImage} alt={"Approval Image"} className=""/>

                      </div>
                          
                </div> 

                <div className="barcard-document-viewer">
                  <div className="image-container">
                    <label className="label1">Front Bar Card:</label>
                    <img src={frontImageURL} alt={"Front Bar Card"} className=""/>

                  </div>  
    
                  <div className="image-container">
                    <label className="label2">Back Bar Card:</label>
                    <img src={backImageURL} alt={"Back Bar Card"} className=""/>
                  </div>

                </div>
                <div className="degrees-document-viewer">

                <div className="image-container">
                    <label className="label1">LLB Degree:</label>
                    <img src={LLBdegree} alt={"LLB Degree"} className="LLB"/>
                </div>

                <div className="image-container">
                    <label className="label1">LAW-GAT Result:</label>
                    <img src={LAWGATresult} alt={"LAW-GAT Result"} className="LAW-GAT"/>
                </div>


                </div>
               
            </div>
        )}
      </div>
    </div>
  </div>
  );
};

export default Profile;
