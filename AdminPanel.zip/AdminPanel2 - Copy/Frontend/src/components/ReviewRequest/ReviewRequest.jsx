import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import ContentTop from '../F_AddJudgement/AddJudgments';
import './ReviewRequest.css';

const ReviewRequests = () => {
  const navigate = useNavigate();
  const [reviewRequests, setReviewRequests] = useState([]);

  useEffect(() => {
    const fetchReviewRequests = async () => {
      try {
        const response = await axios.get('http://localhost:5002/fetch-requests'); 
        setReviewRequests(response.data);
        console.log("Verification data received at table:",response.data)
      } catch (error) {
        console.error('Error fetching review requests:', error);
      }
    };

    fetchReviewRequests();
  }, []);

  const handleNameClick = (id) => {
    navigate(`/profile/${id}`);
  };

  return (
    <div className="review-requests-container">
      <ContentTop />
      <div className="review-requests-content">
        <h1 className="review-requests-title">Review Requests</h1>
        <table className="review-requests-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Status</th>
              <th>Signup Date</th>
            </tr>
          </thead>
          <tbody>
            {reviewRequests.map((request) => (
              <tr
                key={request.ID}
                className="clickable-row"
                onClick={() => handleNameClick(request.ID)}
              >
                <td className="review-requests-name">
                  {request.name}
                </td>
                <td>
                  Pending...
                </td>
                <td>
                  {new Date(request.signupDate).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ReviewRequests;
