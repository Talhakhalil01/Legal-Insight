import "./ContentMain.css";
import AllJudgments from "../Cards/AllJudgments";
import Transactions from "../Transactions/Transactions";
import Report from "../Report/Report";
import AddJudgments from "../Budget/AddJudgments";
//import Subscriptions from "../Subscriptions/Subscriptions";
//import Savings from "../Savings/Savings";
//import Loans from "../Loans/Loans";
//import Financial from "../Financial/Financial";

const ContentMain = () => {
  return (
    <div className="main-content-holder">
        <div className="content-grid-one">
            <AllJudgments />
            <Transactions />
            <Report />
        </div>
        <div className="content-grid-two">
            <AddJudgments />
       {/*    <div className="grid-two-item">
              <div className="subgrid-two">
                <Subscriptions />
                <Savings />
              </div>
            </div>

            <div className="grid-two-item">
              <div className="subgrid-two">
                <Loans />
                <Financial />
              </div>
  </div>  */}
        </div>
    </div>
  )
}

export default ContentMain
